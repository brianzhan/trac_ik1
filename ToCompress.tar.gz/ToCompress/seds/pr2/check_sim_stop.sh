#!/bin/bash -x

ps -ef | grep ros
ps -ef | grep pr2
ps -ef | grep gazebo

