#!/bin/bash

rosrun seds publish_rcart.py "[0.9, -0.186, 0.248, -0.018, -0.470, 0.001, 0.883]"
