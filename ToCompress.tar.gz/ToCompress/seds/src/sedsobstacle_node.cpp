#include "ros/ros.h"
#include <vector>
#include "SedsObstacle.h"
#include "seds/ObjSrv.h"
#include "seds/ObsAvoidSrv.h"
#include <math.h>
#include <time.h>
#include <algorithm>
#include <string>
// typedef vector<float> fvec;

using namespace std;

vector<SedsObstacle *>m_ObsList; // a vector to hold all the obstacle. 
bool m_ObsContour;
Vector m_CurrRoboPosition;
Vector m_CurrRoboVel;
// vector<float> m_ObsGamma;
Vector m_ObsGamma;
Vector m_ObsGammaTemp;
Vector m_W;
MathLib::Matrix m_M;
int numObs;


bool sedsobsSRV(seds::ObjSrv::Request &req, seds::ObjSrv::Request &res) // single service call which will instantiate all the static objcts in the 3d world
{
	srand(time(NULL));
	m_ObsContour = false;
	if(m_ObsList.empty())
	{
		numObs = req.obstacles.size(); // total number of obstacles
		ROS_INFO("Num of obstacles %d", numObs);
		for (int i = 0; i < numObs; i++)
		{
			// m_ObsContour.push_back(false); 
			m_ObsList.push_back(new SedsObstacle(req.exponent));
			ROS_INFO("origin and radius %f %f %f %f", req.obstacles[i].origin.x, req.obstacles[i].origin.y,req.obstacles[i].origin.z,req.obstacles[i].radius);
			m_ObsList[i]->initialize_values(req.obstacles[i].origin, req.obstacles[i].radius);
		}
	}

	for (int i = 0; i < numObs; ++i)
	{
		ROS_INFO("obs gamma %f",m_ObsList[i]->m_Gamma);
	}
	if(req.obstacles.size() != 0)
	{
		m_M = Matrix(3, 3); // 3 dimensional space,
		m_M.Identity();
		// m_M.Print();
	}
	
	m_CurrRoboPosition = Vector(3);
	m_CurrRoboPosition.Zero();
	m_CurrRoboVel = Vector(3);
	m_CurrRoboVel.Zero();
	m_ObsGamma = Vector(numObs);
	m_ObsGamma.Zero();
	m_ObsGammaTemp = Vector(m_ObsGamma.Size());
	m_ObsGammaTemp.Zero();
	m_W = Vector(numObs);
	// m_W.Zero();
	return true;
}

void compute_weights()
{

	
	m_ObsGammaTemp.Set(m_ObsGamma);
	// ROS_INFO("Gamma Temp is");
	// m_ObsGammaTemp.Print();

	for (int i = 0; i < numObs ; ++i)
	{
		if(m_ObsGammaTemp(i) < 1)
			m_ObsGammaTemp(i) = 1;
	}
	// ROS_INFO("Pre Gamma");
	// m_ObsGamma.Print();
	m_ObsGammaTemp -= 1; // element wise subtraction
	// ROS_INFO("Post Gamma duplicate");
	// m_ObsGammaTemp.Print();
	// ROS_INFO("Original Gamma");
	// m_ObsGamma.Print();
	for (int i = 0; i < numObs; ++i)
	{
		/********************************************/
		//This chunk of code does
		// ind = 1:N;
    	// ind(i) = [];

		vector<int> index;
		if (index.size() > 0)
		{
			index.clear();
		}
		for(int j=0; j<numObs; j++)
		{
			index.push_back(j);
			// std::cout << j << std::endl;
		}
		index.erase(index.begin() + i);
		Vector ind = Vector(numObs - 1);
		ind.Zero();
		for(int j=0; j < numObs-1; j++)
		{
			ind(j) = index[j];
		}
		/************************************************/
		float ind_G = m_ObsGammaTemp(i); //scalar Gamma(i)

		/************************************************/
		// w(i) = prod(Gamma(ind)./(Gamma(i)+Gamma(ind)));
		float prod = 1.0;
		for (int j = 0; j < numObs-1; ++j)
		{
			float temp = m_ObsGammaTemp(ind(j))/(ind_G + m_ObsGammaTemp(ind(j)));
			prod *= temp;
		}
		/***********************************************/
		// ROS_INFO("Prod %f", prod);
		m_W(i) = prod;
	}
	// ROS_INFO("Weight List");
	// m_W.Print();

}
// vector <int> sort_indices(const vector<float> &v)
// {
// 	vector <int> idx (v.size());
// 	for (int i=0; i < idx.size(); i++)
// 	{
// 		idx[i] = i; // create index vector
// 	}
// 	sort(idx.begin(),idx.end(), [&v](int i1, int i2)
// 		{
// 			return v[i1] > v[i2];
// 		}
// 		);
// 	return idx;

// }
bool sedsObsAvoidSRV(seds::ObsAvoidSrv::Request &req, seds::ObsAvoidSrv::Response &res) // obs_modulation_ellipsoid(x,xd,obs,m_ObsContour,xd_obs), 
{	// x - is needed to subtract from origin of obstacle. transfer origin to the obsatcle
	// xd - is the returned value from SEDs model. the non modulated dx
	// obs - is the obstacle list. this is maintained in this calss directly
	// m_ObsContour - is the bool list, this is also maintained in this class directly
	// xd_obs - 0 vector. the objects are static. 
	// this should take in a dx which was originally from SEDS. And then return a modulated dx which will then be used to update x.
	//The modulation matrix is obtained from all the obstacle descriptions that is maintained in m_ObsList. 
	
	// Vector ones = Vector(4); ones.One(); ones(0) = -ones(0); //[-1 1 1]
	// ones /= 3;
	// // ROS_INFO("Test print adjkadashdjka");
	// // ones.Print();

	int dim = req.x.size(); // 3
	m_M.Identity();
	for (int i = 0; i < dim; ++i)
	{
		m_CurrRoboPosition(i) = req.x[i];
		m_CurrRoboVel(i) = req.dx[i];
	}

	for (int i = 0; i < numObs; ++i) // For each obstacle compute E and Gamma. Computer basis matrix function
	{	
		m_ObsList[i]->compute_basis_matrix(m_CurrRoboPosition);
	}
	m_ObsGamma.Zero(); // this has to set for every loop
	for (int i = 0; i < numObs; ++i)
	{
		// m_ObsGamma.push_back(m_ObsList[i]->m_Gamma); // this will populate the gamma list with the gammas of all the obstacles
		m_ObsGamma(i) = m_ObsList[i]->m_Gamma;
	}
	// ROS_INFO("Gamm original");
	// m_ObsGamma.Print();

	m_W.Zero(); // set all elements to zero. needs to be computed every call
	compute_weights();
	Vector D = Vector(4);
	// cout<< "The sorted indices are" << sortedindex[i] << std::endl;
	// // }
	// std::cout<< "Unsorted Gamma" <<std::endl;
	// for(int i=0; i<numObs; i++)
	// {
	// 	std::cout<<m_ObsGamma[i] <<std::endl;
	// }
	vector <unsigned int> *indicesVector = new std::vector<unsigned int>();
	m_ObsGamma.Sort(indicesVector);
	// std::cout<< "Sorted Gamma and index" <<std::endl;
	// for(int i=0; i<numObs; i++)
	// {
	// 	std::cout<<m_ObsGamma[i] << " " << indicesVector->at(i) <<std::endl;
	// }
	for (int k = 0; k < numObs; k++)
	{	
		int i = indicesVector->at(k);
		float rho = 1.0; // higher reactivity 
		Vector ones = Vector(4); ones.One(); ones(0) = -ones(0); //[-1 1 1 1]
		D = (ones/pow(fabs(m_ObsGamma[i]), 1/rho))*m_W(i); // 4d
		MathLib::Matrix RMatrix = m_ObsList[i]->m_R;
		// ROS_INFO("D Vector Before");
		// D.Print();
		if(D(0) < -1.0)
		{
			for(int j=1; j<D.Size(); j++)
			{
				D(j) = 1.0;
			}
			
			Vector t2 = m_ObsList[i]->m_E.GetColumn(0);
			// ROS_INFO("Matrix print.adakldjasldjka");
			// t2.Print();
			Vector r = RMatrix*t2;
			Vector t3 = m_CurrRoboVel^r;
			if(t3.Sum() < 0)
			{
				D(0) = -1.0;
			}
			// else
			// {
			// 	D(0) =  1.0; // matlab code has -1.0 in both blocks. seems to be an error. 
			// }
		}
		// ROS_INFO("D Vector After");
		// D.Print();
		MathLib::Matrix EMatrix = m_ObsList[i]->m_E;

		MathLib::Matrix dMatrix = Matrix(4,4);
		dMatrix.Diag(D+1);

		MathLib::Matrix temp2 = (dMatrix*EMatrix.Inverse());
		m_M = RMatrix*EMatrix*temp2*(RMatrix.Transpose())*m_M; // if one of the obstacles becomes a taregt then this step can be m_M = identity *m_M

		// ROS_INFO("Modulation Matrix");
		// m_M.Print();

	}
	// the following line of code was not in the numObs loop. which means n=the last obstacle?!!!?!??!
// E(:,:,n) = R(:,:,n)*E(:,:,n); %transforming the basis vector into the global coordinate system
	// for (int i = 0; i < numObs; ++i)
	// {
	// 	m_ObsList[i]->transformE();
	// }
	// if(numObs > 0)
	// {
		int lastObjIndex = indicesVector->at(indicesVector->size()-1); //numObs - 1;
		m_ObsList[lastObjIndex]->transformE(); // Just tranforms the last object? ?? 
		if(m_ObsContour == false && D(0) < -0.98 && (((m_ObsList[lastObjIndex]->m_E.GetColumn(0))^m_CurrRoboVel).Sum() < 0.0) && ((m_M*m_CurrRoboVel).Norm() < 0.02))
		{
			m_ObsContour = true;
			// ROS_INFO("Contouring has started");
		}
		// ROS_INFO("Unmodulated velocity");
		// m_CurrRoboVel.Print();
		if(m_ObsContour == true)
		{
			Vector contour_dir = m_ObsList[lastObjIndex]->m_E.GetColumn(1); // column one, becasue select that eigen direction to contour. 
			contour_dir /= contour_dir.Norm(); //normalize the vector
			// ROS_INFO("Controu dir");
			// contour_dir.Print();
			// if(((contour_dir^(m_M*m_CurrRoboVel)).Sum() > 0) && ((m_M*m_CurrRoboVel).Norm() > 0.05) || (m_CurrRoboVel^(m_ObsList[lastObjIndex]->m_E.GetColumn(0))).Sum() > 0.0)
			if((((m_ObsList[lastObjIndex]->m_E.GetColumn(0))^m_CurrRoboVel).Sum() > 0.0))
			{
				m_ObsContour = false;
				m_CurrRoboVel = m_M*m_CurrRoboVel; // vector
				// ROS_INFO("Contouring stopped");
			}
			else
			{
				// ROS_INFO("Controu dir");
				// contour_dir.Print();
				// ROS_INFO("In contouring");
				// m_CurrRoboVel = contour_dir*0.05; //0.01 is the amplitude along the eigen direction to contour. 
				m_CurrRoboVel = contour_dir*(m_CurrRoboVel.Norm());
				//m_CurrRoboVel *= 0.001;
				// ROS_INFO("modulated contoured velocity");
				// m_CurrRoboVel.Print();
			}	
		}else
		{
			m_CurrRoboVel = m_M*m_CurrRoboVel;
			if((m_M*m_CurrRoboVel).Norm() > 0.05)
			{
				m_CurrRoboVel = (m_M*m_CurrRoboVel)*(m_CurrRoboVel.Norm()/(m_M*m_CurrRoboVel).Norm());
			}
			// ROS_INFO("modulated velocity");
			// m_CurrRoboVel.Print();
		}
	// }
	//fake response for the time being. 
	res.moddx.resize(dim);
	res.moddx[0] = m_CurrRoboVel(0); res.moddx[1] = m_CurrRoboVel(1); res.moddx[2] = m_CurrRoboVel(2);
	delete indicesVector;
	return true;
}


int main(int argc, char **argv)
{
	ros::init(argc, argv, "sedsobs_server");
	ros::NodeHandle n;
	string currns = n.getNamespace();
	
	ros::ServiceServer instantiate = n.advertiseService(currns + "/seds/obslist_instan", sedsobsSRV);
	ros::ServiceServer obs_mod_ellipsoid = n.advertiseService(currns + "/seds/obs_mod_ellip", sedsObsAvoidSRV);
	ROS_INFO("In SEDS Obstacle node");
	ros::spin();
}