#ifndef SedsObstacle_h
#define SedsObstacle_h

#include <float.h>
#include "ros/ros.h"
#include "MathLib/MathLib.h"
#include <geometry_msgs/Vector3.h>
#include <vector>
#include <algorithm>
#include <math.h>

using namespace std;
using namespace MathLib;

class SedsObstacle{

public:

	int m_dim, m_numPartitions;
	MathLib::Matrix m_a; // length scales along each axis. a=  new Vector[k] in constructor, where k is the dimensionality of the obstacle space
	MathLib::Matrix m_p; // Matrix containing the exponents for each dimension
	Vector m_x0; // vector containing the center of each obstacle with the global frame (the same frame which was used to compute the end effector frame)
	Vector m_sf;
	Vector m_thr;
	MathLib::Matrix m_partition;

	MathLib::Matrix m_R;
	MathLib::Matrix m_E;

	float m_Gamma;
	int m_Exponent;

	Vector m_xt; // diff of robo position and origin of obstacle

	SedsObstacle(int exponent);
	~SedsObstacle();

	void initialize_values(geometry_msgs::Vector3 origin, float radius);
	bool compute_basis_matrix(Vector &robotPosition);
	bool transformE();

};

#endif