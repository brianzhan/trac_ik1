#include <algorithm>
#include "ros/ros.h"
#include "std_srvs/Empty.h"
#include "seds/SedsOptimize.h"
#include "seds/SedsModel.h"
#include "seds/FileIO.h"
#include "seds_wrapper.hpp"

SEDS *seds_obj = NULL;
string source_fid;
string target_fid;

bool saveFileSRV(seds::FileIO::Request &req, seds::FileIO::Response &res)
{

  if (!seds_obj){
    ROS_INFO("You need to run seds_optimize to generate new model parameters!");
    return false;
  }

  rosbag::Bag bag;
  seds::ModelParameters model;
  populate_model_msg(seds_obj, source_fid, target_fid, model);


  bag.open(req.filename.c_str(), rosbag::bagmode::Write);
  bag.write("seds/params", ros::Time::now(), model);

  bag.close();
  return true;
}

bool getParamsSRV(seds::SedsModel::Request &req, seds::SedsModel::Response &res)
{
  // helper function in seds_wrapper
  populate_model_msg(seds_obj, source_fid, target_fid, res.model);

  return true;
}

bool sedsSRV(seds::SedsOptimize::Request  &req, seds::SedsOptimize::Response &res )
{
  vector< vector<fvec> > trajectories; // 3d vector. outer most dimenssion - nth trajectory, the next dim - the number of samples in each trajectory, and the innermost, the dimensionality of the data, which is 12d x-pose and dxpose. 
  float dT; // will be populated in process_bagfile function call. 
  ivec labels; // not sure why this is here. 
  string filename = req.filename; // this filename is output of the tf2seds.py script. the file which has ALL the samples from all the bag files written under the label /seds/trajectories. 

  // need to know what transforms were used to generate the pose data
  if (seds_obj){ // if a seds obj is alive, kill it and spawn a new one. 
    delete seds_obj;
  }
  seds_obj = new SEDS();

  // process the input file into trajectories for training
  process_bagfile(filename, trajectories, dT, source_fid, target_fid); // proess the file. extract info

  // set up and perform seds optimization
  seds_optimize(seds_obj, trajectories, dT);

  ROS_INFO("Optimization done!");
  return true;
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "seds_server");
  ros::NodeHandle n;
  string currns = n.getNamespace();
  ros::ServiceServer service = n.advertiseService(currns + "/seds/optimize", sedsSRV);
  ros::ServiceServer modelparams = n.advertiseService(currns + "/seds/params", getParamsSRV);
  ros::ServiceServer savefile = n.advertiseService(currns + "/seds/save_file", saveFileSRV);

  ROS_INFO("Ready to optimize.");
  ros::spin();

  return 0;
}
