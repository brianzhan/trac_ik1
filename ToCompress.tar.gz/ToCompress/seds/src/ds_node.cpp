#include "std_srvs/Empty.h"
#include "fgmm/fgmm++.hpp"
#include "seds_wrapper.hpp"
#include "ros/ros.h"
#include "seds/DSSrv.h"
#include "seds/SedsModel.h"
#include "seds/ModelParameters.h"
#include "seds/FileIO.h"
#include "seds/DSLoaded.h"
#include "seds/DSEndPoint.h"
#include "seds/SedsMatlabModel.h"
#include "std_srvs/Empty.h"
#include <sys/stat.h>
#include <string>
Gmm *gmm = NULL;
fvec endpoint;
float dT;
int dimX;
string source_fid;
string target_fid;

bool loadMatlabFileSRV(seds::FileIO::Request &req, seds::FileIO::Response &res)
{

  ros::NodeHandle n;
  string currns = n.getNamespace();
  ros::ServiceClient client = n.serviceClient<seds::SedsMatlabModel>(currns + "/seds/loadmatmodel");
  seds::SedsMatlabModel srv;
  srv.request.filename = req.filename;

  ROS_INFO("The matlab file path is %s", srv.request.filename.c_str());
  client.call(srv);

  ROS_INFO ("The dimensionality from the service is %d", srv.response.model.dim);
  dimX = srv.response.model.dim;
  int dim = srv.response.model.dim * 2;
  int nbClusters = srv.response.model.ncomp;
  dT = srv.response.model.dT;
  
  endpoint.resize(dim);
  for(int i = 0; i < dim; i++){
    endpoint[i] = srv.response.model.offset[i];
  }

  ROS_INFO("Using endpoinyyyyyt %d: %f %f %f %f %f %f %f", dim/2, endpoint[0], endpoint[1], endpoint[2], endpoint[3], endpoint[4], endpoint[5], endpoint[6]); // THis is the endpoint, or target?!!!
  ROS_INFO("Using dT: %f", dT);

  if (gmm != NULL)
    delete gmm;

  gmm = new Gmm(nbClusters,dim);

  // and we copy the values back to the source
  float *mu = new float[dim];
  float *sigma = new float[dim*dim];

  for(int k = 0; k < nbClusters; k++){
    for (int i = 0; i < dim; i++){
      mu[i] = srv.response.model.mus[k * dim + i];
      for (int j = 0; j < dim; j++){
  sigma[i * dim + j] = srv.response.model.sigmas[k * dim * dim + i * dim + j];
      }
    }
    fgmm_set_prior(gmm->c_gmm, k, srv.response.model.priors[k]);
    fgmm_set_mean(gmm->c_gmm, k, mu);
    fgmm_set_covar(gmm->c_gmm, k, sigma);
  }

  delete [] sigma;
  delete [] mu;

  source_fid = srv.response.model.source_fid;
  target_fid = srv.response.model.target_fid;
  gmm->initRegression(dim/2);

  return true;
  
}


bool loadFileSRV(seds::FileIO::Request &req, seds::FileIO::Response &res)
{

  rosbag::Bag bag;
  bag.open(req.filename.c_str(), rosbag::bagmode::Read);
  rosbag::View view(bag, rosbag::TopicQuery("seds/params"));

  BOOST_FOREACH(rosbag::MessageInstance const m, view){
    seds::ModelParameters::ConstPtr model = m.instantiate<seds::ModelParameters>();

    // Only one model parameters message will be processed. If you
    // want to filter by some model field (like a new name field?)
    // here is where to do that.

    // now extract the parameters for the gmm!
    dimX = model->dim;
    int dim = model->dim * 2;
    int nbClusters = model->ncomp;
    dT = model->dT;

    endpoint.resize(dim);
    for(int i = 0; i < dim; i++){
      endpoint[i] = model->offset[i];
    }

    ROS_INFO("Using endpoint %d: %f %f %f", dim/2, endpoint[0], endpoint[1], endpoint[2]);
    ROS_INFO("Using dT: %f", dT);

    if (gmm != NULL)
      delete gmm;

    gmm = new Gmm(nbClusters,dim);

    // and we copy the values back to the source
    float *mu = new float[dim];
    float *sigma = new float[dim*dim];

    for(int k = 0; k < nbClusters; k++){
      for (int i = 0; i < dim; i++){
	mu[i] = model->mus[k * dim + i];
	for (int j = 0; j < dim; j++){
	  sigma[i * dim + j] = model->sigmas[k * dim * dim + i * dim + j];
	}
      }
      fgmm_set_prior(gmm->c_gmm, k, model->priors[k]);
      fgmm_set_mean(gmm->c_gmm, k, mu);
      fgmm_set_covar(gmm->c_gmm, k, sigma);
    }

    delete [] sigma;
    delete [] mu;

    source_fid = model->source_fid;
    target_fid = model->target_fid;
		ROS_INFO("Using fids s->t: %s -> %s", source_fid.c_str(), target_fid.c_str());
    gmm->initRegression(dim/2);

    return true;


  }

  // should not get here...
  return false;
}



bool getParamsSRV(seds::SedsModel::Request &req, seds::SedsModel::Response &res)
{
  int d;

  if (gmm == NULL){
    ROS_INFO("You need to load parameters first!");
    return false;
  }

  res.model.dim = gmm->dim;
  res.model.ncomp = gmm->nstates;
  res.model.dT = dT;
  d = res.model.dim;

  res.model.offset.resize(d);
  for (int i = 0; i < d; i++){
    res.model.offset[i] = endpoint[i];
  }

  res.model.priors.resize(res.model.ncomp);
  for (int k = 0; k < res.model.ncomp; k++){
    res.model.priors[k] = fgmm_get_prior(gmm->c_gmm, k);
  }

  res.model.mus.resize(d * res.model.ncomp);
  for(int k = 0; k < res.model.ncomp; k++){
    for (int i = 0; i < d; i++){
      res.model.mus[ k * d + i ] = fgmm_get_mean(gmm->c_gmm, k)[i];
    }
  }

  res.model.sigmas.resize(d * d * res.model.ncomp);
  for(int k = 0; k < res.model.ncomp; k++){
    for (int i = 0; i < d; i++){
      for (int j = 0; j < d; j++){
	res.model.sigmas[k * d * d + i * d + j] = fgmm_get_covar_smat(gmm->c_gmm,k)[i *d + j];
      }
    }
  }

  res.model.source_fid = source_fid;
  res.model.target_fid = target_fid;

  return true;
}


bool loadSRV(std_srvs::Empty::Request &req, std_srvs::Empty::Response &res)
{

  ROS_INFO("Loading parameters from running SEDS NODE.");

  ros::NodeHandle n;
  ros::ServiceClient client = n.serviceClient<seds::SedsModel>("/seds/params");
  seds::SedsModel srv;

  // make the call to seds for the parameters
  client.call(srv);

  // now extract the parameters for the gmm!
  dimX = srv.response.model.dim;
  int dim = srv.response.model.dim * 2;
  int nbClusters = srv.response.model.ncomp;
  dT = srv.response.model.dT;

  endpoint.resize(dim);
  for(int i = 0; i < dim; i++){
    endpoint[i] = srv.response.model.offset[i];
  }

  ROS_INFO("Using endpoint %d: %f %f %f %f %f %f", dim/2, endpoint[0], endpoint[1], endpoint[2], endpoint[3], endpoint[4], endpoint[5]); // THis is the endpoint, or target?!!!
  ROS_INFO("Using dT: %f", dT);

  if (gmm != NULL)
    delete gmm;

  gmm = new Gmm(nbClusters,dim);

  // and we copy the values back to the source
  float *mu = new float[dim];
  float *sigma = new float[dim*dim];

  for(int k = 0; k < nbClusters; k++){
    for (int i = 0; i < dim; i++){
      mu[i] = srv.response.model.mus[k * dim + i];
      for (int j = 0; j < dim; j++){
	sigma[i * dim + j] = srv.response.model.sigmas[k * dim * dim + i * dim + j];
      }
    }
    fgmm_set_prior(gmm->c_gmm, k, srv.response.model.priors[k]);
    fgmm_set_mean(gmm->c_gmm, k, mu);
    fgmm_set_covar(gmm->c_gmm, k, sigma);
  }

  delete [] sigma;
  delete [] mu;

  source_fid = srv.response.model.source_fid;
  target_fid = srv.response.model.target_fid;
  gmm->initRegression(dim/2);

  return true;
}

bool isLoadedSRV(seds::DSLoaded::Request &req, seds::DSLoaded::Response &res){

  if (gmm == NULL){
    res.loaded = false;
  } else {
    res.loaded = true;
  }

  return true;
}

bool dsSRV(seds::DSSrv::Request &req, seds::DSSrv::Response &res){ // dssrv request is x, dssrv response is dx

  // compute next move

  if (gmm == NULL){
    ROS_INFO("Gmm not initialized! Call load model first!");
    return true;
  }

  int dim = req.x.size();
  res.dx.resize(dim);

  float *x = new float[dim];
  float *velocity = new float[dim];
  float *sigma = new float[dim*(dim+1)/2];

  for(int i = 0; i < dim; i++){
    x[i] = (req.x[i] - endpoint[i])* 1000.f; // offset and scale values 
    //THIS IS WHERE THE MAGIC HAPPENS!!! THE CURRENT POSITION IS SUBTRACTED FROM THE ENDPOINT AND THEN GIVEN TO SEDS FOR REGRESSION
    //THEREFORE THE TARGET IS ALWAYS ORIGIN. 
  }

  ROS_DEBUG("Performing regression using SEDS parameters!");

  gmm->doRegression(x, velocity, sigma); // use the offseted x for performing regressions. 

  for(int i = 0; i < dim; i++){
    res.dx[i] = velocity[i] / 1000.f; // the dx value should not change. 
  }

  delete [] x;
  delete [] velocity;
  delete [] sigma;

  return true;
}

bool setEndPointSRV(seds::DSEndPoint::Request &req, seds::DSEndPoint::Response &res) // the perception pipeline should use this service to set the target position AFTER the model has been loaded. This will override the endpoint 
// retreived from the model. If target tracking has to be implement, a publisher subcriber model might be better. But in a general scenario, this will happen at the outset and will not be called again. 
{
  int len = req.x.size(); // for the model to work the endpoint is [x, dx]. but for the endpoint dx vector is 0. therefore input to this service can be only x. and 0's can be appended

  if(len != dimX)
  {
    ROS_INFO("the length of the new end point should be same as the dimensionality of the space");
    return false;
  }

  for(int i=0; i<len; i++)
  {
    endpoint[i] = req.x[i];
  }

  for(int i=len; i<len+len; i++)
  {
    endpoint[i] = 0; // this is dx part of the endpoint vector. which is always zero 
  }
  // ROS_INFO("The length of input array is %d", len);  
  ROS_INFO("Using endpoint %d: %f %f %f %f %f %f", len, endpoint[0], endpoint[1], endpoint[2], endpoint[3], endpoint[4], endpoint[5]); 
  ROS_INFO("Updating the endpoint in the driver node");
  
  // if(ros::service::waitForService("/mico_driver_cart/setendpoint"))
  // {
    ROS_INFO("before srv call");
    ros::NodeHandle n;
    ros::ServiceClient client = n.serviceClient<seds::DSEndPoint>("/mico_driver_cart/setendpoint");
    seds::DSEndPoint EP;
    // seds::DSEndPoint::Response resEP;
    EP.request.x.resize(req.x.size());
    for(int i=0; i<req.x.size(); i++)
    {
      EP.request.x[i] = req.x[i]; // only concerned about the the x component (6d) and no the dx!
    }
    client.call(EP);
    ROS_INFO("After srv call");
  // }
  return true;
}


int main(int argc, char **argv)
{
  ros::init(argc, argv, "ds_server");
  ros::NodeHandle n;
  string currns = n.getNamespace();
  ros::ServiceServer load_model_service = n.advertiseService(currns + "/ds_node/load_model", loadSRV);
  ros::ServiceServer load_file_service = n.advertiseService(currns + "/ds_node/load_file", loadFileSRV);
  ros::ServiceServer load_matlab_file_service = n.advertiseService(currns + "/ds_node/load_matlab_file", loadMatlabFileSRV);
  ros::ServiceServer ds_service = n.advertiseService(currns + "/ds_node/ds_server", dsSRV);
  ros::ServiceServer ds_loaded = n.advertiseService(currns + "/ds_node/is_loaded", isLoadedSRV);
  ros::ServiceServer ds_params = n.advertiseService(currns + "/ds_node/params", getParamsSRV);
  ros::ServiceServer ds_endpoint = n.advertiseService(currns + "/ds_node/endpoint", setEndPointSRV);

  ROS_INFO("Ready to control.");
  ros::spin();

  return 0;
}
