#include "SedsObstacle.h"
#include <stdlib.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

SedsObstacle::SedsObstacle(int exponent)
{
	m_dim = 3; //3 dimensional objects?!
	m_numPartitions = 1; // symmetrical object, no different shapes for different ranges
	m_Exponent = exponent;
}

void SedsObstacle::initialize_values(geometry_msgs::Vector3 origin, float radius)
{
	m_x0 = Vector(m_dim);
	m_x0(0)  = origin.x; m_x0(1) = origin.y; m_x0(2) = origin.z;


	m_a = Matrix(m_dim, m_numPartitions); // this is column vector for s[pheres, because num of partitions is 1]
	for (int i = 0; i < m_numPartitions; i++)
	{
		m_a.SetColumn(radius, i); // set the axis lengths for each partition. num partitions = 1 for spheres. 
	}

	m_xt = Vector(m_dim);
	m_xt.Zero();

	m_p = Matrix(m_dim, m_numPartitions);
	for (int i = 0; i < m_numPartitions; i++)
	{
		m_p.SetColumn(m_Exponent, i); // for sphere exponent is always going to be 1. 2^1
	}

	m_sf = Vector(m_dim);
	m_sf.One(); // set safety params to 1.
	// m_sf = m_sf*1.0; 

	m_thr = Vector(m_dim);
	m_thr.Zero(); //no rotation with respect to the axis. 

	m_partition = Matrix(m_numPartitions, 2); // 2 columns because, start and end angle for each partition
	for (int i = 0; i < m_numPartitions; i++)
	{
		m_partition(i,0) = -M_PI;
		m_partition(i,1) = M_PI;
	}


	if(m_dim == 3)
	{
		m_E = Matrix(m_dim, m_dim+1, true); // all elements are zero
	}
	else
	{
		m_E = Matrix(m_dim, m_dim, true);
	}

	m_Gamma = 1.0;
	
	m_R = Matrix(m_dim, m_dim); // no rotation involved. so keep rotation matrix to be identity. in general use th_r to computer the rotation matrix. 
	m_R.Identity();

}

bool SedsObstacle::compute_basis_matrix(Vector &robotPosition)
{

	m_xt = (m_R.Transpose())*(robotPosition - m_x0); // Just to be consistent with matlab code. m_R is identity for all almost all cases
	int ind = 0; // no partition. matlab ind = 1. because matlab is 1 indexed c++ is 0 indexed. 
	Vector a = Vector(m_dim); // following same variable names as in matlab code. 
	a = m_a.GetColumn(ind);

	a = a^m_sf;
	// ROS_INFO("Vector A");
	// a.Print();
	Vector p = Vector(m_dim);
	p = m_p.GetColumn(ind);
	// ROS_INFO("Vector p");
	// p.Print();

	Vector t1 = Vector(m_dim); // temp vectors for ease of calculation
	t1 = m_xt/a;
	// ROS_INFO("vector t1");
	// t1.Print();
	Vector t2 = Vector(m_dim);
	t2 = p*2;
	Vector t3 = Vector(3);
	t1.PExp(t2-1, t3);

	// Gamma = sum((x_t./a).^(2*p));
	Vector r = Vector(m_dim);
	(t1).PExp(t2, r); // Custom element wise exponetation function in Mathlib
	m_Gamma = r.Sum();
	
	// nv = (2*p.*(x_t./a).^(2*p - 1))./a; %normal vector of the tangential hyper-plane
	Vector nv = Vector(m_dim);
	nv = (t2^t3)/a;

	//Now that we have nv we can compute the eignevector matrix. for the hyperplane
// 	E = zeros(d,d);
// E(:,1) = nv;
// E(1,2:d) = nv(2:d)';
// E(2:d,2:d) = -eye(d-1)*nv(1);

// if d == 3
//     E(:,end+1) = [0;-nv(3);nv(2)];
// end

	m_E.Zero();
	m_E.SetColumn(nv, 0);
	for (int i = 1; i < m_dim; ++i)
	{
		m_E(0,i) = nv(i);
	}
	MathLib::Matrix Eye = Matrix(m_dim-1,m_dim-1);
	Eye.Identity(); //Identity matrix of size 2 by 2
	Eye = Eye*nv(0);
	// Eye.Print();
	for (int i = 1; i < m_dim; ++i)
	{
		for (int j = 1; j < m_dim; ++j)
		{
			m_E(i,j) = Eye(i-1,j-1);
			m_E(i,j) = -m_E(i,j);
		}
	}
	// ROS_INFO("E Matrix");
	if(m_dim == 3) //which is always the case in the mico case
	{
		m_E(0,3) = 0; m_E(1,3) = -nv(2); m_E(2,3) = nv(1);
	}
	// m_E.Print();
	return true;
}

bool SedsObstacle::transformE()
{
	m_E = m_R*m_E;
	return true;
}