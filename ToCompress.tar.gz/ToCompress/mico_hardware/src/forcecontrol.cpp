#include <ros/ros.h>
#include <ros/console.h>
#include "std_msgs/String.h"
#include <iostream>
#include <sstream>

// libkindrv
#include <libkindrv/types.h>
#include <libkindrv/kindrv.h>

using namespace KinDrv;

int main(int argc, char* argv[])
{
	ROS_INFO_STREAM("Starting force _control");
	ros::init(argc, argv, "force_control");
	 // explicitly initialize a libusb context
  KinDrv::init_usb();

  printf("Create a JacoArm \n");
  JacoArm *arm;
  try {
    arm = new JacoArm();
    } catch( KinDrvException &e ) {
      printf("error %i: %s \n", e.error(), e.what());
      return 0;
    }

  arm->start_force_ctrl();

}




// #include <MicoRobot.h>
// #include <iostream>
// #include "std_msgs/String.h"
// #include <ros/rate.h>
// #include <sstream>


// int main(int argc, char* argv[])
// {
//     ROS_INFO_STREAM("Starting force control");
//     ros::init(argc, argv, "force_control");
//     ros::NodeHandle nh;

//     MicoRobot robot(nh);
//     // controller_manager::ControllerManager cm(&robot);
//     robot.startforcecontrol();
//     // bool forceflag = 0;
//     // ros::Rate controlRate(100.0);
//     // while(ros::ok())
//     // {
//     // 	if(forceflag == 0)
//     // 	{
//     // 		robot.startforcecontrol();
//     // 		forceflag = 1;
//     // 	}
//     // 	controlRate.sleep();
//     // }
//     return 0;
// }
