#!/usr/bin/env python
import rospy
import numpy as np
from sensor_msgs.msg import Joy
from std_msgs.msg import Float32MultiArray, Float32
from std_msgs.msg import MultiArrayDimension
import matplotlib.pyplot as plt
from geometry_msgs.msg import Twist


# pub = rospy.Publisher('/control_input_bmi', Float32MultiArray)
pub1 = rospy.Publisher('/cmd', Twist)

def receive(msg):
  
  
  cmd = Twist()
  cmd.linear.x=msg.buttons[0]
  cmd.linear.y=msg.buttons[1]  
  
  print 'robot: ', msg.buttons[0]
  print 'switch: ', msg.buttons[1]
  print '------------------------------------'

  pub1.publish(cmd)

if __name__ == '__main__':
  rospy.init_node('mapdata')
  print "Mapdata started...."
  
  rospy.Subscriber('joy', Joy, receive)
  #pub = rospy.Publisher('/control_input', Float32MultiArray)
  rospy.spin()
