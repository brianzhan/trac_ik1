#include <openrave/plugin.h>
#include <or_rosrobot/ros_controller.h>
//#include <or_rosrobot/ros_traj_controller.h>
//#include <or_rosrobot/ros_vel_controller.h>

void GetPluginAttributesValidated(OpenRAVE::PLUGININFO &info)
{ 
    info.interfacenames[OpenRAVE::PT_Controller].push_back("ROSController");
}

OpenRAVE::InterfaceBasePtr CreateInterfaceValidated(OpenRAVE::InterfaceType type,
    std::string const &interface_name, 
    std::istream &sinput, 
    OpenRAVE::EnvironmentBasePtr env)
{

    if (type == OpenRAVE::PT_Controller && 
            interface_name == "roscontroller")
{
        std::string node_name, ns;
        sinput >> node_name >> ns;
        
        // Initialize the ROS node.
        RAVELOG_DEBUG("name = %s  namespace = %s\n", 
                node_name.c_str(), 
                ns.c_str());
        if (sinput.fail()) {
            RAVELOG_ERROR( "Controller %s is missing the node_name and/or "
                    "owd_namespace parameter(s).\n", interface_name.c_str());
            return OpenRAVE::InterfaceBasePtr();
        }
        
        // optional: no_sigint (pass 1 to enable)
        bool no_sigint;
        sinput >> no_sigint;
        if (sinput.fail())
            no_sigint = false;

        if (!ros::isInitialized()) {
            int argc = 0;
            ros::init(
                    argc,
                    NULL,
                    node_name,
                    ros::init_options::AnonymousName
                        | (no_sigint?ros::init_options::NoSigintHandler:0));
            RAVELOG_DEBUG("Starting ROS node '%s'.\n", node_name.c_str());
        } else {
            RAVELOG_DEBUG("Using existing ROS node '%s'\n", 
                    ros::this_node::getName().c_str());
        }
            return boost::make_shared<or_r2::ROSController>(env, ns);
    }
    else {
    return OpenRAVE::InterfaceBasePtr();
    }
}

OPENRAVE_PLUGIN_API void DestroyPlugin()
{
}
