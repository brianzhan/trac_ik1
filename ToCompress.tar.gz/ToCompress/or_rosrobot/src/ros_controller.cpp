#include <boost/foreach.hpp>
#include <boost/range/combine.hpp>
#include <boost/tuple/tuple.hpp>
#include <boost/algorithm/string/join.hpp>
#include <boost/range/adaptor/map.hpp>
#include <boost/range/adaptor/transformed.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/typeof/typeof.hpp>
#include "or_rosrobot/ros_controller.h"



using actionlib_msgs::GoalStatusArray;

namespace or_r2 {

ROSController::ROSController(OpenRAVE::EnvironmentBasePtr env,
                           std::string const &ns)
    : OpenRAVE::ControllerBase(env)
    , initialized_(false)
    , namespace_(ns)
    , timeout_(0.5) // seconds
{
    using OpenRAVE::openrave_exception;

    if (!env) {
        throw openrave_exception("Environment is NULL.",
                                 OpenRAVE::ORE_InvalidArguments);
    } else if (!ros::isInitialized()) {
        throw openrave_exception("ROS is not initialized. Have you started a"
                                 " ROS node in this process?",
                                 OpenRAVE::ORE_NotInitialized);
    }


    //RAVELOG_WARN("hello from ROSController!");
    //std::cout<< "***********8hello from ROSController!************8" << std::endl;
    nh_.setCallbackQueue(&queue_);
    //originator_ = ros::this_node::getName();
    originator_ = "user";
}

OpenRAVE::RobotBasePtr ROSController::GetRobot() const
{
    CheckInitialized();
    return robot_;
}

std::vector<int> const &ROSController::GetControlDOFIndices() const
{
    CheckInitialized();
    return dof_indices_;
}

int ROSController::IsControlTransformation() const
{
    CheckInitialized();
    return 0;
}

bool ROSController::Init(OpenRAVE::RobotBasePtr robot,
                        std::vector<int> const &dof_indices,
                        int ctrl_transform)
{
    using sensor_msgs::JointState;
    using OpenRAVE::openrave_exception;
    typedef OpenRAVE::KinBody::JointPtr JointPtr;

    if (initialized_) {
        throw openrave_exception("This controller has already been initialized.",
                                 OpenRAVE::ORE_InvalidState);
    }
    else if (ctrl_transform != 0) {
        throw openrave_exception("This contr#ADD8E6oller does not support affine DOFs.",
                                 OpenRAVE::ORE_InvalidArguments);
    } else if (!robot) {
        throw openrave_exception("Robot is NULL.",
                                 OpenRAVE::ORE_InvalidArguments);
    }

    ros::Time::waitForValid();

    robot_ = robot;
    dof_indices_ = dof_indices;
    dof_map_.clear();
    robot->GetDOFValues(joint_values_);

    // Build a mapping from joint names to DOF indices. This will be used to
    // decode JointState messages.
    DOF dof;
    for (dof.sparse_index = 0;
         dof.sparse_index < static_cast<int>(dof_indices.size());
         ++dof.sparse_index)
    {
        dof.full_index = dof_indices[dof.sparse_index];
        JointPtr const joint = robot_->GetJointFromDOFIndex(dof.full_index);
        std::string const joint_name = joint->GetName();

        BOOST_AUTO(result, dof_map_.insert(std::make_pair(joint_name, dof)));
        if (!result.second) {
            throw OPENRAVE_EXCEPTION_FORMAT("Duplicate DOF index %d.",
                        dof.full_index, OpenRAVE::ORE_InvalidArguments);
        }
        RAVELOG_DEBUG("Joint[%s] -> DOF %d\n", joint_name.c_str(), dof.full_index);
    }

    // Setup ROS publishers and subscribers to communicate with the hardware.
    ros::NodeHandle nh_namespace(nh_, namespace_);
   sub_jointstate_ = nh_namespace.subscribe("joint_states", 1,
           &ROSController::JointStateCallback, this);

    pub_traj_joint_ = nh_namespace.advertise<trajectory_msgs::JointTrajectory>(
            "traj_controller/command", 10);
            
	// initializing velocity controller
	typedef std::pair<std::string const, DOF> DOFEntry;
    BOOST_FOREACH (int index, dof_indices_) {
        OpenRAVE::KinBody::JointPtr const joint = robot_->GetJointFromDOFIndex(index);
        std::string const joint_name = joint->GetName();
        
        pub_joint_vels_.push_back(nh_namespace.advertise<std_msgs::Float64>(
                    "vel_" + joint_name + "_controller/command", 10));
    }

    // Wait for the first JointState message.
    // TODO: Also wait for the arbiter.
    ros::Time const start_time = ros::Time::now();
    ros::Rate poll_rate(50);

    RAVELOG_DEBUG("Waiting %.3f seconds for initial joint values.\n", timeout_.toSec());
    for (ros::Time now = start_time;
         now - start_time <= timeout_;
         now = ros::Time::now())
    {
        queue_.callAvailable();
        // TODO: Break out early if we're fully initialized.
    }

    // Verify that all joints were initialized.
    bool joints_initialized = true;
    typedef std::pair<std::string const, DOF> DOFEntry;
    BOOST_FOREACH (DOFEntry const &entry, dof_map_) {
        std::string const &joint_name = entry.first;
        DOF const &dof_index = entry.second;

        if (dof_index.stamp.isZero()) {
            RAVELOG_WARN("Joint '%s' was not initialized within %.3f seconds.\n",
                         joint_name.c_str(), timeout_.toSec());
            joints_initialized = false;
        } else {
            RAVELOG_DEBUG("Received update for joint '%s' at %f.\n",
                          joint_name.c_str(), dof_index.stamp.toSec());
        }
    }

    if (!joints_initialized) {
        throw openrave_exception("Did not receive a JointState message for one or more joints.",
                                 OpenRAVE::ORE_Timeout);
    }
    
    //initialize client to service SwitchController
    client_switch_controller_ = nh_.serviceClient<controller_manager_msgs::SwitchController>("controller_manager/switch_controller");
	std::string vel0 = "velocity_joint_mode_controller";
	std::string vel1 = "vel_j1_controller";
	std::string vel2 = "vel_j2_controller";
	std::string vel3 = "vel_j3_controller";
	std::string vel4 = "vel_j4_controller";
	std::string vel5 = "vel_j5_controller";
	std::string vel6 = "vel_j6_controller";
	std::string vel7 = "vel_f1_controller";
	std::string vel8 = "vel_f2_controller";
	name_vel_controllers.push_back(vel0);
    name_vel_controllers.push_back(vel1);
	name_vel_controllers.push_back(vel2);
	name_vel_controllers.push_back(vel3);
	name_vel_controllers.push_back(vel4);
	name_vel_controllers.push_back(vel5);
	name_vel_controllers.push_back(vel6);
    name_vel_controllers.push_back(vel7);
	name_vel_controllers.push_back(vel8);

    //RAVELOG_WARN("hello from ROSController Init!");

	std::string traj0 = "traj_controller";
	name_traj_controllers.push_back(traj0);
	//name_traj_controllers.push_back(traj1);
	
	//std::string pos0 = "position_joint_mode_controller";
    std::string pos0 = "velocity_joint_mode_controller"; //change to see if I can get velocities
	name_traj_controllers.push_back(pos0);
	
	srv_switch_controller_.request.start_controllers = name_traj_controllers;
	srv_switch_controller_.request.stop_controllers = name_vel_controllers;
	srv_switch_controller_.request.strictness = 1;
	if (client_switch_controller_.call(srv_switch_controller_))
    {
		ROS_INFO("Response: %d", (long int)srv_switch_controller_.response.ok);
		current_mode  = ROSController::CONTROLLER_MODE_TRAJECTORY;
    }
    else
    {
		ROS_ERROR("Failed to call service SwitchController");
		current_mode = ROSController::CONTROLLER_MODE_UNKNOWN;
		return 1;
	}
	current_mode  = ROSController::CONTROLLER_MODE_TRAJECTORY;
	
    initialized_ = true;
    return true;
}


void ROSController::Reset(int options)
{
    CheckInitialized();
    // TODO: What should this do?
}

bool ROSController::IsDone()
{
    CheckInitialized();
    return !running_;
}

void ROSController::SimulationStep(OpenRAVE::dReal time_ellapsed)
{
    if (!initialized_) {
        return;
    }

    //std::cout<<"Hello from joint values! "<<std::endl;
    ros::Time const now = ros::Time::now();
    queue_.callAvailable();

    // Monitor the age of the joint values as a watchdog.
    typedef std::pair<std::string const, DOF> DOFEntry;
    BOOST_FOREACH (DOFEntry &entry, dof_map_) {
        std::string const &joint_name = entry.first;
        DOF &dof = entry.second;

        ros::Duration const age = now - dof.stamp;
        if (!dof.warned && age >= timeout_) {
            RAVELOG_WARN("Joint values for '%s' are out of date:"
                         " Have not received an update in %.3f seconds.\n",
                joint_name.c_str(), age.toSec()
            );
            dof.warned = true;
        }
    }
    
    // for(int ii = 0; ii < 8; ii++)
    // {
    //     RAVELOG_WARN("%.3f ",joint_values_[ii]);
    // }
    // RAVELOG_WARN("\n");
    //joint_values_[5] = joint_values_[5] + 0.5;
    // Update the KinBody's joint values.
    robot_->SetDOFValues(joint_values_, OpenRAVE::KinBody::CLA_Nothing, dof_indices_);
}

void ROSController::JointStateCallback(sensor_msgs::JointState const &msg_jointstate)
{
    if (msg_jointstate.name.size() != msg_jointstate.position.size()) {
        RAVELOG_WARN("Received JointState message with inconsistent data:"
                    " message contains %d names %d positions.\n",
                    msg_jointstate.position.size(),
            msg_jointstate.name.size()
        );
        return;
    }

    for (size_t ijoint = 0; ijoint < msg_jointstate.name.size(); ++ijoint) {
        std::string const &joint_name = msg_jointstate.name[ijoint];
        double const joint_position = msg_jointstate.position[ijoint];

        // Sanity check.
        if (!std::isfinite(joint_position)) {
            RAVELOG_WARN("Ignored NaN or infinity position for joint '%s'.\n",
                         joint_name.c_str());
            continue;
        }

        // Find the corresponding DOF index. If one does not exist, then we're
        // not controlling this joint and we can safely ignore its value.
        BOOST_AUTO(it, dof_map_.find(joint_name));
        if (it == dof_map_.end()) {
            continue;
        }

        // Store the joint value along with the current timestamp. This resets
        // the watchdog and clears any warning flags, which allows us to print
        // a new error message.
        DOF &dof_index = it->second;
        if (msg_jointstate.header.stamp < dof_index.stamp) {
            RAVELOG_WARN("Received outdated JointState message for joint '%s':"
                         "  Message timestamp %f predates update timestamp %f.\n",
                joint_name.c_str(), msg_jointstate.header.stamp.toSec(),
                dof_index.stamp.toSec()
            );
        }

        dof_index.warned = false;
        dof_index.stamp = msg_jointstate.header.stamp;
        joint_values_[dof_index.sparse_index] = joint_position;
    }
}

void ROSController::GetVelocity(std::vector<OpenRAVE::dReal> &velocities) const
{
    CheckInitialized();
    throw OpenRAVE::openrave_exception("GetVelocity is not yet implemented.",
                                       OpenRAVE::ORE_NotImplemented);
}

bool ROSController::SetDesired(std::vector<OpenRAVE::dReal> const &values,
                              OpenRAVE::TransformConstPtr transform)
{
	using OpenRAVE::openrave_exception;

    CheckInitialized();

    if (values.size() != pub_joint_vels_.size()) {
        RAVELOG_WARN(
                "Did not send message with the right number of joint "
                "velocities. Expected %d, got %d.\n",
                pub_joint_vels_.size(),
                values.size());
        return false;
    }

     if(current_mode != ROSController::CONTROLLER_MODE_VELOCITY){
		srv_switch_controller_.request.start_controllers = name_vel_controllers;
		srv_switch_controller_.request.stop_controllers = name_traj_controllers;
		srv_switch_controller_.request.strictness = 1;
		if (client_switch_controller_.call(srv_switch_controller_))
		{
			ROS_INFO("Response: %d", (long int)srv_switch_controller_.response.ok);
			current_mode  = ROSController::CONTROLLER_MODE_VELOCITY;
		}
		else
		{
			ROS_ERROR("Failed to call service SwitchController");
			return 1;
		}
	}

    
    OpenRAVE::dReal value;
    ros::Publisher pub;

    BOOST_FOREACH (boost::tie(value, pub), boost::combine(values, pub_joint_vels_))
    {
        std_msgs::Float64 msg;
        msg.data = value;
        //if(value>0)
        //std::cout<< "message data" << msg.data << "|";
        pub.publish(msg);
    }
    //std::endl;
    //std::endl;`

    return true;
}

bool ROSController::SetPath(OpenRAVE::TrajectoryBaseConstPtr traj)
{
    using OpenRAVE::ConfigurationSpecification;
    using OpenRAVE::openrave_exception;

    // TODO: What exactly does the return code of this function mean?
    CheckInitialized();

    if (!traj) {
        throw openrave_exception("Trajectory is NULL.",
                                 OpenRAVE::ORE_InvalidArguments);
    } else if (traj->GetNumWaypoints() == 0) {
        RAVELOG_WARN("Skipped executing empty trajectory.\n");
        return false;
    }

   //LabeledJointTrajectoryPtr const joint_traj = CreateJointTrajectory(traj);  
   trajectory_msgs::JointTrajectoryPtr const joint_traj = CreateJointTrajectory(traj);
    if (joint_traj) {
        pending_id_ = joint_traj->header.frame_id;
        pub_traj_joint_.publish(joint_traj);
        RAVELOG_DEBUG("Published JointTrajectory with id '%s'.\n",
            pending_id_.c_str()
        );
        return true;
    }

    RAVELOG_DEBUG("Ignoring trajectory that does not contain joint positions"
                  " for the active DOFs.");
    return false;
}

    //LabeledJointTrajectoryPtr ROSController::CreateJointTrajectory(OpenRAVE::TrajectoryBaseConstPtr traj)
trajectory_msgs::JointTrajectoryPtr ROSController::CreateJointVelocities(OpenRAVE::TrajectoryBaseConstPtr traj)
{
    using OpenRAVE::ConfigurationSpecification;

    static OpenRAVE::dReal const NaN = std::numeric_limits<OpenRAVE::dReal>::quiet_NaN();
    ConfigurationSpecification const traj_cspec = traj->GetConfigurationSpecification();


    std::vector<int> const velocity_indices = GetJointIndices(traj, 1);
    
    RAVELOG_DEBUG("Trajectory velocities for DOFs: %s\n",
    FormatDOFIndices(velocity_indices).c_str());
    
    //for now assume only one waypoint and values for all joints 
    //TODO check for velocities for multiple joints! 
    std::vector<OpenRAVE::dReal> waypoint;
    size_t const msg_dof = velocity_indices.size();

    traj->GetWaypoint(0, waypoint);    
    std::vector<OpenRAVE::dReal> qd(msg_dof, NaN);
    traj_cspec.ExtractJointValues(qd.begin(), waypoint.begin(),
                    OpenRAVE::KinBodyPtr(), velocity_indices, 1);
    
    RAVELOG_DEBUG("Trajectory contains velocities: %f %f %f %f %f %f %f %f\n",qd.at(0),qd.at(1),qd.at(2),
    qd.at(3),qd.at(4),qd.at(5),qd.at(6),qd.at(7));

	//switch controllers
	if(current_mode != ROSController::CONTROLLER_MODE_VELOCITY){
		srv_switch_controller_.request.start_controllers = name_vel_controllers;
		srv_switch_controller_.request.stop_controllers = name_traj_controllers;
		srv_switch_controller_.request.strictness = 1;
		if (client_switch_controller_.call(srv_switch_controller_))
		{
			ROS_INFO("Response: %d", (long int)srv_switch_controller_.response.ok);
			current_mode  = ROSController::CONTROLLER_MODE_VELOCITY;
		}
		else
		{
			ROS_ERROR("Failed to call service SwitchController");
			return trajectory_msgs::JointTrajectoryPtr();
		}
	}


    
    OpenRAVE::dReal value;
    ros::Publisher pub;



    BOOST_FOREACH (boost::tie(value, pub), boost::combine(qd, pub_joint_vels_))
    {
        std_msgs::Float64 msg;
        msg.data = value;
        pub.publish(msg);
    }
    //ros::spinOnce();
    //pub.sleep();
    return trajectory_msgs::JointTrajectoryPtr();
    
}


trajectory_msgs::JointTrajectoryPtr ROSController::CreateJointTrajectory(OpenRAVE::TrajectoryBaseConstPtr traj)
{
    using boost::adaptors::map_values;
    using boost::adaptors::transformed;
    using boost::algorithm::join;
    using boost::lexical_cast;
    using OpenRAVE::ConfigurationSpecification;

    static OpenRAVE::dReal const NaN = std::numeric_limits<OpenRAVE::dReal>::quiet_NaN();

    CheckInitialized();
    
    BOOST_ASSERT(traj);


    // Determine which DOFs are inside the trajectory.
    std::vector<int> const position_indices = GetJointIndices(traj, 0);
    std::vector<int> const velocity_indices = GetJointIndices(traj, 1);
    std::vector<int> const acceleration_indices = GetJointIndices(traj, 2);

    if (position_indices.empty()) {
      RAVELOG_DEBUG("Trajectory cdoes not containt joint positions for any of our controlled DOFS"
      " moving onto velocity check");
      if(velocity_indices.empty()){
			      RAVELOG_DEBUG("Trajectory cdoes not containt joint velocities and positions for any of our controlled DOFS."
				 "Skipping execution!");
				return trajectory_msgs::JointTrajectoryPtr();
	  }
	  else{
			     RAVELOG_DEBUG("Trajectory contains velocities only. Switching to velocity controller.");
			     return CreateJointVelocities(traj);
	
	  }

    }

	RAVELOG_DEBUG("Starting trajectory controller.");
	if(current_mode != ROSController::CONTROLLER_MODE_TRAJECTORY){	
		srv_switch_controller_.request.start_controllers = name_traj_controllers;
		srv_switch_controller_.request.stop_controllers = name_vel_controllers;
		srv_switch_controller_.request.strictness = 1;
		if (client_switch_controller_.call(srv_switch_controller_))
		{
			ROS_INFO("Response: %d", (long int)srv_switch_controller_.response.ok);
			current_mode  = ROSController::CONTROLLER_MODE_TRAJECTORY;
		}
		else
		{
			ROS_ERROR("Failed to call service SwitchController");
			return CreateJointVelocities(traj);
		}
	}

    size_t const num_dof = dof_indices_.size();
    size_t const num_waypoints = traj->GetNumWaypoints();
    ConfigurationSpecification const traj_cspec = traj->GetConfigurationSpecification();

    trajectory_msgs::JointTrajectoryPtr msg_traj = 
        boost::make_shared<trajectory_msgs::JointTrajectory>();
    msg_traj->header.stamp = ros::Time::now();

    // TODO: Verify that the trajectory has a deltatime group.


    RAVELOG_DEBUG("Trajectory contains positions for DOFs: %s\n",
        FormatDOFIndices(position_indices).c_str());
    RAVELOG_DEBUG("Trajectory velocities for DOFs: %s\n",
        FormatDOFIndices(velocity_indices).c_str());
    RAVELOG_DEBUG("Trajectory accelerations for DOFs: %s\n",
        FormatDOFIndices(acceleration_indices).c_str());

    // Generate a list of joint names included in the trajectory.
    std::map<int, std::string> dof_names;
    BOOST_FOREACH (int const dof_index, position_indices) {
        typedef OpenRAVE::KinBody::JointPtr JointPtr;
        JointPtr const joint = robot_->GetJointFromDOFIndex(dof_index);
        std::string const joint_name = joint->GetName();

        msg_traj->joint_names.push_back(joint_name);
        BOOST_AUTO(it, dof_names.insert(std::make_pair(dof_index, joint_name)));
        BOOST_ASSERT(it.second);
    }
    RAVELOG_DEBUG("Trajectory contains joints: %s\n",
        join(dof_names | map_values, " ").c_str());

    // Velocities are only supported on joints that also have positions.
    bool has_velocities = !velocity_indices.empty();
    std::vector<int> invalid_velocities;
    std::set_difference(velocity_indices.begin(), velocity_indices.end(),
                        position_indices.begin(), position_indices.end(),
                        std::back_inserter(invalid_velocities));
    if (!invalid_velocities.empty()) {
        RAVELOG_WARN("Velocities are being ignored for DOFs that do not"
                     " specify positions: %s\n",
            FormatDOFIndices(invalid_velocities).c_str()
        );
        has_velocities = false;
    } else if (!velocity_indices.empty() && velocity_indices != position_indices) {
        std::vector<int> missing_velocities;
        std::set_difference(position_indices.begin(), position_indices.end(),
                            velocity_indices.begin(), velocity_indices.end(),
                            std::back_inserter(missing_velocities));

        RAVELOG_WARN("Velocities are being ignored because some DOFs"
                     " are missing values: %s\n",
            FormatDOFIndices(missing_velocities).c_str()
        );
        has_velocities = false;
    }

    // Accelerations are only supported on joints that have both positions and
    // velocities.
    bool has_accelerations = !acceleration_indices.empty();
    std::vector<int> invalid_accelerations;
    std::set_difference(acceleration_indices.begin(), acceleration_indices.end(),
                        position_indices.begin(), position_indices.end(),
                        std::back_inserter(invalid_accelerations));
    std::set_difference(acceleration_indices.begin(), acceleration_indices.end(),
                        velocity_indices.begin(), velocity_indices.end(),
                        std::back_inserter(invalid_accelerations));
    if (!invalid_accelerations.empty()) {
        RAVELOG_WARN("Accelerations are being ignored for DOFs that do not"
                     " specify both positions and velocities: %s\n",
            FormatDOFIndices(invalid_accelerations).c_str()
        );
        has_accelerations = false;
    } else if (!acceleration_indices.empty() && acceleration_indices != velocity_indices) {
        std::vector<int> missing_accelerations;
        std::set_difference(position_indices.begin(), position_indices.end(),
                            acceleration_indices.begin(), acceleration_indices.end(),
                            std::back_inserter(missing_accelerations));

        RAVELOG_WARN("Accelerations are being ignored because some DOFs"
                     " are missing values: %s\n",
            FormatDOFIndices(missing_accelerations).c_str()
        );
        has_accelerations = false;
    }

    RAVELOG_DEBUG("Creating JointTrajectory containing %d of %d controlled DOFs"
                  " with position=1, velocity=%d, and acceleration=%d.\n",
        position_indices.size(), dof_indices_.size(), has_velocities, has_accelerations
    );

    // Convert the waypoints to the ROS message format. We fill the output
    // arrays with NaNs to make it obvious if we've missed any elements while
    // running a sanity check on the resulting trajectory.
    size_t const msg_dof = position_indices.size();
    double time_from_start = 0.0;
    std::vector<OpenRAVE::dReal> prev_waypoint;
    for (size_t iwaypoint = 0; iwaypoint < num_waypoints; ++iwaypoint) {
        trajectory_msgs::JointTrajectoryPoint msg_waypoint;
        std::vector<OpenRAVE::dReal> waypoint;
        traj->GetWaypoint(iwaypoint, waypoint);

        // Time from start.
        OpenRAVE::dReal deltatime = NaN;
        traj_cspec.ExtractDeltaTime(deltatime, waypoint.begin());

         std::vector<OpenRAVE::dReal> prev_waypoint = waypoint;
        //check for waypoints with identical times, if not equal throw an error else disregard
        using OpenRAVE::openrave_exception;
        if((deltatime <1e-10)&&(iwaypoint>0))
        {
            if(std::equal(waypoint.begin(), waypoint.begin() + waypoint.size(), prev_waypoint.begin())){
                RAVELOG_WARN("Identical waypoints detected. Ignoring waypoint %d", iwaypoint);
               continue;
            }
            else{
                throw openrave_exception("Different points with identical timings detected!", OpenRAVE::ORE_InvalidArguments);
            }
        }
        prev_waypoint = waypoint;

        time_from_start += deltatime;
        msg_waypoint.time_from_start.fromSec(time_from_start);
        //RAVELOG_WARN(std::to_string(time_from_start));
  
        // Joint positions. Note that we use assign to handle the (potential)
        // conversion from OpenRAVE::dReal to float64. This is necessary when
        // OpenRAVE is built in 32-bit mode.
        {
            std::vector<OpenRAVE::dReal> q(msg_dof, NaN);
            traj_cspec.ExtractJointValues(q.begin(), waypoint.begin(),
                    OpenRAVE::KinBodyPtr(), position_indices, 0); 
            msg_waypoint.positions.assign(q.begin(), q.end());
        }

        // Joint velocities.
        if (has_velocities) {
            std::vector<OpenRAVE::dReal> qd(msg_dof, NaN);
            traj_cspec.ExtractJointValues(qd.begin(), waypoint.begin(),
                    OpenRAVE::KinBodyPtr(), position_indices, 1); 
            msg_waypoint.velocities.assign(qd.begin(), qd.end());
        }
        //msg_waypoint.velocities.assign(msg_dof, 0.0);

        // Joint accelerations.
        if (has_accelerations) {
            std::vector<OpenRAVE::dReal> qdd(msg_dof, NaN);
            traj_cspec.ExtractJointValues(qdd.begin(), waypoint.begin(),
                    OpenRAVE::KinBodyPtr(), position_indices, 2); 
            msg_waypoint.accelerations.assign(qdd.begin(), qdd.end());
        }
        msg_traj->points.push_back(msg_waypoint);
    }

    // Verify that the trajectory is valid (i.e. sanity checks).
    BOOST_ASSERT(msg_traj->header.stamp.isValid());
    BOOST_ASSERT(msg_traj->joint_names.size() == msg_dof);

    BOOST_FOREACH (trajectory_msgs::JointTrajectoryPoint const &msg_waypoint, msg_traj->points) {
        BOOST_ASSERT(msg_waypoint.positions.size() == msg_dof);
        BOOST_ASSERT(msg_waypoint.velocities.empty()
                  || msg_waypoint.velocities.size() == msg_dof);
        BOOST_ASSERT(msg_waypoint.accelerations.empty()
                  || msg_waypoint.accelerations.size() == msg_dof);

        BOOST_ASSERT(std::all_of(msg_waypoint.positions.begin(),
                                 msg_waypoint.positions.end(),
                                 static_cast<bool(*)(double)>(std::isfinite)));
        BOOST_ASSERT(std::all_of(msg_waypoint.velocities.begin(),
                                 msg_waypoint.velocities.end(),
                                 static_cast<bool(*)(double)>(std::isfinite)));
        BOOST_ASSERT(std::all_of(msg_waypoint.accelerations.begin(),
                                 msg_waypoint.accelerations.end(),
                                 static_cast<bool(*)(double)>(std::isfinite)));
    }

    if (!msg_traj->points.empty()) {
        msg_traj->header.frame_id = GenerateID();
        return msg_traj;
    } else {
	RAVELOG_WARN("Suppressing empty trajectory. This may have caused a"
                     " SEGFAULT in Robodyn.\n");
        return trajectory_msgs::JointTrajectoryPtr();
    }
}


// void ROSController::GoalStatusCallback(actionlib_msgs::GoalStatusArray const &msg_goalstatus)
// {
//     for (actionlib_msgs::GoalStatus const &goal_status : msg_goalstatus.status_list) {
//         if (goal_status.goal_id.id == pending_id_) {
//             pending_id_ = "";
//             RAVELOG_DEBUG("Received status update of type %d for id '%s'.\n",
//                 goal_status.status, goal_status.goal_id.id.c_str()
//                 );
//         }
//         switch (goal_status.status) {
//             case actionlib_msgs::GoalStatus::ACTIVE:
//             running_ = true;
//             break;
//             case actionlib_msgs::GoalStatus::PREEMPTED:
//             case actionlib_msgs::GoalStatus::SUCCEEDED:
//             case actionlib_msgs::GoalStatus::ABORTED:
//             case actionlib_msgs::GoalStatus::REJECTED:
//             case actionlib_msgs::GoalStatus::RECALLED:
//             running_ = false;
//             break;
//             case actionlib_msgs::GoalStatus::PREEMPTING:
//             case actionlib_msgs::GoalStatus::RECALLING:
//             case actionlib_msgs::GoalStatus::PENDING:
//             break;
//             default:
//             RAVELOG_WARN("Unknown actionlib goal status %d.\n", goal_status.status);
//         }
//     }
// }


void ROSController::CheckInitialized() const
{
    using OpenRAVE::openrave_exception;

    if (!initialized_) {
        throw openrave_exception("Controller has not been initialized.",
                                 OpenRAVE::ORE_NotInitialized);
    }
}

std::string ROSController::FormatDOFIndices(std::vector<int> const &dof_indices) const
{
    using boost::adaptors::transformed;
    using boost::algorithm::join;
    using boost::lexical_cast;

    if (!dof_indices_.empty()) {
        return join(dof_indices | transformed(lexical_cast<std::string, int>), " ");
    } else {
        return "<none>";
    }
}

std::vector<int> ROSController::GetJointIndices(OpenRAVE::TrajectoryBaseConstPtr traj,
                                               int derivative) const
{
    using OpenRAVE::ConfigurationSpecification;

    BOOST_ASSERT(traj);
    BOOST_ASSERT(derivative >= 0);

    size_t const num_dof = dof_indices_.size();
    ConfigurationSpecification const traj_cspec = traj->GetConfigurationSpecification();

    // Copy the values from waypoint into values. This will set the
    // corresponding elements in values to one. Any values that remain
    // zero are not included in the trajectory.
    std::vector<OpenRAVE::dReal> waypoint(traj_cspec.GetDOF(), 1.0);
    std::vector<OpenRAVE::dReal> values(num_dof, 0.0);
    traj_cspec.ExtractJointValues(values.begin(), waypoint.begin(),
            OpenRAVE::KinBodyPtr(), dof_indices_, derivative); 

    std::vector<int> traj_dof_indices;
    for (size_t idof = 0; idof < num_dof; ++idof) {
        BOOST_ASSERT(values[idof] == 0.0 || values[idof] == 1.0);
        if (values[idof]) {
            traj_dof_indices.push_back(dof_indices_[idof]);
        }
    }
    return traj_dof_indices;
}

// Source: http://stackoverflow.com/questions/440133/how-do-i-create-a-random-alpha-numeric-string-in-c
std::string ROSController::GenerateID() const
{
    static size_t const length = 8;

    auto randchar = []() -> char
    {
        char const charset[] =
            "0123456789"
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
            "abcdefghijklmnopqrstuvwxyz";
        size_t const max_index = sizeof(charset) - 1;
        return charset[rand() % max_index];
    };

    std::string str(length, 0);
    std::generate_n(str.begin(), length, randchar);
    return str;
}


}
