#!/usr/bin/env python

import adapy
import math
import numpy as np
import openravepy
import prpy
import rospy
import scipy
import sys
import threading
import time
import random
import os

from datetime import datetime
from StringIO import StringIO
from IPython import embed
from TransformMatrix import *

numDofs = -1

def str2num(string):
    return array([float(s) for s in string.split()])


def ReadPosesFromFile(fileName):
    poses = []
    fp = open(fileName,'r')
    numPoses = len(poses)

    for line in fp:
      T = [[0 for x in xrange(4)] for x in xrange(4)] 
      line = line.strip()
      counter = 0
      for number in line.split():
        T[counter/4][counter%4] = float(number)
        #print T[counter/4][counter%4]
        counter = counter + 1
      poses.append(T)
       #print T[0][0]
    fp.close()
    return poses;

def ReadFromFile(errorsFileName, thetasFileName, timesFileName):
    with open(errorsFileName) as f:
       startErrors = map(float, f)
    with open(errorsFileName) as f:
       errors = map(float, f)
    with open(thetasFileName) as f:
       thetas = map(float, f)
    with open(timesFileName) as f:
       times = map(float, f)
    N = len(errors)
    
    smallerrors = []
    smallthetas = []
    smalltimes = []
    smallerrorindices = [i for i, [x,y] in enumerate(zip(errors,thetas)) if x > 1e-2 or np.absolute(y) > 20 ]
    smallerrors = []

    for indx in smallerrorindices:
        smallerrors.append(errors[indx])
        smallthetas.append(thetas[indx])
        smalltimes.append(times[indx])
        errors[indx] = -1
        times[indx] = 0
    ii = 0
    while (ii < N):
        if(ii < len(errors)):
          if errors[ii] == -1:
             errors.pop(ii)
             thetas.pop(ii)
             times.pop(ii)
          else:
              ii = ii + 1
        else:
            ii = ii + 1
        
    #embed()
    return errors, thetas, times, smallerrors, smallthetas, smalltimes

  

if __name__ == "__main__":

    filePath = os.path.abspath(os.path.join(os.path.join(os.path.realpath(__file__), os.pardir), os.pardir)) 

    print "Reading poses from file ... "
    fileName = filePath + '/data/poses.dat'
    poses = ReadPosesFromFile(fileName)


    file_err_name =   filePath + "/data/GeneralIKErrors.dat"
    file_thetas_name =  filePath + "/data/GeneralIKThetas.dat"

    file_time_name =    filePath + "/data/GeneralIKTimes.dat"
    errors, thetas, times, smallerrors, smallthetas, smalltimes = ReadFromFile(file_err_name, file_thetas_name, file_time_name)
    print 'average error for correct solution is:', sum(errors)/float(len(errors))
    print 'average thetas for correct solution is:', sum(thetas)/float(len(thetas))
    print 'average time for correct solution is: ', sum(times) / float(len(times))
    print 'number of success: ', len(errors)
    print 'success rate: ', float(len(errors))/float(len(errors)+len(smallerrors))
    print 'successs rate (debugging): ', float(len(thetas))/float(len(thetas) + len(smallthetas))
    print 'average error for failure is:', sum(smallerrors)/float(len(smallerrors))
    print 'average thetas for failure is:', sum(smallthetas)/float(len(smallthetas))
    print 'average time for failure is: ', sum(smalltimes) / float(len(smalltimes))