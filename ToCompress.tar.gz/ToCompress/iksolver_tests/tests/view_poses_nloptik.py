#!/usr/bin/env python

import adapy
import math
import numpy as np
import openravepy
import prpy
import rospy
import scipy
import sys
import threading
import time
import random
import os

from datetime import datetime
from StringIO import StringIO
from IPython import embed
from TransformMatrix import *

numDofs = -1
pi = np.math.pi

def str2num(string):
    return array([float(s) for s in string.split()])


def ReadPosesFromFile(fileName):
    poses = []
    fp = open(fileName,'r')
    numPoses = len(poses)

    for line in fp:
      T = [[0 for x in xrange(4)] for x in xrange(4)] 
      line = line.strip()
      counter = 0
      for number in line.split():
        T[counter/4][counter%4] = float(number)
        #print T[counter/4][counter%4]
        counter = counter + 1
      poses.append(T)
       #print T[0][0]
    fp.close()
    return poses;

def ReadFromFile(errorsFileName, timesFileName):
    with open(errorsFileName) as f:
       errors = map(float, f)
    with open(timesFileName) as f:
       times = map(float, f)
    smallerrors = []
    smalltimes = []
    smallthetas = []
    smallerrorindices = [i for i, x in enumerate(errors) if x > 1e-2]
    smallerrors = []
    for indx in smallerrorindices:
        smallerrors.append(errors[indx])
        smalltimes.append(times[indx])
        errors[indx] = 0
        times[indx] = 0
    for ii in range(len(errors)):
        if(ii < len(errors)):
          if errors[ii] == 0:
             errors.pop(ii)
             times.pop(ii)

    return errors, times, smallerrors, smalltimes

  
def TestPose(robot, manip, startValues, poses, poseIndx):
    numPoses = len(poses)
    errors = []
    times = [];
    #for kk in range(numPoses):

    targetPose = poses[poseIndx]
    manip.SetDOFValues(startValues)
    lPose = np.asarray(targetPose)
    tstart = datetime.now()
    #ik = manip.FindIKSolution(targetPose,  openravepy.IkFilterOptions.IgnoreJointLimits)
        
    #ik = str2num(probs_cbirrt.SendCommand('DoGeneralIK exec nummanips 1 maniptm 0 %s'%targetPose))
    #ik = str2num(probs_cbirrt.SendCommand('DoGeneralIK exec nummanips 1 maniptm 0 %s' %SerializeTransform(lPose)))

    ik = manip.FindIKSolution(lPose, 0)


    tend = datetime.now()
    dt = tend - tstart
    dt_micsec = dt.microseconds
    print 'time: ', time
    #print dt_msec
    manip.SetDOFValues(ik)
    newPose = manip.GetEndEffectorTransform()
 

    #test quaternion calculation
    quat_target = openravepy.quatFromRotationMatrix(targetPose)
    quat_curr = openravepy.quatFromRotationMatrix(newPose)
    quat_curr_wrt_targ = openravepy.quatMultiply(openravepy.quatInverse(quat_target),quat_curr)
    quat_curr_wrt_targ = quat_curr_wrt_targ/np.linalg.norm(quat_curr_wrt_targ)
    theta = 2*math.acos(quat_curr_wrt_targ[0])
    if(theta > pi):
      theta = -2*pi + theta

    if(theta < -pi):
      theta = 2*pi + theta


    #let's keep inverse angles as well
    if(theta > pi/2):
       theta = pi - theta
    if(theta < -pi/2):
       theta = pi + theta
    theta = theta * 180/pi
    print 'theta: ', theta, ' [deg]'
    #err = theta
    err = 0
    for tt in range(3):
        err = err + pow((targetPose[tt][3]-newPose[tt][3]),2)
    err = math.sqrt(err)
    print 'error: ', err
    return targetPose, err, theta;


if __name__ == "__main__":
    #rospy.init_node("adapy_supervisor")
    #s = Supervisor(sim=True, control = True, attach_viewer=True)
    #testik
    env, robot = adapy.initialize(sim=True, attach_viewer=True)
    #numDofs = robot.GetDOF();

    manip = robot.arm
    robot.SetActiveManipulator(manip)
    manip = robot.GetActiveManipulator()
    startValues = manip.GetDOFValues()

    filePath = os.path.abspath(os.path.join(os.path.join(os.path.realpath(__file__), os.pardir), os.pardir)) 

    print "Reading poses from file ... "
    fileName = filePath + '/data/poses.dat'
    poses = ReadPosesFromFile(fileName)
        
    
    #iksolver = openravepy.RaveCreateIkSolver(env,"NloptIK")
    #manip.SetIkSolver(iksolver)
    iksolver = openravepy.RaveCreateIkSolver(env,"NloptIK");
    #embed()
    manip.SetIKSolver(iksolver)
    #embed()
    #iksolver.Init(manip)
    print 'active manipulator: ', robot.GetActiveManipulator()
    print 'iksolver: ', manip.GetIkSolver()
    #for kk in range(len(poses)):
    for kk in range(len(poses)):
       print kk
       targetPose, error, theta = TestPose(robot,manip,startValues,poses,kk)
       h  = openravepy.misc.DrawAxes(env,targetPose)
       raw_input("Press Enter to continue...")
      
       #if(error > 1e-3):
       # if(np.abs(theta) > 20) and (error <1e-2):
       #   print kk
       #   h  = openravepy.misc.DrawAxes(env,targetPose)
       #   raw_input("Press Enter to continue...")

    