#!/usr/bin/env python

import adapy
import math
import numpy as np
import openravepy
import prpy
import rospy
import scipy
import sys
import threading
import time
import random
import os

from StringIO import StringIO
from IPython import embed



numDofs = -1

def WritePosesToFile(poses, fileName):
    fp = open(fileName,'w')
    numPoses = len(poses)

    for pp in range(numPoses):
       for dd in range(4):
          for ii in range(4):
             fp.write(str(poses[pp][dd][ii]))
             fp.write('\t')

       fp.write('\n')
    fp.close()


def GeneratePoses(manip, robot, numPoses):
    limits_as = robot.GetDOFLimits();
    lower_limits_a = limits_as[0];
    upper_limits_a = limits_as[1];
    
    for i in range(numDofs):
      lower_limits_a[i] = max(lower_limits_a[i],-math.pi)
      upper_limits_a[i] = min(upper_limits_a[i], math.pi)
    

    q  = np.zeros(numDofs)
    poses = []
    for pp in range(numPoses):
      
      for i in range(numDofs):
        q[i] = random.uniform(lower_limits_a[i],upper_limits_a[i])
      
      manip.SetDOFValues(q)
      targetPose = manip.GetEndEffectorTransform()
      poses.append(targetPose)
    return poses;


if __name__ == "__main__":
    #rospy.init_node("adapy_supervisor")
    #s = Supervisor(sim=True, control = True, attach_viewer=True)

    #testik
    env, robot = adapy.initialize(sim=True, attach_viewer=False)
    numDofs = robot.GetDOF();

    #manip = s.robot.arm
    #s.robot.SetActiveManipulator(manip)
    manip = robot.GetActiveManipulator()
    print "Generating poses ... "
    poses = GeneratePoses(manip,robot,10000)
    print "Saving poses to file ... "
    filePath = os.path.abspath(os.path.join(os.path.join(os.path.realpath(__file__), os.pardir), os.pardir)) 
    fileName = filePath + '/data/poses.dat'
    WritePosesToFile(poses, fileName)
