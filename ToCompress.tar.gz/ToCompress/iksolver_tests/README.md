iksolver_tests
==============

iksolver_tests is a set of Python scripts used by the Personal Robotics Laboratory at Carnegie Mellon University. These scripts run tests to benchmark different ik_solvers in terms of speed, success rate and accuracy.

# Generating poses for testing #
You can generate a set of random end_effector poses for the Ada robot within the joint limits, by running the script 
generate_poses.py The poses are saved in the file poses.dat in the data/ folder. 

# Testing the poses using the nlopt / generalik solver #
You can test the poses by running the script test_poses_nloptik.py or test_poses_generalik.py

# Calculate performance metrics #
You can view the performance output for each solver by running test_poses_nloptik.py or compute_errors_generalik.py

# View generates poses and nlopt solver solution #
You can view the generated poses and the solution of the nlopt solver by running view_poses_nloptik.py
