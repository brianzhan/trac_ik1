#!/usr/bin/env python
import rospy
import numpy as np
from control_input import ControlInput
from sensor_msgs.msg import Joy
from std_msgs.msg import Float32MultiArray
from std_msgs.msg import MultiArrayDimension


class Joy3AxisJointInput(ControlInput):
  ''' Sip and Puff Mico teleoperation based on three axis joint  node '''

  def __init__(self, joints=8, buttons=2, max_velocities=None):
    ControlInput.__init__(self)
    
    self._joints = joints
    self._buttons = buttons

    self._available_modes = np.ceil(joints)
    self._mode = 0 # controlling joints _mode*3 + 0, _mode*3 + 1, and _mode*3 + 2

    # load velocity limits
    if max_velocities == None:
        if rospy.has_param('max_joint_vel'):
          self._max_joint_vel = np.array(rospy.get_param('max_joint_vel'))
        else:
          self._max_joint_vel = np.ones(self._joints)
          rospy.logwarn('No rosparam for max_joint_vel found...Defaulting to max linear joint vel of 50 degrees/s')
    else:
        self._max_joint_vel = max_velocities

    
    if len(self._max_joint_vel) != self._joints:
      rospy.logerr('Length of max_joint_vel does not equal number of joints!')

    self._joint_vel = np.zeros(self._joints)

    self.send_msg = Float32MultiArray()
    dim = [MultiArrayDimension()]
    dim[0].label = 'joint_velocity'
    dim[0].size = self._joints
    dim[0].stride = self._joints
    self.send_msg.layout.dim = dim
    #self.send_msg.layout.data_offset = 0
    self.send_msg.data = np.zeros_like(self._joint_vel)
    self.waiting_for_release = [False] * self._buttons

    self.lock.acquire()
    try:
      self.data = self.send_msg
    finally:
      self.lock.release()

  def receive(self, msg):
    # Sip forward through modes
    #if msg.buttons[0] and msg.axes[0]>0.35:
    if self.waiting_for_release[0] and msg.buttons[0] and msg.axes[0]>0.35:    
        self._mode =  int((self._mode + 1) % self._available_modes)
        rospy.loginfo("Hard Sip: Switching to control of joints %s.", self._mode + 1)        

    # Puff cycles backward through modes
    #if msg.buttons[1] and msg.axes[0]<-0.35:
    if self.waiting_for_release[1] and msg.buttons[1] and msg.axes[0]<-0.35:    
        self._mode =  int((self._mode - 1) % self._available_modes)
        rospy.loginfo("Hard Puff: Switching to control of joints %s.", self._mode + 1)

    for i, waiting in enumerate(self.waiting_for_release):
        if not waiting and msg.buttons[i]:
            self.waiting_for_release[i] = True
        elif not msg.buttons[i]:
            self.waiting_for_release[i] = False


    # zero out the _joint_vel
    self._joint_vel = np.zeros(self._joints)
    
    joint = int(self._mode)
    if joint < self._joints:
      self._joint_vel[joint] = self._vel_from_axes(msg.axes, joint)

    self.send_msg.data = self._joint_vel

    self.lock.acquire()
    try:
      self.data = self.send_msg
    finally:
      self.lock.release() 
  
  def _vel_from_axes(self, axes, joint):
      return axes[0] * self._max_joint_vel[joint]

  def getDefaultData(self):
    # since this sends velocity, the default will be all zeros.
    self.lock.acquire()
    try:
      self.data = Float32MultiArray() # np.zeros_like(self._joint_vel)
    finally:
      self.lock.release()

if __name__ == '__main__':
  rospy.init_node('joy3axis_node', anonymous=True)
  joy3axis = Joy3AxisJointInput()
  joy3axis.startSend('control_input')
  rospy.Subscriber('joy', Joy, joy3axis.receive,  queue_size = 1)


  rospy.spin()
