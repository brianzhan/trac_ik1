#!/usr/bin/env python
import rospy
import numpy as np
from control_input import ControlInput
from sensor_msgs.msg import Joy
from std_msgs.msg import Float32MultiArray
from std_msgs.msg import MultiArrayDimension


class XYThetaInput(ControlInput):
  ''' data is a Float32Array message '''

  def __init__(self):
    ControlInput.__init__(self)
    
    self._mode = 'xy'
    # load velocity limits
    if rospy.has_param('max_cart_vel'):
      self._max_cart_vel = np.array(rospy.get_param('max_cart_vel'))
    else:
      self._max_cart_vel = np.ones(8)
      self._max_cart_vel[6] = 5400
      self._max_cart_vel[7] = 5400
      rospy.logwarn('No rosparam for max_cart_vel found...Defaulting to max linear velocity of 50 cm/s and max rotational velocity of 50 degrees/s')
    
    if not len(self._max_cart_vel) == 8:
      rospy.logerr('Length of max_cart_vel does not equal number of joints!')

    self._cart_vel = np.zeros(8)

    self.send_msg = Float32MultiArray()
    _dim = [MultiArrayDimension()]
    _dim[0].label = 'cartesian_velocity'
    _dim[0].size = 8
    _dim[0].stride = 8
    self.send_msg.layout.dim = _dim
    #self.send_msg.layout.data_offset = 0
    self.send_msg.data = np.zeros_like(self._cart_vel)
    self.waiting_for_release = False

    self.lock.acquire()
    try:
      self.data = self.send_msg
    finally:
      self.lock.release()

  def receive(self, msg):
    # handle internal modes
    if msg.buttons[0] and not msg.buttons[1]:
      self._mode = 'xy'
      rospy.loginfo('Joystick control mode: xy')
    elif not msg.buttons[0] and msg.buttons[1]:
      self._mode = 'theta'
      rospy.loginfo('Joystick control mode: theta')

    # set axes variable
    _axes = np.array(msg.axes);
    _axes[1] = -_axes[1]
    _axes[2] = -_axes[2]
    
    # zero out the _cart_vel
    for i in range(0,8):
      self._cart_vel[i] = 0
    
    # based on mode, find what you want to put _cart_vel
    if self._mode == 'xy':
      for i in range(0,2):
        self._cart_vel[i] = _axes[i]*self._max_cart_vel[i]
    elif self._mode == 'theta':
      self._cart_vel[4] = -_axes[0]*self._max_cart_vel[4]

    self.send_msg.data = self._cart_vel

    self.lock.acquire()
    try:
      self.data = self.send_msg
    finally:
      self.lock.release() 
  
  def getDefaultData(self):
    # since this sends velocity, the default will be all zeros.
    self.lock.acquire()
    try:
      self.data = Float32MultiArray() # np.zeros_like(self._cart_vel)
    finally:
      self.lock.release()

if __name__ == '__main__':
  rospy.init_node('xytheta_input_node', anonymous=True)
  xytheta = XYThetaInput()
  xytheta.startSend('joy_cart_vel')
  rospy.Subscriber('joy', Joy, xytheta.receive)


  rospy.spin()
