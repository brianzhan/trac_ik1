#!/usr/bin/env python

import adapy
import math
import numpy as np
import openravepy
import prpy
import rospy
import scipy
import sys
import threading
import time

from StringIO import StringIO
from seds.srv import JtoC, JtoCRequest, JtoCResponse
from controller_manager_msgs.srv import SwitchController, ListControllers
from std_msgs.msg import Float32MultiArray, Float64
from sensor_msgs.msg import JointState
from tf import transformations as tfs

class NullIO(StringIO):
    """
    I/O device that ignores things written to it.

    This is necessary because SciPy's sparse.linalg.lsqr is badly behaved,
    and uncontrollably vomits to stdout."""
    def write(self, txt):
        pass

class OrControllerMode(object):
    """
    Base class for a 'controller mode.'
    
    This defines a mapping from some particular type of 'control_input' message
    to some particular means of controlling a (real or simulated) robot. The
    supervisor dynamically chooses between these when presented with control_input
    messages.
    """
    def __init__(self, supervisor, load=True):
        self.sup = supervisor
        self.loaded = False
        if load:
            self.load()

    def _load_controllers(self, controllers, timeout=10):
        """Load a list of ros_control controllers by name."""

        rospy.wait_for_service('controller_manager/switch_controller', timeout=10)
        rospy.wait_for_service('controller_manager/list_controllers', timeout=10)

        switch_controllers = rospy.ServiceProxy(
                'controller_manager/switch_controller', SwitchController)
        list_controllers = rospy.ServiceProxy(
                'controller_manager/list_controllers', ListControllers)

        running = set([c.name for c in list_controllers().controller
            if c.state == "running"])
        controllers = set(controllers)
        switch_controllers(list(controllers - running), list(running - controllers), 2)
    
    def _unload_controllers(self, controllers):
        """Unload a list of ros_control controllers by name"""

        rospy.wait_for_service('controller_manager/switch_controller')
        rospy.wait_for_service('controller_manager/list_controllers')

        switch_controllers = rospy.ServiceProxy(
                'controller_manager/switch_controller', SwitchController)
        list_controllers = rospy.ServiceProxy(
                'controller_manager/list_controllers', ListControllers)

        running = set([c.name for c in list_controllers().controller
            if c.state == "running"])
        controllers = set(controllers)
        switch_controllers([], list(controllers & running), 2)

    def load(self):
        """
        Perform various startup tasks.
        
        Switch the robot's controller to the one I care about, load the
        relevant ros_control controllers, etc.
        """

        try:
            if self.sup.handler.loaded:
                self.sup.handler.unload()
                if self.sup.handler.loaded:
                    raise Exception(
                            "Can't start a new handler: loaded handler won't die.")
        except AttributeError:
            pass
        if self.loaded:
            raise Exception("This handler is already loaded.")

        # We'll need to know during unloading whether we're simulated or not,
        # regardless of changes in the supervisor.
        self.sim = self.sup.sim

        if self.sim:
            or_controller_string = self.or_simulated_controller
        else:
            or_controller_string = self.or_physical_controller

            self._load_controllers(self.ros_controllers)
            
        with self.sup.env:
            self.controller = openravepy.RaveCreateController(self.sup.env,
                    or_controller_string)

	    m = self.sup.robot.GetActiveDOFIndices()
            c = self.controller
            self.sup.robot.SetController(c, m, 0)

        self.loaded = True

    def unload(self):
        """
        Undo all important things we did in the load function.

        Unload all loaded ros_controllers, set velocities to 0, etc.
        """

        if not self.sim:
            self._unload_controllers(self.ros_controllers)
        self.loaded = False

class TwistHandler(OrControllerMode):
    """Handle cartesian twists for Ada.

    Messages should be 8 fields long, and include dx, dy, dz, dtheta, dphi,
    dpsi, and a gripper velocity. These get periodically turned into joint
    velocities via inverse-jacobian using damped least-squares, and then
    sent to the robot.
    """

    def __init__(self, supervisor, damp=0.1, period=0.05, pgain=None, **kw_args):
        self.TRANS = 1
        self.ROT = 2
        self.mode = 0
        # self.cartvel = np.array([0]*6)
        self.Pgain = pgain or np.array([6]*3 + [2]*3)

        self.data_lock = threading.Lock()
        self.data = [0] * 8

        self.sup = supervisor
        self.damp = damp
        self.or_simulated_controller = "idealvelocitycontroller"
        #self.or_physical_controller = (
        #        "rosvelocitycontroller openrave {0} 1".format(self.sup.ns))
        self.or_physical_controller = (
                "roscontroller openrave {0} 1".format(self.sup.ns))

        #joints = ["j1", "j2", "j3", "j4", "j5", "j6", "f1", "f2"]
        #self.ros_controllers.extend(
        #        ["pid_{0}_controller".format(j) for j in joints])
        self.ros_controllers = [
                "velocity_joint_mode_controller",
                "joint_state_controller",
                ]
        joints = ["j1", "j2", "j3", "j4", "j5", "j6", "f1", "f2"]
        self.ros_controllers.extend(
                ["vel_{0}_controller".format(j) for j in joints])
        self.period = period

        super(TwistHandler, self).__init__(supervisor, **kw_args)

    def load(self):
        super(TwistHandler, self).load()
        self.ThreadIsRunning = True
        self.updater = threading.Thread(target=self._sendValue,
                args=(self.period,), name="IK")
        self.updater.start()
        self.measured_cartesian = rospy.Publisher('measured_cartesian_velocity', Float32MultiArray)
        self.desired_cartesian = rospy.Publisher('desired_cartesian_velocity', Float32MultiArray)
        self.sv = rospy.Publisher('svs', Float32MultiArray)
        self.js = rospy.Subscriber("joint_states",
                JointState, self.getActualCartesian)
        # self.rjs = rospy.Subscriber("/robotjsvels", Float32MultiArray, self.getCartFromJS)
        self.jtoc = rospy.Service("/supervisor/jointtocart", JtoC, self.JointtoCartVel)

        
    def handle(self, msg):
        with self.data_lock:
            self.data = msg.data

    def _sendValue(self, period):
        while self.ThreadIsRunning and not rospy.is_shutdown():
            try:
                start = time.clock()

                with self.data_lock:
                    with self.sup.env:
                        #jointvels = self._inverseJacobian()
                        twist = np.array(self.data[:6])
                        # twist = self.cartvel
                        # print twist
                        jointvels, twist_opt = prpy.util.ComputeJointVelocityFromTwist(self.sup.robot,twist,objective=prpy.util.quadraticPlusJointLimitObjective)
                        if (abs(np.array(jointvels)[:6]) > self.sup.robot.GetDOFVelocityLimits()[:6]).any():
                            jointvels = (jointvels / abs(np.array(jointvels)).max()) * self.sup.robot.GetDOFVelocityLimits().max()
                        if (abs(np.array(jointvels[:6])) > self.sup.robot.GetDOFVelocityLimits()[:6]).any():
                            print "Joint speed exceeds limits: Trying to send {0}".format(
                                    jointvels)
                        # jointvels = np.concatenate((jointvels,[0,0]), axis=0)
                        jointvels = np.concatenate((jointvels,self.data[6:]), axis=0)
                        self.controller.SetDesired(jointvels)

                end = time.clock()
                if period - (end - start) > 0:
                    time.sleep(period - (end - start))
            except KeyboardInterrupt:
                break
            except Exception as e:
                print e


    def JointtoCartVel(self, jointvels):
        res = JtoCResponse()
        jointvels = jointvels.jvels
        m = self.sup.robot.GetActiveManipulator()
        J = m.CalculateJacobian()
        Jrot = m.CalculateAngularVelocityJacobian()
        cart = list(np.dot(J, np.array(jointvels)[:,np.newaxis]))
        rot = list(np.dot(Jrot, np.array(jointvels)[:,np.newaxis]))
        res.cvels = cart+rot 
        return res


    def getActualCartesian(self, msg):
        m = self.sup.robot.GetActiveManipulator()
        J = m.CalculateJacobian()
        Jrot = m.CalculateAngularVelocityJacobian()
        cart = list(np.dot(J, np.array(msg.velocity[2:])[:,np.newaxis]))
        rot = list(np.dot(Jrot, np.array(msg.velocity[2:])[:,np.newaxis]))
        
        mc = Float32MultiArray()
        mc.data = cart + rot
        # self.cartvel = np.array(mc.data)
        # self.measured_cartesian.publish(mc)

        dc = Float32MultiArray()
        dc.data = list(np.multiply(np.array(self.data),
                   np.array([self.sup.trans_scale]*3 + [self.sup.rot_scale]*3 + [1, 1])))
        self.desired_cartesian.publish(dc)

        U, s, V = np.linalg.svd(np.vstack((J, Jrot)))

        sv = Float32MultiArray()
        sv.data = list(s)

        self.sv.publish(sv)

    def getCartFromJS(self,msg):
        # print "in callback"
        m = self.sup.robot.GetActiveManipulator()
        J = m.CalculateJacobian()
        Jrot = m.CalculateAngularVelocityJacobian()
        cart = list(np.dot(J, np.array(msg.data)[:,np.newaxis]))
        rot = list(np.dot(Jrot, np.array(msg.data)[:,np.newaxis]))
        # self.cartvel = np.array(cart+rot)
        mc = Float32MultiArray()
        mc.data = cart+rot
        self.measured_cartesian.publish(mc)



    def _inverseJacobian(self):
        """
        Produce the desired joint velocities at the current timestep.

        Get the linear- and angular-velocity jacobians for the end-effector at
        the current timestep from OpenRAVE, and find a good fit for joint
        velocities given the current intended cartesian velocities, using
        damped least-squares.
        """


        if not np.any(self.data[:6]):
            return [0]*6 + list(self.data[6:])


        # [:, np.newaxis] gives the transpose into a column vector.
        input_trans = np.array(self.data[:3])[:,np.newaxis] * self.sup.trans_scale
        input_rot = np.array(self.data[3:6])[:,np.newaxis] * self.sup.rot_scale

        if input_trans.any():
            newmode = self.TRANS
        elif input_rot.any():
            newmode = self.ROT
        else:
            newmode = self.mode

        """
        if mode changed,
            record current position or rotation
        else,
            use recorded position as desired_*
        """
        
        with self.sup.env:
            m = self.sup.robot.GetActiveManipulator()
            J_trans = m.CalculateJacobian()
            J_rot = m.CalculateAngularVelocityJacobian()

            if newmode != self.mode:
                if newmode == self.TRANS:
                    self.rot_target = tfs.quaternion_from_matrix(
                            m.GetEndEffectorTransform())
                else:
                    self.trans_target = m.GetEndEffectorTransform()[:3,3]
                desired_translation = input_trans
                desired_rotation = input_rot
            elif newmode == self.TRANS:
                current_rotation = tfs.quaternion_from_matrix(
                        m.GetEndEffectorTransform())
                inverse_current = tfs.quaternion_inverse(current_rotation)

                diff = tfs.quaternion_multiply(self.rot_target, inverse_current)
                diff = diff / np.linalg.norm(diff)
                theta = 2 * math.acos(diff[3])

                if theta > math.pi:
                    theta -= 2 * math.pi

                if diff[:3].any():
                    angvel = theta * diff[:3] / np.linalg.norm(diff[:3])
                else:
                    angvel = 0

                desired_rotation = (self.Pgain[3:] * angvel)[:,np.newaxis]
                desired_translation = input_trans
            elif newmode == self.ROT:
                desired_translation = (-self.Pgain[:3] *
                        (m.GetEndEffectorTransform()[:3,3]
                            - self.trans_target))[:,np.newaxis]
                desired_rotation = input_rot

            else:
                desired_translation = input_trans
                desired_rotation = input_rot

        self.mode = newmode

        damp = (self.sup.trans_damp
                if np.linalg.norm(desired_translation) > 0.01
                else self.sup.rot_damp)
        
        desired_grip = self.data[6:]



        J = np.vstack((J_trans, J_rot))
        
        # As mentioned above, scipy's least-squares method unstoppably prints to
        # sys.__stdout__, so we have to temporarily redirect it.
        sys.stdout = NullIO()
        result = scipy.sparse.linalg.lsqr(J,
                np.vstack((desired_translation, desired_rotation)), damp=damp)[0]
        sys.stdout = sys.__stdout__
        
        return list(result) + list(desired_grip)

    def unload(self):
        self.ThreadIsRunning = False

        # wait for the updater to die.
        self.updater.join()

        with self.sup.env:
            # Stop everything
            self.controller.SetDesired([0] * 8)

        self.js.unregister()
        #self.desired_cartesian.unregister()
        #self.measured_cartesian.unregister()
        #self.sv.unregister()

        super(TwistHandler, self).unload()


class JointVelHandler(OrControllerMode):
    """Simplest controllermode. Passes control_input directly to robot."""

    def __init__(self, supervisor, **kw_args):
        self.sup = supervisor
        self.sim = self.sup.sim
        self.or_simulated_controller = "idealvelocitycontroller"
        self.or_physical_controller = (
                "roscontroller openrave {0} 1".format(self.sup.ns))

        self.ros_controllers = [
                "velocity_joint_mode_controller",
                "joint_state_controller",
                ]

        joints = ["j1", "j2", "j3", "j4", "j5", "j6", "f1", "f2"]
        self.ros_controllers.extend(
                ["vel_{0}_controller".format(j) for j in joints])

        super(JointVelHandler, self).__init__(supervisor, **kw_args)

        
    def handle(self, msg):
        self.controller.SetDesired(msg.data[:8])

    def unload(self):
        self.controller.SetDesired([0] * 8)
        super(JointVelHandler, self).unload()

class JointStateHandler(OrControllerMode):
    """Controller mode that only keeps the robot up-to-date with joint states"""

    def __init__(self, supervisor, **kw_args):
        self.sup = supervisor
        self.or_simulated_controller = self.or_physical_controller = (
                "roscontroller openrave {0} 1".format(self.sup.ns))
        self.ros_controllers = []
        super(JointStateHandler, self).__init__(supervisor, **kw_args)

    def handle(self, msg):
        pass
        

class PositionHandler(OrControllerMode):
    """Plan and execute to position. Unimplemented."""
    def __init__(self, supervisor):
        self.sim = supervisor.sim
    def handle(self, msg):
        pass





class JointPosHandler(OrControllerMode):
    """Plan and execute to joint position."""
    def __init__(self, supervisor, **kw_args):
        self.sup = supervisor
        self.sim = self.sup.sim
        self.or_simulated_controller = "idealcontroller"
        self.or_physical_controller = (
                "roscontroller openrave {0} 1".format(self.sup.ns))

        self.ros_controllers = [
                "position_joint_mode_controller",
                "joint_state_controller",
                "traj_controller",
                ]

        super(JointPosHandler, self).__init__(supervisor, **kw_args)

    def handle(self, msg):
        traj = openravepy.RaveCreateTrajectory(self.sup.env, '')
        traj.Init(self.sup.robot.GetActiveConfigurationSpecification())
        traj.Insert(0, self.sup.robot.GetActiveDOFValues())
        traj.Insert(1, msg.data)
        openravepy.planningutils.RetimeActiveDOFTrajectory(traj, self.sup.robot)
        self.controller.SetPath(traj)
        #self.sup.robot.PlanToConfiguration(msg.data)

class DumbJointPosHandler(OrControllerMode):
    """Plan and execute to joint position. Doesn't plan; only sends positions."""
    def __init__(self, supervisor, **kw_args):
        self.sup = supervisor
        self.sim = self.sup.sim
        self.or_simulated_controller = "idealcontroller"
        self.or_physical_controller = (
                "roscontroller openrave {0} 1".format(self.sup.ns))

        self.ros_controllers = [
                "position_joint_mode_controller",
                "joint_state_controller",
                ]

        joints = ["j1", "j2", "j3", "j4", "j5", "j6", "f1", "f2"]
        self.ros_controllers.extend(
                ["pos_{0}_controller".format(j) for j in joints])

        super(DumbJointPosHandler, self).__init__(supervisor, **kw_args)

    def handle(self, msg):
        self.controller.SetDesired(msg.data)
        #self.sup.robot.PlanToConfiguration(msg.data)
        
class Supervisor(object):

    # Map from control_input strings to controllermodes.
    _HANDLERS = {
            "cartesian_velocity" : TwistHandler,
            "joint_velocity"     : JointVelHandler,
            #"cartesian_position" : PositionHandler,
            #"joint_position"     : JointPosHandler,
            #"joint_position"     : DumbJointPosHandler,
            }

    def __init__(self,
            ns=None,
            control=True,
            sim=False,
            attach_viewer='qtcoin',
            trans_scale=1,
            trans_damp=0.1,
            rot_scale=1,
            rot_damp=0.1,
            **kw_args):
        self.rot_scale = rot_scale
        self.trans_scale = trans_scale
        self.rot_damp = rot_damp
        self.trans_damp = trans_damp

        self.handler_lock = threading.Lock()

        # without sim=True, adapy tries to load some weird controller.
        self.env, self.robot = adapy.initialize(sim=True, attach_viewer=attach_viewer, **kw_args) 
        self.sim = sim

        self.ns = ns or rospy.get_namespace()

        if control:
            self.handler = JointVelHandler(self)

            rospy.Subscriber("control_input",
                    Float32MultiArray,
                    self._controlInputCallback,
                    queue_size=1)
        else:
            self.handler = JointStateHandler(self)

        
    def setHandler(self, msg_string):
        self.handler.unload()
        self.handler = self._HANDLERS[msg_string](self)

    def _controlInputCallback(self, msg):
        handler = msg.layout.dim[0].label
        with self.handler_lock:
            if self._HANDLERS.get(handler) != self.handler.__class__:
                self.setHandler(handler)

        # m = self.robot.GetActiveManipulator()
        # t = m.GetEndEffectorTransform()[:,3]
        # tuplemsg = list(msg.data)
        # if t[2] < 0.07:
        #     for i in range(0, len(tuplemsg)):
        #         tuplemsg[i] = 0
        #     tuplemsg[2] = 0.05
        # msg.data = tuple(tuplemsg)
        # print self.robot.GetActiveDOFValues()
        self.handler.handle(msg)




if __name__ == "__main__":
    rospy.init_node("adapy_supervisor")


    s = Supervisor(sim=False, attach_viewer=False)

    from std_msgs.msg import Float32MultiArray, MultiArrayDimension
    msg = Float32MultiArray()
    dim = MultiArrayDimension()
    dim.label = "cartesian_velocity"
    msg.layout.dim.append(dim)
    msg.data = [0, 0, 0, 0, 0, 0, 0, 0]
    s._controlInputCallback(msg)
    time.sleep(1)

    from IPython import embed
    embed()

