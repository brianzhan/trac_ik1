#!/usr/bin/env python

import openravepy
import numpy
import actionlib
import rospy
import math
import tf
import rospkg
import os
import time
import adapy
import prpy
from prpy.tsr.tsr import *
from IPython import embed
from copy import copy
from std_msgs.msg import Float64
from sensor_msgs.msg import Joy
from geometry_msgs.msg import Twist
from controller_manager_msgs.srv import SwitchController, ListControllers
from std_msgs.msg import Float32MultiArray
from std_msgs.msg import MultiArrayDimension

numpy.set_printoptions(precision=3)

#startConfiguration = numpy.asarray([-0.59226119, -0.80147511,  0.60337137,  3.06410745, -0.94669731,-2.833287])

class OrControllerMode(object):
    """
    Base class for a 'controller mode.'

    This defines a mapping from some particular type of 'control_input' message
    to some particular means of controlling a (real or simulated) robot. The
    supervisor dynamically chooses between these when presented with control_input
    messages.
    """
    def __init__(self, robot, env, load=True):
        self.robot = robot
        self.env = env
        self.loaded = False
        if load:
            self.load()

    def _load_controllers(self, controllers, timeout=10):
        """Load a list of ros_control controllers by name."""

        rospy.wait_for_service('controller_manager/switch_controller', timeout=10)
        rospy.wait_for_service('controller_manager/list_controllers', timeout=10)

        switch_controllers = rospy.ServiceProxy(
                'controller_manager/switch_controller', SwitchController)
        list_controllers = rospy.ServiceProxy(
                'controller_manager/list_controllers', ListControllers)

        running = set([c.name for c in list_controllers().controller
            if c.state == "running"])
        controllers = set(controllers)
        switch_controllers(list(controllers - running), list(running - controllers), 2)

    def _unload_controllers(self, controllers):
        """Unload a list of ros_control controllers by name"""

        rospy.wait_for_service('controller_manager/switch_controller')
        rospy.wait_for_service('controller_manager/list_controllers')

        switch_controllers = rospy.ServiceProxy(
                'controller_manager/switch_controller', SwitchController)
        list_controllers = rospy.ServiceProxy(
                'controller_manager/list_controllers', ListControllers)

        running = set([c.name for c in list_controllers().controller
            if c.state == "running"])
        controllers = set(controllers)
        switch_controllers([], list(controllers & running), 2)

    def load(self):
        """
        Perform various startup tasks.

        Switch the robot's controller to the one I care about, load the
        relevant ros_control controllers, etc.
        """

        # We'll need to know during unloading whether we're simulated or not,
        # regardless of changes in the supervisor.
        self.sim = False #self.sup.sim
        ns=None
        self.ns = ns or rospy.get_namespace()

        self.or_simulated_controller = "idealvelocitycontroller"
        self.or_physical_controller = (
                "rosvelocitycontroller openrave {0} 1".format(self.ns))

        self.ros_controllers = [
                "velocity_joint_mode_controller",
                "joint_state_controller",
                ]

        joints = ["j1", "j2", "j3", "j4", "j5", "j6", "f1", "f2"]
        self.ros_controllers.extend(
                ["pid_{0}_controller".format(j) for j in joints])


        if self.sim:
            or_controller_string = self.or_simulated_controller
        else:
            or_controller_string = self.or_physical_controller

            self._load_controllers(self.ros_controllers)

        with self.env:
            self.controller = openravepy.RaveCreateController(self.env,
                    or_controller_string)
            self.robot.SetController(self.controller,
                    self.robot.GetActiveDOFIndices(), 0)

        self.loaded = True

    def unload(self):
        """
        Undo all important things we did in the load function.

        Unload all loaded ros_controllers, set velocities to 0, etc.
        """

        if not self.sim:
            self._unload_controllers(self.ros_controllers)
        self.loaded = False


class JointVelHandler(OrControllerMode):
    """Simplest controllermode. Passes control_input directly to robot."""

    def __init__(self, robot, env):

        #self.sim = True #self.sup.sim
        ns=None
        self.ns = ns or rospy.get_namespace()
        self.robot = robot
        self.env = env

        self.or_simulated_controller = "idealvelocitycontroller"
        self.or_physical_controller = (
                "rosvelocitycontroller openrave {0} 1".format(self.ns))

        self.ros_controllers = [
                "velocity_joint_mode_controller",
                "joint_state_controller",
                ]

        joints = ["j1", "j2", "j3", "j4", "j5", "j6", "f1", "f2"]
        self.ros_controllers.extend(
                ["pid_{0}_controller".format(j) for j in joints])

        super(JointVelHandler, self).__init__(self.robot, self.env)


    def handle(self, msg):
        self.controller.SetDesired(msg)

    def unload(self):
        self.controller.SetDesired([0] * 8)
        super(JointVelHandler, self).unload()

class ADAmanipulationTester:
  def initSimple(self):
      openravepy.RaveInitialize(True, level=openravepy.DebugLevel.Debug)
      openravepy.misc.InitOpenRAVELogging();
      self.env, self.robot = adapy.initialize(attach_viewer=True, sim=True)
      self.manip = self.robot.arm
      inds, pos = self.robot.configurations.get_configuration('home')

      #self.robot.SetActiveDOFValues([2.49703523e+00, -2.83277542e+00, 2.88702108e+00,-5.72281360e-01, 4.34883553e-01, 2.16745773e+00,0.0,0.0])
    


    #   self.robot.SetActiveDOFValues([2.50578478, -2.72143438,  2.43454203, -0.44424004,  0.63099234,  2.54072013,0.0,0.0])

      offset, scaling = 0, 0
      with open('/home/siddarth/icorr_ws/bmi_map/offset.txt') as f:
          content = f.readlines()
          temp = [float(itm) for itm in content[0].rstrip().split(',')]
          offset = temp[1]

      with open('/home/siddarth/icorr_ws/bmi_map/scaling.txt') as f:
          content = f.readlines()
          temp = [float(itm) for itm in content[0].rstrip().split(',')]
          scaling = temp[1]
      # scaling = [1456.4, 1189.8] #for brian
      # self.joy_switch = 0.8

      self.joy_switch = 0
      with open('/home/siddarth/icorr_ws/bmi_map/threshold.txt') as f:
          content = f.readlines()
          temp = [float(itm) for itm in content[0].rstrip().split(',')]
          self.joy_switch = temp[1]+(offset/float(scaling))-0.53

      # initialize important values
      self.idx = 1
      self.segment = 1
      self.user_cmd = Twist()
      self.GAIN = 1.0
      self.joy_thresh = 0.15
    #   self.joy_switch = 1.5
      self.dist_thresh = 0.15
      self.dist_thresh_end = 0.03
      self.wrist_thresh = 0.01
      self.delta_time = 0.1
      self.gripper_pos = 0.85
      self.gripper_vel = 700
      self.wrist_vel = -0.5
      self.modeswitch = False

      # find the ordata
      rospack = rospkg.RosPack()
      file_root = rospack.get_path('pr_ordata')

      # load the table
      table_name = 'table'
      table_xml = os.path.join(file_root, 'data', 'furniture', 'table.kinbody.xml')

      table_pose = numpy.array([[ 1,   0,   0,  8.75423792e-01],
      [ 0,  0,  -1,  6.32824451e-02],
      [ 0,  1,   0,  0],
      [  0,   0,   0,  1]])
      self.table = prpy.rave.add_object(self.env, table_name, table_xml, table_pose)
      self.table_aabb = self.table.ComputeAABB()

      # # load a fuze bottle
      glass_name = 'glass'
      glass_xml = os.path.join(file_root, 'data', 'objects', 'glass.kinbody.xml')
      glass_pose = numpy.eye(4)
      self.glass = prpy.rave.add_object(self.env, glass_name, glass_xml, glass_pose)
      glass_aabb = self.glass.ComputeAABB()

      glass_pose[2,3] = 2*self.table_aabb.extents()[2] + 0.005
      glass_pose[0,3] = self.table_aabb.pos()[0] - 0.5*self.table_aabb.extents()[0] + 0.3
      glass_pose[1,3] = self.table_aabb.pos()[1]
      self.glass.SetTransform(glass_pose)

      robot_pose = copy(glass_pose)

      robot_pose[0,3] = robot_pose[0,3] + 0.1
      robot_pose[1,3] = robot_pose[1,3] + 0.275
      robot_pose[2,3] = 2*self.table_aabb.extents()[2] + 0.04
      robot_pose[2,3] = robot_pose[2,3] + 0.02
      robot_pose[0,3] = robot_pose[0,3] - 0.5
      self.robot.SetTransform(robot_pose)
      #embed()

      glass_pose[0,3] = glass_pose[0,3] - 0.2
      glass_pose[1,3] = glass_pose[1,3] - 0.1
      self.glass.SetTransform(glass_pose)

      #load a fuze bottle
      fuze_name = 'fuze_bottle'
      fuze_xml = os.path.join(file_root, 'data', 'objects', 'glass.kinbody.xml')
      fuze_pose = numpy.eye(4)
      self.fuze = prpy.rave.add_object(self.env, fuze_name, fuze_xml, fuze_pose)
      fuze_aabb = self.fuze.ComputeAABB()

      fuze_pose[2,3] = 2*self.table_aabb.extents()[2] -0.05
      fuze_pose[0,3] = self.table_aabb.pos()[0] - 0.5*self.table_aabb.extents()[0] + 0.6
      fuze_pose[1,3] = self.table_aabb.pos()[1] + 0.2
      fuze_pose[1,3] = fuze_pose[1,3] - 0.3
      fuze_pose[0,3] = fuze_pose[0,3] - 0.8


      table_pose[0,3] = 0.475
      self.table.SetTransform(table_pose)

      fuze_pose[0,3] = -0.122
      fuze_pose[1,3] = -0.057
      fuze_pose[2,3] = 0.735
      self.fuze.SetTransform(fuze_pose)


      #embed()

      ViewSide1 = numpy.array([[ 0.9998857 , -0.00582933, -0.01394994,  0.89785039],
      [ 0.01070029, -0.37899823,  0.92533553, -1.42433608],
      [-0.01068109, -0.92537904, -0.37889254,  1.3081876 ],
      [ 0.        ,  0.        ,  0.        ,  1.        ]])

      ViewSide2 = numpy.array([[ 0.99886276,  0.01140204, -0.04629459,  0.92531258],
      [ 0.04448544, -0.57221648,  0.8188952 , -0.81919384],
      [-0.01715345, -0.82002335, -0.57207295,  1.3155508 ],
      [ 0.        ,  0.        ,  0.        ,  1.        ]])

      ViewRobotTop1 = numpy.array([[-0.01158292, -0.94072085,  0.33898396,  0.42924026],
      [-0.99780782,  0.03296392,  0.05738418, -0.0122487 ],
      [-0.06515673, -0.33757617, -0.93904043,  1.93505919],
      [ 0.        ,  0.        ,  0.        ,  1.        ]])

      viewer = self.env.GetViewer()
      viewer.SetCamera(ViewRobotTop1)

      self.pub = rospy.Publisher('/eef_pose', Twist)
      self.pubnew = rospy.Publisher('/eef_pose_new', Twist)

  def planAndExecuteTrajectorySimple(self):

    manip = self.robot.arm
    self.robot.SetActiveManipulator(manip)
    activedofs = [i for i in range(6)]
    self.robot.SetActiveDOFs(activedofs)

    self.robot.planner = prpy.planning.Sequence(self.robot.cbirrt_planner)

    #trajStart = self.manip.PlanToConfiguration(startConfiguration, execute=True)
    #prpy.rave.save_trajectory(trajStart,"/home/siddarth/argallab_mico/src/ada_meal_scenario/src/trajStart.xml")   
    #self.robot.ExecuteTrajectory(trajStart)          
    #time.sleep(8)

    self.trajGlass = prpy.rave.load_trajectory(self.env,"/home/siddarth/argallab_mico/src/ada_meal_scenario/src/trajectories/trajGlass.xml")   
    self.trajoffg1 = prpy.rave.load_trajectory(self.env,"/home/siddarth/argallab_mico/src/ada_meal_scenario/src/trajectories/trajoffg1.xml")   
    self.trajoffg2 = prpy.rave.load_trajectory(self.env,"/home/siddarth/argallab_mico/src/ada_meal_scenario/src/trajectories/trajoffg2.xml") 

    self.trajBowl = prpy.rave.load_trajectory(self.env,"/home/siddarth/argallab_mico/src/ada_meal_scenario/src/trajectories/trajBowl.xml")   
    self.trajPour = prpy.rave.load_trajectory(self.env,"/home/siddarth/argallab_mico/src/ada_meal_scenario/src/trajectories/trajPour.xml")   
    self.trajdonePour = prpy.rave.load_trajectory(self.env,"/home/siddarth/argallab_mico/src/ada_meal_scenario/src/trajectories/trajdonePour.xml")   
    self.trajreturnstart = prpy.rave.load_trajectory(self.env,"/home/siddarth/argallab_mico/src/ada_meal_scenario/src/trajectories/trajreturnstart.xml")        

    #self.second_plan = self.robot.PlanToConfiguration([3.54410936e+00,  -3.17783269e+00,   3.37548138e+00,-3.00847844e-01,   1.02188249e+00,   0.89453364], execute=False)
    self.second_plan = self.trajGlass
    
    self.second_plan_mod = []
    for idx in range(self.second_plan.GetNumWaypoints()-1):
        cur_point = self.second_plan.GetWaypoint(idx)
        next_point = self.second_plan.GetWaypoint(idx+1)
        temp_dist = numpy.linalg.norm(next_point-cur_point)
        #if temp_dist > 0.03:
        self.second_plan_mod.append(cur_point)

    self.second_plan = self.trajoffg1
    for idx in range(self.second_plan.GetNumWaypoints()-1):
        cur_point = self.second_plan.GetWaypoint(idx)
        next_point = self.second_plan.GetWaypoint(idx+1)
        temp_dist = numpy.linalg.norm(next_point-cur_point)
        #if temp_dist > 0.03:
        self.second_plan_mod.append(cur_point)

    self.second_plan = self.trajoffg2
    for idx in range(self.second_plan.GetNumWaypoints()-1):
        cur_point = self.second_plan.GetWaypoint(idx)
        next_point = self.second_plan.GetWaypoint(idx+1)
        temp_dist = numpy.linalg.norm(next_point-cur_point)
        #if temp_dist > 0.03:
        self.second_plan_mod.append(cur_point)

    #self.robot.SetActiveDOFValues([3.54410936e+00,  -3.17783269e+00,   3.37548138e+00,-3.00847844e-01,   1.02188249e+00,   4.97639599e-01])
    
    #self.third_plan = self.robot.PlanToConfiguration([5.62271394, -3.05594133,  2.32917403,  2.74717093,  0.73291895, 0.05930156], execute=False)
    
    #self.third_plan = self.robot.PlanToConfiguration([ 5.607, -2.584,  3.359,  0.646,  1.672,  0.351], execute=False)
    self.third_plan = self.trajBowl

    self.third_plan_mod = []

    for idx in range(self.third_plan.GetNumWaypoints()-1):
        cur_point = self.third_plan.GetWaypoint(idx)
        next_point = self.third_plan.GetWaypoint(idx+1)
        temp_dist = numpy.linalg.norm(self.calc_shortest_ang(next_point, cur_point))
        #if temp_dist > 0.03:
        self.third_plan_mod.append(cur_point)

    activedofs = [i for i in range(8)]
    self.robot.SetActiveDOFs(activedofs)

    self.handler = JointVelHandler(self.robot, self.env)


    # rospy.Subscriber('/control_input_bmi', Float32MultiArray, self._controlInputCallback)
    rospy.Subscriber('/cmd', Twist, self._controlInputCallback)
    rospy.Timer(rospy.Duration(0.01),self._timerCallback)
    rospy.spin()

  def _controlInputCallback(self, msg):

    self.user_cmd.linear.x = msg.linear.x*self.GAIN
    self.user_cmd.linear.y = msg.linear.y*self.GAIN
    if self.user_cmd.linear.y > self.joy_switch and self.segment == 3:
        print('Switched to Turning Wrist Motion')
        self.segment = 4
    # elif self.user_cmd.linear.x < self.joy_switch and self.segment == 4:
    #     print('Switched to Following Trajectory Motion')
    #     self.segment = 3

    if self.user_cmd.linear.x < self.joy_thresh:# and self.segment != 4:
         self.user_cmd.linear.x = 0

    m = self.robot.GetActiveManipulator()
    eef_position = m.GetEndEffectorTransform()[:3,3]
    robot_pose_sub = self.robot.GetTransform()[:3,3]
    eef_pos_new = Twist()
    eef_pos_new.linear.x = eef_position[0]-robot_pose_sub[0]
    eef_pos_new.linear.y = eef_position[1]-robot_pose_sub[1]
    eef_pos_new.linear.z = eef_position[2]-robot_pose_sub[2]
    self.pubnew.publish(eef_pos_new)

  def _timerCallback(self, msg):

    activedofs = [i for i in range(6)]
    self.robot.SetActiveDOFs(activedofs)

    cur_pos = self.robot.GetActiveDOFValues()

    vel_vec = numpy.zeros(8)

    if self.segment == 1:

        cur_goal = self.second_plan_mod[self.idx]
        dist_vec = self.calc_shortest_ang(cur_goal, cur_pos)
        dist = numpy.linalg.norm(dist_vec)
        wrist_dist = numpy.abs(cur_goal[5]-cur_pos[5])
        j5_dist = numpy.abs(cur_goal[4]-cur_pos[4])

        if ((len(self.second_plan_mod) - self.idx) < 5) and dist > self.dist_thresh_end and wrist_dist > self.wrist_thresh and j5_dist > self.wrist_thresh:
            vel_vec = (dist_vec/self.delta_time)*self.user_cmd.linear.x
            vel_vec = numpy.append(vel_vec,0)
            vel_vec = numpy.append(vel_vec,0)
        elif dist > self.dist_thresh:# and wrist_dist > self.wrist_thresh:
            vel_vec = (dist_vec/self.delta_time)*self.user_cmd.linear.x
            vel_vec = numpy.append(vel_vec,0)
            vel_vec = numpy.append(vel_vec,0)
        else:
            if self.idx == len(self.second_plan_mod)-1:
                print('GOAL 1 REACHED')
                self.segment = 2
                self.idx = 0
            elif self.idx < len(self.second_plan_mod):
                self.idx += 1
    elif self.segment == 2:
        activedofs = [i for i in range(8)]
        self.robot.SetActiveDOFs(activedofs)
        f1 = self.robot.GetDOFValues()[6]
        f2 = self.robot.GetDOFValues()[7]
        if f1 > self.gripper_pos and f2 > self.gripper_pos:
            print('GOAL 2 REACHED')
            self.segment = 3
        else :
            vel_vec[6] = self.gripper_vel
            vel_vec[7] = self.gripper_vel
    elif self.segment == 3:

        cur_goal = self.third_plan_mod[self.idx]
        dist_vec = self.calc_shortest_ang(cur_goal, cur_pos)
        dist = numpy.linalg.norm(dist_vec)

        if dist > self.dist_thresh:
            vel_vec = (dist_vec/self.delta_time)*self.user_cmd.linear.x
            vel_vec = numpy.append(vel_vec,0)
            vel_vec = numpy.append(vel_vec,0)
        else:
            if self.idx == len(self.third_plan_mod)-1:
                print('GOAL 3 REACHED')
                # self.segment = 4
            elif self.idx < len(self.third_plan_mod):
                self.idx += 1
    elif self.segment == 4:
        vel_vec[5] = self.wrist_vel
        #self.user_cmd.linear.x = -self.user_cmd.linear.x
        #vel_vec[5] = 0
        #print self.robot.GetActiveDOFValues()

    if self.user_cmd.linear.x < self.joy_thresh:
        vel_vec = [0]*8
    joint_vel_msg = vel_vec
    self.handler.handle(joint_vel_msg)
    m = self.robot.GetActiveManipulator()
    eef_position = m.GetEndEffectorTransform()[:3,3]
    print eef_position
    #print m.GetEndEffectorTransform()
    robot_pose_sub = self.robot.GetTransform()[:3,3]
    print robot_pose_sub
    print "---------------------------------------------"
    eef_pos = Twist()
    eef_pos.linear.x = eef_position[0]-robot_pose_sub[0]
    eef_pos.linear.y = eef_position[1]-robot_pose_sub[1]
    eef_pos.linear.z = eef_position[2]-robot_pose_sub[2]
    self.pub.publish(eef_pos)



  def calc_shortest_ang(self, cur_goal, cur_pos):
      dist_vec = numpy.zeros(6)
      no_limit_idxs = [0,3,4,5]
      for idx in range(6):
          if idx in no_limit_idxs:
              dist_vec[idx] = self.calc_helper(cur_goal[idx], cur_pos[idx])
          else:
              dist_vec[idx] = cur_goal[idx] - cur_pos[idx]
      return dist_vec

  def calc_helper(self, cur_goal_ang, cur_pos_ang):

      new_goal_ang = (cur_goal_ang + numpy.pi) % (2.0*numpy.pi) - numpy.pi
      new_cur_ang = (cur_pos_ang + numpy.pi) % (2.0*numpy.pi) - numpy.pi
      ang = new_goal_ang-new_cur_ang
      new_ang = (ang + numpy.pi) % (2.0*numpy.pi) - numpy.pi

      return new_ang

if __name__ == "__main__":

    rospy.init_node('icorr')

    adaManipulationTester = ADAmanipulationTester()
    adaManipulationTester.initSimple()
    adaManipulationTester.planAndExecuteTrajectorySimple()
