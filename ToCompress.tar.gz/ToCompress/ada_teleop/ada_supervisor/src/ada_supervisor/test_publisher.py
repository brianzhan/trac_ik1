#!/usr/bin/env python


import rospy
from std_msgs.msg import String, Float32MultiArray, Float64
from std_msgs.msg import MultiArrayDimension

def talker():
    pub = rospy.Publisher('vell_input', Float32MultiArray, queue_size=1)
    rospy.init_node('talker', anonymous=True)
    r = rospy.Rate(10) # 10hz
    mc = Float32MultiArray()
    mc.data = [0,0,0.05,0,0,0,0,0]
    mc.layout.dim = [MultiArrayDimension()]
    mc.layout.dim [0].label = 'cartesian_velocity'
    mc.layout.dim [0].size = 8
    mc.layout.dim [0].stride = 8
    counter = 1
    while not rospy.is_shutdown():
        pub.publish(mc)
        r.sleep()
        counter = counter + 1
        if counter > 50:
           mc.data = [0,0,-0.05,0,0,0,0,0]
        if counter > 100:
           mc.data = [0,0,0,0,0,0,0,0]
        
if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException: pass
