#!/usr/bin/env python
import rospy
import numpy as np
import openravepy
import std_msgs.msg
from std_msgs.msg import Float32MultiArray
from std_msgs.msg import MultiArrayDimension
from std_msgs.msg import Float64
import controller_manager_msgs.srv
import adapy
#import ada_supervisor.srv

pub = []
sub_control_input = None
srv_switch_controller_set = None

# NOTE: This is running very fast, so any slow statements will cause
#       significant lag. This includes rospy.loginfo statements.
def interpret_control_input(msg):
  msg_type = msg.layout.dim[0].label
  msg_len = msg.layout.dim[0].size
  
  #rospy.loginfo('Msg: %s' % (str(msg.data)))
  
  if msg_type == 'cartesian_velocity':
    ik_sol = perform_ik(msg.data)
    send_joint_vel(ik_sol)
  elif msg_type == 'joint_velocity':
    send_joint_vel(msg.data)
  elif msg_type == 'cartesian_position':
    pass
  elif msg_type == 'joint_position':
    pass
  else:
    rospy.logerr('Unknown control_input type')


def perform_ik(msg_data, robot):
    manip = robot.GetActiveManipulator()
    J_xyz = np.matrix(manip.CalculateJacobian())
    J_inv = np.linalg.pinv(J_xyz)
    joint_vel = J_inv*np.transpose(np.matrix(msg_data))

    return joint_vel

  
def send_joint_vel(msg_data):
  if len(msg_data) == len(pub): # wait until all publishers are initiallized
    for ii in range(0,len(msg_data)):
      pub[ii].publish(data=msg_data[ii])

def get_currently_running_controllers():
  try:
    srvcli = rospy.ServiceProxy(
      'controller_manager/list_controllers',
      controller_manager_msgs.srv.ListControllers,
      persistent=False)
    resp = srvcli()
    return [c.name for c in resp.controller if c.state == 'running']
  except rospy.ServiceException as ex:
    return []

def cb_switch_controller_set(req):
  
  # get current controllers
  set_current = set(get_currently_running_controllers())
  
  # get desired controllers
  if req.setname == 'jvel':
    set_desired = set(['joint_state_controller','velocity_joint_mode_controller']+['vel_{}_controller'.format(s) for s in ['j1','j2','j3','j4','j5','j6','f1','f2']])
  elif req.setname == 'jpos':
    set_desired = set(['joint_state_controller','position_joint_mode_controller']+['pos_{}_controller'.format(s) for s in ['j1','j2','j3','j4','j5','j6','f1','f2']])
  elif req.setname == 'jtraj':
    set_desired = set(['joint_state_controller','position_joint_mode_controller','traj_controller'])
  else:
    res = ada_supervisor.srv.SwitchControllerSetResponse()
    res.ok = False
    res.reason = 'set name not known! try [jpos|jvel|jtraj]'
    return res
    
  # perform switch
  clireq = controller_manager_msgs.srv.SwitchControllerRequest()
  clireq.stop_controllers = list(set_current - set_desired)
  clireq.start_controllers = list(set_desired - set_current)
  clireq.strictness = controller_manager_msgs.srv.SwitchControllerRequest.STRICT
  try:
    srvcli = rospy.ServiceProxy(
      'controller_manager/switch_controller',
      controller_manager_msgs.srv.SwitchController,
      persistent=False)
    clires = srvcli(clireq)
    if not clires.ok:
      res = ada_supervisor.srv.SwitchControllerSetResponse()
      res.ok = False
      res.reason = 'service returned failure!'
      return
  except rospy.ServiceException as ex:
    res = ada_supervisor.srv.SwitchControllerSetResponse()
    res.ok = False
    res.reason = 'service call failed: {}'.format(ex)
    return res
  
  res = ada_supervisor.srv.SwitchControllerSetResponse()
  res.ok = True
  return res

def init_subscribers():
  sub_control_input = rospy.Subscriber('control_input', Float32MultiArray, interpret_control_input)
 # srv_switch_controller_set = rospy.Service('switch_controller_set', ada_supervisor.srv.SwitchControllerSet, cb_switch_controller_set)

def init_publishers():

  pub.append(rospy.Publisher('vel_j1_controller/command',Float64))
  pub.append(rospy.Publisher('vel_j2_controller/command',Float64))
  pub.append(rospy.Publisher('vel_j3_controller/command',Float64))
  pub.append(rospy.Publisher('vel_j4_controller/command',Float64))
  pub.append(rospy.Publisher('vel_j5_controller/command',Float64))
  pub.append(rospy.Publisher('vel_j6_controller/command',Float64))
  pub.append(rospy.Publisher('vel_f1_controller/command',Float64))
  pub.append(rospy.Publisher('vel_f2_controller/command',Float64))
  
def init_openrave(viewer=True):
    env, robot = adapy.initialize(sim=True, attach_viewer=viewer)

    c = openravepy.RaveCreateController(env, 'roscontroller openrave / 1')
    robot.SetController(c, range(8), 0)

    colchecker = openravepy.RaveCreateCollisionChecker(env, 'ode')
    env.SetCollisionChecker(colchecker)

    inds, pos = robot.configurations.get_configuration('home')

    return env, robot

if __name__ == '__main__':

  rospy.init_node('ada_supervisor', anonymous=False) #do not allow multiple at once.
  rospy.loginfo('ada_supervisor_node running...')
  init_subscribers()
  init_publishers()
  env, robot = init_openrave()
  rospy.spin()
