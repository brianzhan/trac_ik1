#!/usr/bin/env python
import numpy
import openravepy
import adapy
import prpy
import numpy as np
import math
import tf
import rospkg
import sys
import os
import time
import rospy
import IPython
from IPython import embed
from threading import Timer
from time import sleep
from std_msgs.msg import String
from visualization_msgs.msg import Marker, MarkerArray
from tf.transformations import quaternion_matrix,quaternion_from_matrix
from prpy.tsr.tsrlibrary import TSRFactory
from prpy.tsr.tsr import *
from adapy.tsr import glass as glassUtils
from tasklogger import TaskLogger
from perception.msg import Segments
import sensor_msgs.point_cloud2 as pc2
from sensor_msgs.msg import Joy, PointCloud, PointCloud2, PointField, Image


startConfiguration = np.asarray([-0.59226119, -0.80147511,  0.60337137,  3.06410745, -0.94669731,-2.833287])

class ADAmanipulationTester:

  def initSimple(self):

	  
	  self.Initialized = False
	  rospy.init_node('ada_meal_scenario', anonymous = True)
	  env_path = '/environments/tablewithglass.env.xml'
	  openravepy.RaveInitialize(True, level=openravepy.DebugLevel.Debug)
	  openravepy.misc.InitOpenRAVELogging();
	  self.env, self.robot = adapy.initialize(attach_viewer='qtcoin', sim=True, env_path = env_path)
	  self.manip = self.robot.arm
	  inds, pos = self.robot.configurations.get_configuration('home')	  
	  self.robot.SetDOFValues(self.robot.GetDOFValues())
	   # find the ordata
	  rospack = rospkg.RosPack()
	  file_root = rospack.get_path('pr_ordata')
	  #file_root = rospack.get_path('ada_description')
	  # self.glass.SetTransform(glass_pose)
	  self.table = self.env.GetKinBody('table')
	  table_trans = self.table.GetTransform()
	  table_trans[2,3] = table_trans[2,3] - 0.02
	  self.table.SetTransform(table_trans)
	  self.glass = self.env.GetKinBody('glass')
	  self.bowl = self.env.GetKinBody('bowl')
	  self.env.RemoveKinBody(self.glass)
	  self.env.RemoveKinBody(self.bowl)
	  # self.env.RemoveKinBody(self.table)
	  robot_pose = numpy.eye(4)
	  self.robot.SetTransform(robot_pose)
	  ViewSide1Obj = self.env.GetKinBody('ViewSide1')
	  ViewSide1Trans = ViewSide1Obj.GetTransform()
	  ViewSide2Obj = self.env.GetKinBody('ViewSide2')
	  ViewSide2Trans = ViewSide2Obj.GetTransform()
	  ViewTopObj = self.env.GetKinBody('ViewTop')
	  ViewTopTrans = ViewTopObj.GetTransform()
	  viewer = self.env.GetViewer()
	  #viewer.SetCamera(ViewTopTrans)
	  self.trajectoryPlanned = True	  
	  self.manip = self.robot.arm	  
	  activedofs = [i for i in range(6)]
	  self.robot.SetActiveDOFs(activedofs) 
	  self.robot.planner = prpy.planning.Sequence(self.robot.cbirrt_planner)      		  
	  traj = self.manip.PlanToConfiguration(startConfiguration)
	  time.sleep(8)
	  self.Initialized = True
	  
	  global plotlist, first, centarray, Bodies_Array, grasper
	  grasper = openravepy.interfaces.Grasper(self.robot)
	  first = True
	  Bodies_Array = []
	  centarray = []
	  self.sub = rospy.Subscriber('segments_array', Segments, self.pcloudCallback, queue_size=1)	    

	  rospy.spin()    


  def pcloudCallback(self, message):
	global plotlist, first, centarray, Bodies_Array, grasper
	color = np.array([.65, 0, 1])
	data = message.pointClouds	
	pcs = []
	for i in range(0, len(data)):
		pcs.append(pc2.read_points(data[i], skip_nans=True))

	pccoords = []
	for i in range(0, len(pcs)):
		pccoords.append(list(pcs[i]))

	pcarrays = []
	for i in range(0, len(pccoords)):
		pcarrays.append(np.array(pccoords[i]))

	plotlist = []
	for i in range(0, len(pcarrays)):
		plot = self.env.plot3(pcarrays[i], 1, color)
		plotlist.append(plot)

	poss = []
	exts = []
	for i in range(0, len(pccoords)):
		firstiter = True
		for j in range(0, len(pccoords[i])):
			if firstiter:
				xmax = pccoords[i][j][0]
				xmin = pccoords[i][j][0]
				ymax = pccoords[i][j][1]
				ymin = pccoords[i][j][1]
				zmax = pccoords[i][j][2]
				zmin = pccoords[i][j][2]

			if xmax < pccoords[i][j][0]:
				xmax = pccoords[i][j][0]
			elif xmin > pccoords[i][j][0]:
				xmin = pccoords[i][j][0]

			if ymax < pccoords[i][j][1]:
				ymax = pccoords[i][j][1]
			elif ymin > pccoords[i][j][1]:
				ymin = pccoords[i][j][1]

			if zmax < pccoords[i][j][2]:
				zmax = pccoords[i][j][2]
			elif zmin > pccoords[i][j][2]:
				zmin = pccoords[i][j][2]

			firstiter = False

		poss.append([(xmax + xmin)/2, (ymax+ymin)/2, (zmax+zmin)/2])
		exts.append([(xmax-xmin)/2, (ymax-ymin)/2, (zmax-zmin)/2])

	tmeshs = []
	for i in range(0, len(pccoords)):
		points = np.zeros((len(pccoords[i]), 3), np.double)
		for j,p in enumerate(pccoords[i]):
			points[j, 0] = p[0]
			points[j, 1] = p[1]
			points[j, 2] = p[2]
		planes, faces, triangles = grasper.ConvexHull(points, returntriangles=True)
		usedindices = np.zeros(len(points), int)
		usedindices[triangles.flatten()] = 1
		pointindices = np.flatnonzero(usedindices)
		pointindicesinv = np.zeros(len(usedindices))
		pointindicesinv[pointindices] = range(len(pointindices))
		vertices = points[pointindices]
		indices = np.reshape(pointindicesinv[triangles.flatten()], triangles.shape)
		tempmesh = openravepy.TriMesh(vertices=vertices, indices=indices)
		tmeshs.append(tempmesh)

	if (len(Bodies_Array) > len(pccoords)):
		for i in range(0, len(Bodies_Array)-len(pccoords)):
			self.env.Remove(Bodies_Array[len(pccoords)+i])
			self.env.Remove(centarray[len(pccoords)+i])
			Bodies_Array.pop(len(pccoords)+i)
			centarray.pop(len(pccoords)+i)

	for i in range(0, len(pccoords)):
		if first:
			temp = openravepy.RaveCreateKinBody(self.env, '')
			tempname = "body%d" % i
			temp.SetName(tempname)
			temp.InitFromTrimesh(tmeshs[i])
			self.env.Add(temp, anonymous=True)
			Bodies_Array.append(temp)

			temp2 = self.env.ReadKinBodyXMLFile('data/rsmallsphere.kinbody.xml')
			self.env.Add(temp2, anonymous=True)
			centtrans = np.array([[1,0,0,poss[i][0]], [0,1,0,poss[i][1]], [0,0,1,poss[i][2]], [0,0,0,1]])
			temp2.SetTransform(centtrans)
			centarray.append(temp2)
		elif not first and (i >= len(Bodies_Array)):
			temp = openravepy.RaveCreateKinBody(self.env, '')
			tempname = "body%d" % i
			temp.SetName(tempname)
			temp.InitFromTrimesh(tmeshs[i])
			self.env.Add(temp, anonymous=True)
			Bodies_Array.append(temp)

			temp2 = self.env.ReadKinBodyXMLFile('data/rsmallsphere.kinbody.xml')
			self.env.Add(temp2, anonymous=True)
			centtrans = np.array([[1,0,0,poss[i][0]], [0,1,0,poss[i][1]], [0,0,1,poss[i][2]], [0,0,0,1]])
			temp2.SetTransform(centtrans)
			centarray.append(temp2)
		else:
			temp = Bodies_Array[i]
			self.env.Remove(temp)
			temp.InitFromTrimesh(tmeshs[i])
			self.env.Add(temp, anonymous=True)
			Bodies_Array[i] = temp
			centtrans = np.array([[1,0,0,poss[i][0]], [0,1,0,poss[i][1]], [0,0,1,poss[i][2]], [0,0,0,1]])
			centarray[i].SetTransform(centtrans)

	# aa = centarray[1]
	# bb = aa.GetTransform()
	# cc = np.array([[0.0, 1.0, 0, bb[0][3]], [-1.0, 0.0, 0.0, bb[1][3]], [0.0, 0.0, 1.0, bb[2][3]], bb[3]])

	first = False
	# embed()  
	
if __name__ == "__main__":
	adaManipulationTester = ADAmanipulationTester()
	adaManipulationTester.initSimple() 