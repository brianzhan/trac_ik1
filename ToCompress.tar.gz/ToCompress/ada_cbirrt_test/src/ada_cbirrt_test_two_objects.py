#!/usr/bin/env python

import numpy
#import roslib
#mport rospy
import openravepy
import adapy
import prpy
import numpy as np


from IPython import embed
import tf
import rospkg

import os
import time

#from ar_track_alvar.msg import AlvarMarkers
from sensor_msgs.msg import JointState

import IPython

from prpy.tsr.tsrlibrary import TSRFactory
from prpy.tsr.tsr import *
@TSRFactory('ada', 'glass', 'grasp')
def move_glass(robot, glass, manip=None):
    '''
    @param robot The robot performing the grasp
    @param glass The glass to grasp
    @param manip The manipulator to perform the grasp, if None
       the active manipulator on the robot is used
    '''
    if manip is None:
        manip_idx = robot.GetActiveManipulatorIndex()
    else:
        with manip.GetRobot():
            manip.SetActive()
            manip_idx = manip.GetRobot().GetActiveManipulatorIndex()

    T0_w = glass.GetTransform()
    Tw_e = numpy.array([[ 0., 0., -1., -0.22], 
                          [-1., 0., 0., 0.1], 
                          [0., 1., 0., 0.28], 
                          [0., 0., 0., 1.]])

    Bw = numpy.zeros((6,2))
    Bw[2,:] = [-0.02, 0.02]# Allow a little vertical movement
    #Bw[5,:] = [-numpy.pi, numpy.pi]  # Allow any orientation
    
    grasp_tsr = TSR(T0_w = T0_w, Tw_e = Tw_e, Bw = Bw, manip = manip_idx)
    grasp_chain = TSRChain(sample_start=False, sample_goal = True, constrain=False, TSR = grasp_tsr)

    return [grasp_chain]

@TSRFactory('ada', 'glass', 'grasp')
def grasp_object(robot, object, manip=None):
    '''
    @param robot The robot performing the grasp
    @param glass The glass to grasp
    @param manip The manipulator to perform the grasp, if None
       the active manipulator on the robot is used
    '''
    if manip is None:
        manip_idx = robot.GetActiveManipulatorIndex()
    else:
        with manip.GetRobot():
            manip.SetActive()
            manip_idx = manip.GetRobot().GetActiveManipulatorIndex()

    T0_w = object.GetTransform()

    Tw_e = numpy.array([[ 0., 0., -1., -0.02], 
                          [-1., 0., 0., 0.], 
                          [0., 1., 0., 0.08], 
                          [0., 0., 0., 1.]])


    Bw = numpy.zeros((6,2))
    Bw[2,:] = [-0.02, 0.02]  # Allow a little vertical movement

    Bw[5,:] = [-numpy.pi/3, numpy.pi/3]  # Allow any orientation
    
    grasp_tsr = TSR(T0_w = T0_w, Tw_e = Tw_e, Bw = Bw, manip = manip_idx)
    grasp_chain = TSRChain(sample_start=False, sample_goal = True, constrain=False, TSR = grasp_tsr)

    return [grasp_chain]


class ADAmanipulationTester:
  def initSimple(self):
      openravepy.RaveInitialize(True, level=openravepy.DebugLevel.Debug)
      openravepy.misc.InitOpenRAVELogging();
      self.env, self.robot = adapy.initialize(attach_viewer=True, sim=True)
      self.manip = self.robot.arm
      inds, pos = self.robot.configurations.get_configuration('home')
      pos[1] = -1.57;
      pos[2] = 0;
      self.robot.SetDOFValues(pos, inds, openravepy.KinBody.CheckLimitsAction.Nothing)

      # find the ordata
      rospack = rospkg.RosPack()
      file_root = rospack.get_path('pr_ordata')
     
      # load the table
      table_name = 'table'
      #table_xml = os.path.join(file_root, 'ordata', 'objects', 'furniture', 'table.kinbody.xml')
      table_xml = os.path.join(file_root, 'data', 'furniture', 'table.kinbody.xml')

      table_pose = numpy.array([[ 1,   0,   0,  8.75423792e-01],
                        [ 0,  0,  -1,  6.32824451e-02],
                        [ 0,  1,   0,  0],
                        [  0,   0,   0,  1]])
      self.table = prpy.rave.add_object(self.env, table_name, table_xml, table_pose)
      self.table_aabb = self.table.ComputeAABB()
      

      # # load a glass
      glass_name = 'glass'
      glass_xml = os.path.join(file_root, 'data', 'objects', 'glass.kinbody.xml')
      glass_pose = numpy.eye(4)
      self.glass = prpy.rave.add_object(self.env, glass_name, glass_xml, glass_pose)
      glass_aabb = self.glass.ComputeAABB()
      
      glass_pose[2,3] = 2*self.table_aabb.extents()[2] -0.05# 0.005
      glass_pose[0,3] = self.table_aabb.pos()[0] - 0.5*self.table_aabb.extents()[0] + 0.6
      glass_pose[1,3] = self.table_aabb.pos()[1] - 0.1
      self.glass.SetTransform(glass_pose)

      #load a fuze bottle
      fuze_name = 'fuze_bottle'
      fuze_xml = os.path.join(file_root, 'data', 'objects', 'fuze_bottle.kinbody.xml')
      fuze_pose = numpy.eye(4)
      self.fuze = prpy.rave.add_object(self.env, fuze_name, fuze_xml, fuze_pose)
      fuze_aabb = self.fuze.ComputeAABB()
      
      fuze_pose[2,3] = 2*self.table_aabb.extents()[2] -0.05
      fuze_pose[0,3] = self.table_aabb.pos()[0] - 0.5*self.table_aabb.extents()[0] + 0.6
      fuze_pose[1,3] = self.table_aabb.pos()[1] + 0.2
      self.fuze.SetTransform(fuze_pose)
      
      robot_pose = glass_pose
      robot_pose[0,3] = glass_pose[0,3] - 0.5
      robot_pose[1,3] = glass_pose[1,3] + 0.1
      robot_pose[2,3] = 2*self.table_aabb.extents()[2] +0.06
      self.robot.SetTransform(robot_pose)
      #embed()


      self.trajectoryPlanned = False

  def planAndExecuteTrajectorySimple(self):     

      manip = self.robot.arm
      self.robot.SetActiveManipulator(manip)
      activedofs = [i for i in range(6)]
      self.robot.SetActiveDOFs(activedofs)
      #start_ik = manip.GetDOFValues()
      #embed()



      self.robot.planner = prpy.planning.Sequence(self.robot.cbirrt_planner) 

      grasp_glass_chains = grasp_object(self.robot, self.glass)

      grasp_fuze_chains = grasp_object(self.robot, self.fuze)
      #move_chain = move_chains[0]
      
      manip.PlanToTSR(grasp_glass_chains)

      manip.hand.CloseHand()

      #self.robot.arm.hand.CloseHand()

      
      #self.robot.Grab(self.glass)
      
      #move_chains = move_glass(self.robot, self.glass)
      
      #manip.PlanToConfiguration(start_ik)

      #manip.PlanToTSR(grasp_glass_chains)

        
      #embed()
      
  def joint_states_callback(self, msg):
      #self.lock.acquire()
      name = msg.name
      position = msg.position
      velocity = msg.velocity
      effort = msg.effort
      #self.lock.release()
      
      print "name: ", name, " joint positions: ", position
      
      jointIndices = []
      jointValues = []
      
      for n in name:
           jointIndices.append(self.robot.GetJointIndex(n))
           jointValues.append(position[name.index(n)])
      
      self.robot.SetDOFValues(jointValues, jointIndices)
  
  def startVideo(self):
      self.recorder = openravepy.RaveCreateModule(self.env,'viewerrecorder')
      self.env.AddModule(self.recorder,'')
      codecs = self.recorder.SendCommand('GetCodecs') # linux only
      filePath = os.path.abspath(os.path.join(os.path.join(os.path.realpath(__file__), os.pardir), os.pardir)) 
      print "Reading poses from file ... "
      fileName = filePath + '/data/videos/graspVideo.mpg'
      codec = 13 # mpeg4
      self.recorder.SendCommand('Start 640 480 30 codec %d timing realtime filename %s\nviewer %s'%(codec,fileName,self.env.GetViewer().GetName()))
  def stopVideo(self):
      self.recorder.SendCommand('Stop') # stop the video
      self.env.Remove(self.recorder) # remove the recorder


    
if __name__ == "__main__":

    adaManipulationTester = ADAmanipulationTester()
    adaManipulationTester.initSimple()
    adaManipulationTester.startVideo()
    adaManipulationTester.planAndExecuteTrajectorySimple()
    adaManipulationTester.stopVideo()
    #embed()
