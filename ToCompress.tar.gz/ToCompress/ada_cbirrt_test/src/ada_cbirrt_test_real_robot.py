#!/usr/bin/env python

import numpy
#import roslib
#mport rospy
import openravepy
import adapy
import prpy
import numpy as np


from IPython import embed
import tf
import rospkg

import os
import time

#from ar_track_alvar.msg import AlvarMarkers
from sensor_msgs.msg import JointState

#rom TransformMatrix import *
#from str2num import *

import IPython

from prpy.tsr.tsrlibrary import TSRFactory
from prpy.tsr.tsr import *

class ADAmanipulationTester:
  def initSimple(self):
      openravepy.RaveInitialize(True, level=openravepy.DebugLevel.Debug)
      openravepy.misc.InitOpenRAVELogging();
      
      env_path = '/environments/tablewithglass.env.xml'
      self.env, self.robot = adapy.initialize(attach_viewer=True, sim=False,  env_path = env_path)
  
      self.glass = self.env.GetKinBody('glass')

      robot_pose = numpy.array([[1, 0, 0, 0.409],[0, 1, 0, 0.338],[0, 0, 1, 0.795],[0, 0, 0, 1]])
      self.robot.SetTransform(robot_pose)

      ViewSide1Obj = self.env.GetKinBody('ViewSide1')
      ViewSide1Trans = ViewSide1Obj.GetTransform()

      ViewSide2Obj = self.env.GetKinBody('ViewSide2')
      ViewSide2Trans = ViewSide2Obj.GetTransform()

      ViewTopObj = self.env.GetKinBody('ViewTop')
      ViewTopTrans = ViewTopObj.GetTransform()

      viewer = self.env.GetViewer()
      viewer.SetCamera(ViewTopTrans)


      self.trajectoryPlanned = False

  def planAndExecuteTrajectorySimple(self):     

      manip = self.robot.arm
      #self.robot.SetActiveManipulator(manip)
      activedofs = [i for i in range(6)]
      self.robot.SetActiveDOFs(activedofs)

      self.robot.tsrlibrary(self.glass, 'grasp')

      self.robot.arm.hand.OpenHand()

      embed()

      time.sleep(3.0)


      # #move_chain = move_chains[0]
      self.robot.PlanToTSR(self.robot.tsrlibrary(self.glass, 'grasp'))

      reached = False
      distThres = 0.1
      while(reached == False):
         glassPose = self.glass.GetTransform()
         glassPos = numpy.array([glassPose[0,3],glassPose[1,3],glassPose[2,3]])
         robotPose = manip.GetEndEffectorTransform()
         robotPos = numpy.array([robotPose[0,3],robotPose[1,3],robotPose[2,3]])
         if(numpy.linalg.norm(robotPos-glassPos) < distThres):
              print "*******target reached!************"
              reached = True
              time.sleep(1.0)

              self.robot.arm.hand.CloseHand()
              self.robot.Grab(self.glass)

      reached = False
      activedofs = [i for i in range(8)]
      self.robot.SetActiveDOFs(activedofs)
      while(reached == False):
        values = self.robot.GetActiveDOFValues()
        target_finger_pos = numpy.array([0.8,0.8])
        current_pos = numpy.array([values[6], values[7]])
        #embed()
        if(numpy.linalg.norm(current_pos - target_finger_pos)<0.1):
            reached = True
            #print "reached point!"
            with prpy.rave.Disabled(self.glass):
               self.robot.PlanToTSR(self.robot.tsrlibrary(self.glass,'move'))

      time.sleep(2)
      self.robot.arm.hand.OpenHand()



      #embed()
     
   
      
  def joint_states_callback(self, msg):
      #self.lock.acquire()
      name = msg.name
      position = msg.position
      velocity = msg.velocity
      effort = msg.effort
      #self.lock.release()
      
      print "name: ", name, " joint positions: ", position
      
      jointIndices = []
      jointValues = []
      
      for n in name:
           jointIndices.append(self.robot.GetJointIndex(n))
           jointValues.append(position[name.index(n)])
      
      self.robot.SetDOFValues(jointValues, jointIndices)
  
  def startVideo(self):
      self.recorder = openravepy.RaveCreateModule(self.env,'viewerrecorder')
      self.env.AddModule(self.recorder,'')
      codecs = self.recorder.SendCommand('GetCodecs') # linux only
      filename = 'testGrasp.mpg'
      codec = 13 # mpeg4
      self.recorder.SendCommand('Start 640 480 30 codec %d timing realtime filename %s\nviewer %s'%(codec,filename,self.env.GetViewer().GetName()))
  def stopVideo(self):
      self.recorder.SendCommand('Stop') # stop the video
      self.env.Remove(self.recorder) # remove the recorder


    
if __name__ == "__main__":
    adaManipulationTester = ADAmanipulationTester()
    adaManipulationTester.initSimple()
    adaManipulationTester.startVideo()
    adaManipulationTester.planAndExecuteTrajectorySimple()
    adaManipulationTester.stopVideo()
    #embed()
