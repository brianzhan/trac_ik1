#!/usr/bin/env python

import numpy
#import roslib
#mport rospy
import openravepy
import adapy
import prpy
import numpy as np


from IPython import embed
import tf
import rospkg

import os, time, scipy, math, sys

#from ar_track_alvar.msg import AlvarMarkers
from sensor_msgs.msg import JointState

import IPython

from prpy.tsr.tsrlibrary import TSRFactory
from prpy.tsr.tsr import *
@TSRFactory('ada', 'glass', 'grasp')
def move_glass(robot, glass, manip=None):
    '''
    @param robot The robot performing the grasp
    @param glass The glass to grasp
    @param manip The manipulator to perform the grasp, if None
       the active manipulator on the robot is used
    '''
    if manip is None:
        manip_idx = robot.GetActiveManipulatorIndex()
    else:
        with manip.GetRobot():
            manip.SetActive()
            manip_idx = manip.GetRobot().GetActiveManipulatorIndex()

    T0_w = glass.GetTransform()
    Tw_e = numpy.array([[ 0., 0., -1., -0.22], 
                          [-1., 0., 0., 0.1], 
                          [0., 1., 0., 0.28], 
                          [0., 0., 0., 1.]])

    Bw = numpy.zeros((6,2))
    Bw[2,:] = [-0.02, 0.02]# Allow a little vertical movement
    #Bw[5,:] = [-numpy.pi, numpy.pi]  # Allow any orientation
    
    grasp_tsr = TSR(T0_w = T0_w, Tw_e = Tw_e, Bw = Bw, manip = manip_idx)
    grasp_chain = TSRChain(sample_start=False, sample_goal = True, constrain=False, TSR = grasp_tsr)

    return [grasp_chain]

@TSRFactory('ada', 'glass', 'grasp')
def grasp_object(robot, object, manip=None):
    '''
    @param robot The robot performing the grasp
    @param glass The glass to grasp
    @param manip The manipulator to perform the grasp, if None
       the active manipulator on the robot is used
    '''
    if manip is None:
        manip_idx = robot.GetActiveManipulatorIndex()
    else:
        with manip.GetRobot():
            manip.SetActive()
            manip_idx = manip.GetRobot().GetActiveManipulatorIndex()

    T0_w = object.GetTransform()

    Tw_e = numpy.array([[ 0., 0., -1., -0.02], 
                          [-1., 0., 0., 0.], 
                          [0., 1., 0., 0.08], 
                          [0., 0., 0., 1.]])


    Bw = numpy.zeros((6,2))
    Bw[2,:] = [-0.02, 0.02]  # Allow a little vertical movement

    Bw[5,:] = [-numpy.pi/4, numpy.pi/4]  # Allow any orientation
    
    grasp_tsr = TSR(T0_w = T0_w, Tw_e = Tw_e, Bw = Bw, manip = manip_idx)
    grasp_chain = TSRChain(sample_start=False, sample_goal = True, constrain=False, TSR = grasp_tsr)

    return [grasp_chain]


class ADAmanipulationTester:
  def initSimple(self):
      openravepy.RaveInitialize(True, level=openravepy.DebugLevel.Debug)
      openravepy.misc.InitOpenRAVELogging();
      self.env, self.robot = adapy.initialize(attach_viewer=True, sim=True)
      self.manip = self.robot.arm
      self.inds, self.pos = self.robot.configurations.get_configuration('home')
      self.pos[1] = -1.57;
      self.pos[2] = 0;
      self.robot.SetDOFValues(self.pos, self.inds, openravepy.KinBody.CheckLimitsAction.Nothing)
      self.start_dofs = self.manip.GetDOFValues()

      # find the ordata
      rospack = rospkg.RosPack()
      file_root = rospack.get_path('pr_ordata')
     
      # load the table
      table_name = 'table'
      #table_xml = os.path.join(file_root, 'ordata', 'objects', 'furniture', 'table.kinbody.xml')
      table_xml = os.path.join(file_root, 'data', 'furniture', 'table.kinbody.xml')

      table_pose = numpy.array([[ 1,   0,   0,  8.75423792e-01],
                        [ 0,  0,  -1,  6.32824451e-02],
                        [ 0,  1,   0,  0],
                        [  0,   0,   0,  1]])
      self.table = prpy.rave.add_object(self.env, table_name, table_xml, table_pose)
      self.table_aabb = self.table.ComputeAABB()
      

      # load a glass
      glass_name = 'glass'
      glass_xml = os.path.join(file_root, 'data', 'objects', 'glass.kinbody.xml')
      glass_pose = numpy.eye(4)
      self.glass = prpy.rave.add_object(self.env, glass_name, glass_xml, glass_pose)
      glass_aabb = self.glass.ComputeAABB()
      
      glass_pose[2,3] = 2*self.table_aabb.extents()[2] -0.05# 0.005
      glass_pose[0,3] = self.table_aabb.pos()[0] - 0.5*self.table_aabb.extents()[0] + 0.6
      glass_pose[1,3] = self.table_aabb.pos()[1] - 0.1
      self.glass.SetTransform(glass_pose)

      #load a fuze bottle
      fuze_name = 'fuze_bottle'
      fuze_xml = os.path.join(file_root, 'data', 'objects', 'fuze_bottle.kinbody.xml')
      fuze_pose = numpy.eye(4)
      self.fuze = prpy.rave.add_object(self.env, fuze_name, fuze_xml, fuze_pose)
      fuze_aabb = self.fuze.ComputeAABB()
      
      fuze_pose[2,3] = 2*self.table_aabb.extents()[2] -0.05
      fuze_pose[0,3] = self.table_aabb.pos()[0] - 0.5*self.table_aabb.extents()[0] + 0.6
      fuze_pose[1,3] = self.table_aabb.pos()[1] + 0.2
      self.fuze.SetTransform(fuze_pose)
      
      robot_pose = glass_pose
      robot_pose[0,3] = glass_pose[0,3] - 0.5
      robot_pose[1,3] = glass_pose[1,3] + 0.1
      robot_pose[2,3] = 2*self.table_aabb.extents()[2] +0.06
      self.robot_pose = robot_pose
      self.robot.SetTransform(robot_pose)



      # --------- camera setup ------------ #
      self.camTransReal = numpy.array([[-0.40655201, -0.10286847,  0.90781801, -0.67769653],
       [-0.9121957 ,  0.10131334, -0.39703227,  0.73053592],
       [-0.05113197, -0.98952195, -0.13502532,  1.19368148],
       [ 0.        ,  0.        ,  0.        ,  1.        ]])


      '''
      numpy.array([[  9.98824647e-01,  -1.61842016e-04,  -4.84695673e-02,  8.96796227e-01],
       [  4.72546790e-02,  -2.19260835e-01,   9.74521258e-01, -1.12947798e+00],
       [ -1.07851963e-02,  -9.75666265e-01,  -2.18995479e-01,  1.24580741e+00],
       [  0.00000000e+00,   0.00000000e+00,   0.00000000e+00,  1.00000000e+00]])
      '''
      self.camTransClear = numpy.array([[ 0.93787521,  0.18027989, -0.2964612 ,  1.32921386],
       [ 0.34134647, -0.32615532,  0.88153576, -0.9960916 ],
       [ 0.06223077, -0.92796652, -0.3674309 ,  1.44181561],
       [ 0.        ,  0.        ,  0.        ,  1.        ]])

      '''
      numpy.array([[ 0.43030747,  0.39467702, -0.81182851,  1.83874953],
       [ 0.90262676, -0.17814661,  0.39182741, -0.38194048],
       [ 0.01002077, -0.9013844 , -0.43290386,  1.47222519],
       [ 0.        ,  0.        ,  0.        ,  1.        ]])
      '''

      self.trajectoryPlanned = False

  def planTrajectorySimple(self):     

      manip = self.robot.arm
      self.robot.SetActiveManipulator(manip)
      activedofs = [i for i in range(6)]
      self.robot.SetActiveDOFs(activedofs)
      #start_ik = manip.GetDOFValues()
      #embed()



      self.robot.planner = prpy.planning.Sequence(self.robot.cbirrt_planner) 

      grasp_glass_chains = grasp_object(self.robot, self.glass)

      grasp_fuze_chains = grasp_object(self.robot, self.fuze)
      #move_chain = move_chains[0]

      self.traj = manip.PlanToTSR(grasp_glass_chains, execute=False)
      #self.robot.ExecuteTrajectory(self.traj)
      #manip.hand.CloseHand()

      #manip.PlanToConfiguration(start_ik)

      #manip.PlanToTSR(grasp_glass_chains)

        
      #embed()
      
  def joint_states_callback(self, msg):
      #self.lock.acquire()
      name = msg.name
      position = msg.position
      velocity = msg.velocity
      effort = msg.effort
      #self.lock.release()
      
      #print "name: ", name, " joint positions: ", position
      
      jointIndices = []
      jointValues = []
      
      for n in name:
           jointIndices.append(self.robot.GetJointIndex(n))
           jointValues.append(position[name.index(n)])
      
      self.robot.SetDOFValues(jointValues, jointIndices)
  
  def startVideo(self, name):
      self.recorder = openravepy.RaveCreateModule(self.env,'viewerrecorder')
      self.env.AddModule(self.recorder,'')
      codecs = self.recorder.SendCommand('GetCodecs') # linux only
      filePath = os.path.abspath(os.path.join(os.path.join(os.path.realpath(__file__), os.pardir), os.pardir)) 
      print "Reading poses from file ... "
      fileName = filePath + '/data/videos/testVideo.mpg'
      codec = 13 # mpeg4
      self.recorder.SendCommand('Start 640 480 30 codec %d timing realtime filename %s\nviewer %s'%(codec,fileName,self.env.GetViewer().GetName()))
  
  def stopVideo(self):
      self.recorder.SendCommand('Stop') # stop the video
      self.env.Remove(self.recorder) # remove the recorder

  # Gets images for both real and clear camera transforms, and clutter/noclutter
  def getImages(self, imageName):
      print 'Getting images...'
      viewer = self.env.GetViewer()
      filePath = os.path.abspath(os.path.join(os.path.join(os.path.realpath(__file__), os.pardir), os.pardir)) 
      fileNameRealClutter = filePath + '/data/images/' + imageName + '_real_clutter' + '.png'
      fileNameClearClutter = filePath + '/data/images/' + imageName + '_clear_clutter' + '.png'
      fileNameRealFree = filePath + '/data/images/' + imageName + '_real_free' + '.png'
      fileNameClearFree = filePath + '/data/images/' + imageName + '_clear_free' + '.png'

      # take image in real camera transform, then in the clear one
      print 'Getting camera transform images'

      viewer.SetCamera(self.camTransReal)
      self.fuze.SetVisible(False)
      self.glass.SetVisible(True)
      imRealClutter = viewer.GetCameraImage(1280*2, 720*2, self.camTransReal, [800*2, 800*2, 640*2, 360*2])
      print 'real pov with clutter taken'

      # clear point of view, no clutter
      self.fuze.SetVisible(True)
      self.glass.SetVisible(True)
      imRealFree = viewer.GetCameraImage(1280*2, 720*2, self.camTransReal, [800*2, 800*2, 640*2, 360*2])
      print 'real pov with no clutter taken'

      # clear point of view, 
      viewer.SetCamera(self.camTransClear)

      self.fuze.SetVisible(False)
      self.glass.SetVisible(True)
      imClearClutter = viewer.GetCameraImage(1280*2, 720*2, self.camTransClear, [800*2, 800*2, 640*2, 360*2])
      print 'clear pov with clutter taken'

      # clear point of view, no clutter
      self.fuze.SetVisible(True)
      self.glass.SetVisible(True)
      imClearFree = viewer.GetCameraImage(1280*2, 720*2, self.camTransClear, [800*2, 800*2, 640*2, 360*2])

      self.fuze.SetVisible(True)
      print 'clear pov with no clutter taken'

      print 'Saving images...'
      scipy.misc.imsave(fileNameRealClutter, imRealClutter)
      scipy.misc.imsave(fileNameRealFree, imRealFree)
      scipy.misc.imsave(fileNameClearClutter, imClearClutter)
      scipy.misc.imsave(fileNameClearFree, imClearFree)
      print 'Image capture complete'
  
  # object goal only - NEED TO ADD IN CLUTTER AS WELL
  def imgGoal(self):
    print 'Image goal only'
    self.robot.SetVisible(False)

    time.sleep(1)
    self.getImages('goal')
    time.sleep(1)

    # reset positions/images
    self.robot.SetVisible(True)
    self.fuze.SetVisible(True)

  def imgConfigs(self):
    print 'Final configuration for grasping object, start config transparent'

    # move main robot out of the way before adding new one to avoid collision planning errors
    self.robot.ExecuteTrajectory(self.traj)
    self.final_dofs = self.manip.GetDOFValues()
    self.manip.hand.CloseHand()

    self.loadStartConfigRobot()

    time.sleep(1)
    self.getImages('configs')
    time.sleep(1)

    # reset
    self.removeStartConfigRobot()
    self.robot.SetDOFValues(self.pos, self.inds, openravepy.KinBody.CheckLimitsAction.Nothing)
    self.manip.hand.OpenHand()

    self.fuze.SetVisible(True)
    self.glass.SetVisible(True)


  def removeBalls(self):
    for ball in self.ballList:
      self.env.Remove(ball)

  def loadStartConfigRobot(self):
    # initialize second robot in starting configuration
    self.r2 = self.env.ReadRobotXMLFile('/homes/njassal/catkin_ws/src/ada/ada_description/ordata/robots/mico-modified.robot2.xml')
    self.r2.SetName('r2')
    self.env.AddKinBody(self.r2)
    self.r2.SetTransform(self.robot_pose)
    self.r2.SetDOFValues(self.pos, self.inds, openravepy.KinBody.CheckLimitsAction.Nothing)

    # set transparency
    links = self.r2.GetLinks()
    for l in range(0, len(links)):
      cur_link = links[l]
      gs = cur_link.GetGeometries()
      for g in gs:
        g.SetTransparency(0.7)

  def removeStartConfigRobot(self):
      self.env.Remove(self.r2)
  
  def resetRobot(self):
    self.robot.SetDOFValues(self.pos, self.inds, openravepy.KinBody.CheckLimitsAction.Nothing)
    self.removeBalls()  

  # runs given trajectory, creates video
  def runTrajWithTrace(self, name, num):
    time.sleep(2)
    path = '/homes/njassal/catkin_ws/src/ada_cbirrt_test/data/videos/temp_images/'
    vidPath = '/homes/njassal/catkin_ws/src/ada_cbirrt_test/data/videos/'
    viewer = self.env.GetViewer()
    camTrans = viewer.GetCameraTransform()

    waypoints = self.traj.GetNumWaypoints()
    self.ballList = []
    color = [1, 1, 1]

    time.sleep(1)
    for i in range(waypoints):

      # position robot at waypoint i
      self.manip.SetDOFValues(self.traj.GetWaypoint(i))

      trans = self.manip.GetEndEffectorTransform()
      time.sleep(.05)
      ball = self.env.ReadKinBodyXMLFile('/homes/njassal/catkin_ws/src/ada_cbirrt_test/data/smallsphere.kinbody.xml')
      ball.SetName('ball' + str(i) + str(num))
      self.env.AddKinBody(ball)
      ball.SetTransform(trans)
      self.ballList.append(ball)
      
      # set ball color
      color[0] = color[0] + (1. / waypoints)
      color[1] = color[1] - (1. / waypoints)
      ball.GetLinks()[0].GetGeometries()[0].SetDiffuseColor(color)

      time.sleep(.1)

      # get and save image with number padding
      if i < 10:
        str_num = '00'+str(i)
      elif i < 100:
        str_num = '0'+str(i)
      imTemp = viewer.GetCameraImage(1280*2, 720*2, camTrans, [800*2, 800*2, 640*2, 360*2])
      scipy.misc.imsave(path+'frame_'+str_num+'.png', imTemp)
      time.sleep(.05)

    print 'generating video...'

    os.system("avconv -f image2 -i " + path + "frame_%03d.png " + vidPath + name + ".mp4")

    # delete temporary images for video (for next run)
    os.system("rm " + path + "*")
    print 'done'



    time.sleep(1)

  def imgAndVidTraj(self):
    print 'End effector trace of trajectory, with configurations present'
    print 'Real POV image/video'
    
    fileNameRealClutter = 'traj_real_clutter'
    fileNameClearClutter = 'traj_clear_clutter'
    fileNameRealFree = 'traj_real_free'
    fileNameClearFree = 'traj_clear_free'

    viewer = self.env.GetViewer()
    viewer.SetCamera(self.camTransReal)

  
    # real pov ---------------------------------------------
    print 'generating real pov w/ clutter video...'
    self.fuze.SetVisible(True)
    self.glass.SetVisible(True)
    self.runTrajWithTrace(fileNameRealClutter,0)
    self.resetRobot()

    print 'generating real pov w/ no clutter video...'
    self.fuze.SetVisible(False)
    self.glass.SetVisible(True)
    self.runTrajWithTrace(fileNameRealFree,1)
    self.resetRobot()

    # clear pov ---------------------------------------------
    viewer.SetCamera(self.camTransClear)

    print 'generating clear pov w/ clutter video...'
    self.fuze.SetVisible(True)
    self.glass.SetVisible(True)
    self.runTrajWithTrace(fileNameClearClutter,2)
    self.resetRobot()

    self.fuze.SetVisible(False)
    self.glass.SetVisible(True)
    self.runTrajWithTrace(fileNameClearFree,3)


    # using final EE pose with trace from previous traj run, generate images
    time.sleep(2)
    self.loadStartConfigRobot()
    time.sleep(1)
    self.fuze.SetVisible(False)
    self.glass.SetVisible(False)
    self.getImages('traj')
    time.sleep(1)

    self.removeStartConfigRobot()
    self.resetRobot()



if __name__ == "__main__":

    adaManipulationTester = ADAmanipulationTester()
    adaManipulationTester.initSimple()
    adaManipulationTester.planTrajectorySimple()

    #adaManipulationTester.startVideo()
    #adaManipulationTester.stopVideo()

    time.sleep(2)   # allows viewer to load properly

    adaManipulationTester.imgGoal()
    time.sleep(1)

    adaManipulationTester.imgConfigs()
    time.sleep(2)

    # cannot be run with imgGoal and imgConfigs...reset not functioning properly? causes only a few waypoints
    #adaManipulationTester.imgAndVidTraj()
    

    #embed()
