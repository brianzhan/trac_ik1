#!/usr/bin/env python

import numpy
#import roslib
#mport rospy
import openravepy
import adapy
import prpy
import numpy as np


from IPython import embed
import tf
import rospkg

import os
import time

#from ar_track_alvar.msg import AlvarMarkers
from sensor_msgs.msg import JointState

#rom TransformMatrix import *
#from str2num import *

import IPython

from prpy.tsr.tsrlibrary import TSRFactory
from prpy.tsr.tsr import *
from adapy.tsr import glass as glassUtils


@TSRFactory('ada', 'glass', 'grasp')
def grasp_object(robot, object, val= 0, manip=None):
    '''
    @param robot The robot performing the grasp
    @param glass The glass to grasp
    @param manip The manipulator to perform the grasp, if None
       the active manipulator on the robot is used
    '''
    if manip is None:
        manip_idx = robot.GetActiveManipulatorIndex()
    else:
        with manip.GetRobot():
            manip.SetActive()
            manip_idx = manip.GetRobot().GetActiveManipulatorIndex()

    T0_w = object.GetTransform()

    Tw_e = numpy.array([[ 0., 0., -1., -0.02], 
                          [-1., 0., 0., 0.], 
                          [0., 1., 0., 0.08], 
                          [0., 0., 0., 1.]])


    Bw = numpy.zeros((6,2))
    Bw[2,:] = [-0.02 + val, 0.02 + val]  # Allow a little vertical movement

    Bw[5,:] = [-numpy.pi, numpy.pi]  # Allow any orientation
    
    grasp_tsr = TSR(T0_w = T0_w, Tw_e = Tw_e, Bw = Bw, manip = manip_idx)
    grasp_chain = TSRChain(sample_start=False, sample_goal = True, constrain=False, TSR = grasp_tsr)

    return [grasp_chain]



class ADAmanipulationTester:
  def initSimple(self):
      openravepy.RaveInitialize(True, level=openravepy.DebugLevel.Debug)
      openravepy.misc.InitOpenRAVELogging();
      self.env, self.robot = adapy.initialize(attach_viewer=True, sim=False)
      self.manip = self.robot.arm
      inds, pos = self.robot.configurations.get_configuration('home')
      pos[1] = -1.57;
      pos[2] = 0;
      self.robot.SetDOFValues(pos, inds, openravepy.KinBody.CheckLimitsAction.Nothing)

      # find the ordata
      rospack = rospkg.RosPack()
      file_root = rospack.get_path('pr_ordata')
      #file_root = rospack.get_path('ada_description')
      obj_root = rospack.get_path('ada_cbirrt_test')
      coke_file_root = '/homes/snikolai/Documents/pr_ordata_old'#rospack.get_path('pr_ordata_old')

     
      # load the table
      table_name = 'table'
      #table_xml = os.path.join(file_root, 'ordata', 'objects', 'furniture', 'table.kinbody.xml')
      table_xml = os.path.join(file_root, 'data', 'furniture', 'table.kinbody.xml')

      table_pose = numpy.array([[ 1,   0,   0,  8.75423792e-01],
                        [ 0,  0,  -1,  6.32824451e-02],
                        [ 0,  1,   0,  0],
                        [  0,   0,   0,  1]])
      self.table = prpy.rave.add_object(self.env, table_name, table_xml, table_pose)
      self.table_aabb = self.table.ComputeAABB()
      

      #load a coke can
      coke_name = 'coke'
      coke_xml = os.path.join(coke_file_root, 'ordata', 'objects', 'household', 'coke_can.kinbody.xml')
      coke_pose = numpy.eye(4)
      self.coke = prpy.rave.add_object(self.env, coke_name, coke_xml, coke_pose)
      coke_aabb = self.coke.ComputeAABB()
      
      coke_pose[2,3] = 2*self.table_aabb.extents()[2] + 0.005# 0.005
      coke_pose[0,3] = self.table_aabb.pos()[0] - 0.5*self.table_aabb.extents()[0] + 0.4
      coke_pose[1,3] = self.table_aabb.pos()[1] - 0.15
      self.coke.SetTransform(coke_pose)

      #load a fuze bottle
      fuze_name = 'fuze_bottle'
      fuze_xml = os.path.join(obj_root, 'data', 'study1_objects', 'fuze_bottle.kinbody.xml')
      fuze_pose = numpy.eye(4)
      self.fuze = prpy.rave.add_object(self.env, fuze_name, fuze_xml, fuze_pose)
      fuze_aabb = self.fuze.ComputeAABB()
      
      fuze_pose[2,3] = 2*self.table_aabb.extents()[2] -0.05
      fuze_pose[0,3] = self.table_aabb.pos()[0] - 0.5*self.table_aabb.extents()[0] + 0.6
      fuze_pose[1,3] = self.table_aabb.pos()[1] - 0.2
      self.fuze.SetTransform(fuze_pose)
      

      # load a poptarts box
      dasani_name = 'dasani'
      dasani_xml = os.path.join(obj_root, 'data', 'study1_objects', 'dasani.kinbody.xml')
      dasani_pose = numpy.eye(4)
      self.dasani = prpy.rave.add_object(self.env, dasani_name, dasani_xml, dasani_pose)
      dasani_aabb = self.dasani.ComputeAABB()
      
      dasani_pose[2,3] = 2*self.table_aabb.extents()[2] -0.05# 0.005
      dasani_pose[0,3] = self.table_aabb.pos()[0] - 0.5*self.table_aabb.extents()[0] + .51
      dasani_pose[1,3] = self.table_aabb.pos()[1]  + 0.05
      self.dasani.SetTransform(dasani_pose)


      robot_pose = coke_pose
      robot_pose[0,3] = coke_pose[0,3] + 0.5
      robot_pose[1,3] = coke_pose[1,3] + 0.1
      robot_pose[2,3] = 2*self.table_aabb.extents()[2] # +0.04
      self.robot_pose = robot_pose
      self.robot.SetTransform(robot_pose)
      #embed()

      ViewSide1 = numpy.array([[ 0.9998857 , -0.00582933, -0.01394994,  0.89785039],
       [ 0.01070029, -0.37899823,  0.92533553, -1.42433608],
       [-0.01068109, -0.92537904, -0.37889254,  1.3081876 ],
       [ 0.        ,  0.        ,  0.        ,  1.        ]])

      ViewSide2 = numpy.array([[ 0.99886276,  0.01140204, -0.04629459,  0.92531258],
       [ 0.04448544, -0.57221648,  0.8188952 , -0.81919384],
       [-0.01715345, -0.82002335, -0.57207295,  1.3155508 ],
       [ 0.        ,  0.        ,  0.        ,  1.        ]])

      ViewRobotTop1 = numpy.array([[-0.01158292, -0.94072085,  0.33898396,  0.42924026],
       [-0.99780782,  0.03296392,  0.05738418, -0.0122487 ],
       [-0.06515673, -0.33757617, -0.93904043,  1.93505919],
       [ 0.        ,  0.        ,  0.        ,  1.        ]])



      viewer = self.env.GetViewer()
      viewer.SetCamera(ViewRobotTop1)

      self.trajectoryPlanned = False

  def planAndExecuteTrajectorySimple(self):     

      manip = self.robot.arm
      #self.robot.SetActiveManipulator(manip)
      activedofs = [i for i in range(6)]
      self.robot.SetActiveDOFs(activedofs)

      filePath = os.path.dirname(os.path.abspath(__file__))
     
      #grasp_chains = glassUtils.glass_grasp(self.robot, self.glass, manip)
      #tsrchain = grasp_chains[0]
      #tsr = tsrchain.TSRs[0]
      with prpy.rave.Disabled(self.table):
          values = [2.27, -1.839, -0.521, 0.369, -2.59, 2.504]
          self.robot.PlanToConfiguration(values)
          
          time.sleep(3)

          self.robot.planner = prpy.planning.Sequence(self.robot.cbirrt_planner) 

          grasp_coke_chains = grasp_object(self.robot, self.coke, -0.01)

          grasp_fuze_chains = grasp_object(self.robot, self.fuze)

          grasp_dasani_chains = grasp_object(self.robot, self.dasani)
          #grasp_chains = glassUtils.glass_grasp(self.robot, self.glass)
          #move_chains = glassUtils.move_glass(self.robot, self.glass)

          #self.robot.arm.hand.CloseHand()
          # #move_chain = move_chains[0]
          #traj = self.robot.PlanToTSR(grasp_dasani_chains)
          new_traj = openravepy.RaveCreateTrajectory(self.robot.GetEnv(), '')
          new_traj.Init(self.robot.GetActiveConfigurationSpecification())

          traj = prpy.rave.load_trajectory(self.env,filePath + "/traj_coke.xml")

          numOfWaypoints = traj.GetNumWaypoints()
          for i in range(numOfWaypoints):
              waypoint = traj.GetWaypoint(i)
              waypoint = waypoint[0:6]
               #waypoint = numpy.append(waypoint, [values[6],values[7]])
              new_traj.Insert(i,waypoint)
          #new_traj.Remove(0,numOfWaypoints)
          #prpy.rave.save_trajectory(new_traj, "traj.xml")
          with prpy.rave.Disabled(self.table):
              self.robot.ExecuteTrajectory(new_traj) 
              #self.robot.arm.hand.CloseHand()
          #embed()
              time.sleep(10)

              self.robot.PlanToConfiguration(values)   
       
              time.sleep(5)

    
          new_traj = openravepy.RaveCreateTrajectory(self.robot.GetEnv(), '')
          new_traj.Init(self.robot.GetActiveConfigurationSpecification())

          traj = prpy.rave.load_trajectory(self.env,filePath + "/traj_dasani.xml")
          numOfWaypoints = traj.GetNumWaypoints()
          for i in range(numOfWaypoints):
              waypoint = traj.GetWaypoint(i)
              waypoint = waypoint[0:6]
               #waypoint = numpy.append(waypoint, [values[6],values[7]])
              new_traj.Insert(i,waypoint)
          #new_traj.Remove(0,numOfWaypoints)
          #prpy.rave.save_trajectory(new_traj, "traj.xml")
          with prpy.rave.Disabled(self.table):
              self.robot.ExecuteTrajectory(new_traj) 
              #self.robot.arm.hand.CloseHand()
          #embed()
              time.sleep(10)

              self.robot.PlanToConfiguration(values)

              time.sleep(10)


          new_traj = openravepy.RaveCreateTrajectory(self.robot.GetEnv(), '')
          new_traj.Init(self.robot.GetActiveConfigurationSpecification())

          traj = prpy.rave.load_trajectory(self.env,filePath + "/traj_fuze.xml")
          numOfWaypoints = traj.GetNumWaypoints()
          for i in range(numOfWaypoints):
              waypoint = traj.GetWaypoint(i)
              waypoint = waypoint[0:6]
               #waypoint = numpy.append(waypoint, [values[6],values[7]])
              new_traj.Insert(i,waypoint)
          #new_traj.Remove(0,numOfWaypoints)
          #prpy.rave.save_trajectory(new_traj, "traj.xml")
          with prpy.rave.Disabled(self.table):
              self.robot.ExecuteTrajectory(new_traj) 
              #self.robot.arm.hand.CloseHand()
          #embed()
              time.sleep(10)

              self.robot.PlanToConfiguration(values)

      # reached = False
      # distThres = 0.1
      # while(reached == False):
      #    glassPose = self.glass.GetTransform()
      #    glassPos = numpy.array([glassPose[0,3],glassPose[1,3],glassPose[2,3]])
      #    robotPose = manip.GetEndEffectorTransform()
      #    robotPos = numpy.array([robotPose[0,3],robotPose[1,3],robotPose[2,3]])
      #    if(numpy.linalg.norm(robotPos-glassPos) < distThres):
      #         print "*******target reached!************"
      #         reached = True
      #         time.sleep(1.0)
      #         self.robot.arm.hand.CloseHand()
      #         self.robot.Grab(self.glass)

      # reached = False
      # activedofs = [i for i in range(8)]
      # self.robot.SetActiveDOFs(activedofs)
      # while(reached == False):
      #   values = self.robot.GetActiveDOFValues()
      #   target_finger_pos = numpy.array([0.8,0.8])
      #   current_pos = numpy.array([values[6], values[7]])
      #   #embed()
      #   if(numpy.linalg.norm(current_pos - target_finger_pos)<0.1):
      #       reached = True
      #       #print "reached point!"
      #       with prpy.rave.Disabled(self.glass):
      #          manip.PlanToTSR(move_chains)




      #embed()
     
   
      
  def joint_states_callback(self, msg):
      #self.lock.acquire()
      name = msg.name
      position = msg.position
      velocity = msg.velocity
      effort = msg.effort
      #self.lock.release()
      
      print "name: ", name, " joint positions: ", position
      
      jointIndices = []
      jointValues = []
      
      for n in name:
           jointIndices.append(self.robot.GetJointIndex(n))
           jointValues.append(position[name.index(n)])
      
      self.robot.SetDOFValues(jointValues, jointIndices)
  
  def startVideo(self):
      self.recorder = openravepy.RaveCreateModule(self.env,'viewerrecorder')
      self.env.AddModule(self.recorder,'')
      codecs = self.recorder.SendCommand('GetCodecs') # linux only
      filename = 'testGrasp.mpg'
      codec = 13 # mpeg4
      self.recorder.SendCommand('Start 640 480 30 codec %d timing realtime filename %s\nviewer %s'%(codec,filename,self.env.GetViewer().GetName()))
  def stopVideo(self):
      self.recorder.SendCommand('Stop') # stop the video
      self.env.Remove(self.recorder) # remove the recorder


    
if __name__ == "__main__":
    embed()
    adaManipulationTester = ADAmanipulationTester()
    adaManipulationTester.initSimple()
    adaManipulationTester.startVideo()
    adaManipulationTester.planAndExecuteTrajectorySimple()
    adaManipulationTester.stopVideo()
    #embed()
