#!/usr/bin/env python

import numpy
#import roslib
#mport rospy
import openravepy
import adapy
import prpy
import numpy as np


from IPython import embed
import tf
import rospkg

import os
import time

#from ar_track_alvar.msg import AlvarMarkers
from sensor_msgs.msg import JointState

#rom TransformMatrix import *
#from str2num import *

import IPython

from prpy.tsr.tsrlibrary import TSRFactory
from prpy.tsr.tsr import *
from adapy.tsr import bowl as bowlUtils


class ADAmanipulationTester:
  def initSimple(self):
      openravepy.RaveInitialize(True, level=openravepy.DebugLevel.Debug)
      openravepy.misc.InitOpenRAVELogging();
      self.env, self.robot = adapy.initialize(attach_viewer=True, sim=False)
      self.manip = self.robot.arm
      inds, pos = self.robot.configurations.get_configuration('home')
      pos[1] = -1.57;
      pos[2] = 0;
      self.robot.SetDOFValues(pos, inds, openravepy.KinBody.CheckLimitsAction.Nothing)

      # find the ordata
      rospack = rospkg.RosPack()
      file_root = rospack.get_path('pr_ordata')
      #file_root = rospack.get_path('ada_description')

     
      # load the table
      table_name = 'table'
      #table_xml = os.path.join(file_root, 'ordata', 'objects', 'furniture', 'table.kinbody.xml')
      table_xml = os.path.join(file_root, 'data', 'furniture', 'table.kinbody.xml')

      table_pose = numpy.array([[ 1,   0,   0,  8.75423792e-01],
                        [ 0,  0,  -1,  6.32824451e-02],
                        [ 0,  1,   0,  0],
                        [  0,   0,   0,  1]])
      self.table = prpy.rave.add_object(self.env, table_name, table_xml, table_pose)
      self.table_aabb = self.table.ComputeAABB()
      

      # # load a fuze bottle
      bowl_name = 'bowl'
      bowl_xml = os.path.join(file_root, 'data', 'objects', 'bowl.kinbody.xml')
      bowl_pose = numpy.eye(4)
      self.bowl = prpy.rave.add_object(self.env, bowl_name, bowl_xml, bowl_pose)
      bowl_aabb = self.bowl.ComputeAABB()
      
      bowl_pose[2,3] = 2*self.table_aabb.extents()[2] + 0.005
      bowl_pose[0,3] = self.table_aabb.pos()[0] - 0.5*self.table_aabb.extents()[0] + 0.3
      bowl_pose[1,3] = self.table_aabb.pos()[1]
      self.bowl.SetTransform(bowl_pose)
      
      bowl_pose[0,3] = bowl_pose[0,3] + 0.1
      bowl_pose[1,3] = bowl_pose[1,3] + 0.275
      bowl_pose[2,3] = 2*self.table_aabb.extents()[2] + 0.04
      bowl_pose[2,3] = bowl_pose[2,3] + 0.02
      bowl_pose[0,3] = bowl_pose[0,3] - 0.4
      self.robot.SetTransform(bowl_pose)
      #embed()

      ViewSide1 = numpy.array([[ 0.9998857 , -0.00582933, -0.01394994,  0.89785039],
       [ 0.01070029, -0.37899823,  0.92533553, -1.42433608],
       [-0.01068109, -0.92537904, -0.37889254,  1.3081876 ],
       [ 0.        ,  0.        ,  0.        ,  1.        ]])

      ViewSide2 = numpy.array([[ 0.99886276,  0.01140204, -0.04629459,  0.92531258],
       [ 0.04448544, -0.57221648,  0.8188952 , -0.81919384],
       [-0.01715345, -0.82002335, -0.57207295,  1.3155508 ],
       [ 0.        ,  0.        ,  0.        ,  1.        ]])

      ViewRobotTop1 = numpy.array([[-0.01158292, -0.94072085,  0.33898396,  0.42924026],
       [-0.99780782,  0.03296392,  0.05738418, -0.0122487 ],
       [-0.06515673, -0.33757617, -0.93904043,  1.93505919],
       [ 0.        ,  0.        ,  0.        ,  1.        ]])



      viewer = self.env.GetViewer()
      viewer.SetCamera(ViewRobotTop1)

      self.trajectoryPlanned = False

  def planAndExecuteTrajectorySimple(self):     

      manip = self.robot.arm
      #self.robot.SetActiveManipulator(manip)
      activedofs = [i for i in range(6)]
      self.robot.SetActiveDOFs(activedofs)


      grasp_chains = bowlUtils.bowl_grasp(self.robot, self.bowl, manip)
      #tsrchain = grasp_chains[0]
      #tsr = tsrchain.TSRs[0]

      self.robot.planner = prpy.planning.Sequence(self.robot.cbirrt_planner) 

      #grasp_chains = bowlUtils.bowl_grasp(self.robot, self.bowl)
      move_chains = bowlUtils.move_bowl(self.robot, self.bowl)

    
      #self.robot.arm.hand.CloseHand()
      # #move_chain = move_chains[0]
      self.robot.PlanToTSR(grasp_chains)

      # self.robot.arm.hand.CloseHandTight()
      
      # embed()
     
      # self.robot.arm.hand.OpenHand()

      reached = False
      distThres = 0.2
      while(reached == False):
         bowlPose = self.bowl.GetTransform()
         bowlPos = numpy.array([bowlPose[0,3],bowlPose[1,3],bowlPose[2,3]])
         robotPose = manip.GetEndEffectorTransform()
         robotPos = numpy.array([robotPose[0,3],robotPose[1,3],robotPose[2,3]])
         if(numpy.linalg.norm(robotPos-bowlPos) < distThres):
              print "*******target reached!************"
              reached = True
              time.sleep(3.0)
              self.robot.arm.hand.CloseHandTight()
              self.robot.Grab(self.bowl)
              #time.sleep(4.0)

      reached = False
      activedofs = [i for i in range(8)]
      self.robot.SetActiveDOFs(activedofs)
      while(reached == False):
        values = self.robot.GetActiveDOFValues()
        target_finger_pos = numpy.array([1.09,1.09])
        current_pos = numpy.array([values[6], values[7]])
        #embed()
        if(numpy.linalg.norm(current_pos - target_finger_pos)<0.1):
            time.sleep(3)
            reached = True
            with prpy.rave.Disabled(self.bowl), prpy.rave.Disabled(self.robot):
              currentConfiguration = manip.GetDOFValues()
              liftConfiguration = currentConfiguration
              liftConfiguration[4] = liftConfiguration[4] + 0.7
              manip.PlanToConfiguration(liftConfiguration)
              time.sleep(1)
              liftConfiguration[1] = liftConfiguration[1] - 0.3
              manip.PlanToConfiguration(liftConfiguration)


      time.sleep(3.0)

      with prpy.rave.Disabled(self.bowl), prpy.rave.Disabled(self.robot):
           self.robot.arm.hand.OpenHand()

      time.sleep(3.0)

      startConfiguration4 = np.asarray([ 1.96253294, -0.9923351 ,  0.28682431,  1.72192592, -1.07456739,
        1.31137727])
  
      with prpy.rave.Disabled(self.bowl):
         manip.PlanToConfiguration(startConfiguration4)



      embed()
     
   
      
  def joint_states_callback(self, msg):
      #self.lock.acquire()
      name = msg.name
      position = msg.position
      velocity = msg.velocity
      effort = msg.effort
      #self.lock.release()
      
      print "name: ", name, " joint positions: ", position
      
      jointIndices = []
      jointValues = []
      
      for n in name:
           jointIndices.append(self.robot.GetJointIndex(n))
           jointValues.append(position[name.index(n)])
      
      self.robot.SetDOFValues(jointValues, jointIndices)
  
  def startVideo(self):
      self.recorder = openravepy.RaveCreateModule(self.env,'viewerrecorder')
      self.env.AddModule(self.recorder,'')
      codecs = self.recorder.SendCommand('GetCodecs') # linux only
      filename = 'testGrasp.mpg'
      codec = 13 # mpeg4
      self.recorder.SendCommand('Start 640 480 30 codec %d timing realtime filename %s\nviewer %s'%(codec,filename,self.env.GetViewer().GetName()))
  def stopVideo(self):
      self.recorder.SendCommand('Stop') # stop the video
      self.env.Remove(self.recorder) # remove the recorder


    
if __name__ == "__main__":
    adaManipulationTester = ADAmanipulationTester()
    adaManipulationTester.initSimple()
    adaManipulationTester.startVideo()
    adaManipulationTester.planAndExecuteTrajectorySimple()
    adaManipulationTester.stopVideo()
    #embed()
