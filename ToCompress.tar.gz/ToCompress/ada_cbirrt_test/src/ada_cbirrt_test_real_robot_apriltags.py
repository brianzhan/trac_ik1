#!/usr/bin/env python

import numpy
#import roslib
#mport rospy
import openravepy
import adapy
import prpy
import numpy as np
import math
from IPython import embed
import tf
import rospkg

import os
import time

import rospy
#from ar_track_alvar.msg import AlvarMarkers
from sensor_msgs.msg import JointState
from visualization_msgs.msg import Marker, MarkerArray

from tf.transformations import quaternion_matrix,quaternion_from_matrix

#rom TransformMatrix import *
#from str2num import *

import IPython

from prpy.tsr.tsrlibrary import TSRFactory
from prpy.tsr.tsr import *
from adapy.tsr import bowl as bowlUtils



class ADAmanipulationTester:
  def object_pose_callback(self, msg):
    if(len(msg.markers)>0):
        marker = msg.markers[0]
        position_data = marker.pose.position
        orientation_data = marker.pose.orientation

        object_pose = numpy.matrix(quaternion_matrix([orientation_data.x,
                                                     orientation_data.y,
                                                     orientation_data.z,
                                                     orientation_data.w]))
        #object_pose[0,3] = position_data.x-0.02
        #object_pose[1,3] = position_data.y +0.05
        #object_pose[2,3] = position_data.z + 0.15
        object_pose[0,3] = position_data.x
        object_pose[1,3] = position_data.y
        object_pose[2,3] = position_data.z
        world_camera = self.robot.GetLinks()[7].GetTransform()

        object_world_pose = np.dot(world_camera,object_pose)
        self.bowl.SetTransform(np.asarray(object_world_pose))


        #one way to do it is through the tf
        # robot_base = self.robot.GetLinks()[0].GetTransform()
        # (trans,rot) = self.tfListener.lookupTransform('/base_link', '/Hand_Link', rospy.Time(0))
        # relative_hand = numpy.matrix(quaternion_matrix(rot))
        # relative_hand[0,3] = trans[0]
        # relative_hand[1,3] = trans[1]
        # relative_hand[2,3 ]= trans[2]

        # robot_base = self.robot.GetLinks()[0].GetTransform()
        # (trans,rot) = self.tfListener.lookupTransform('/Hand_Link', '/base_rgbd_camera_link', rospy.Time(0))
        # relative_camera = numpy.matrix(quaternion_matrix(rot))
        # relative_camera[0,3] = trans[0]
        # relative_camera[1,3] = trans[1]
        # relative_camera[2,3 ]= trans[2]
        #(yaw, pitch, roll) = tf.transformations.euler_from_quaternion(rot)
        #relative_camera = tf.transformations.compose_matrix(angles = (yaw + math.pi/2, pitch, roll - math.pi/2), translate=trans)

        #world_camera = np.dot(robot_base, relative_camera)
        #world_hand = np.dot(robot_base,relative_hand)
        #world_camera = np.dot(world_hand, relative_camera)
        h  = openravepy.misc.DrawAxes(self.env,object_world_pose)

        print "object transform:"
        print self.bowl.GetTransform()
        print "estimated transform:"
        print object_world_pose
        #embed()


  def initSimple(self):

      rospy.init_node('ada_cbirrt_test', anonymous = True)

      openravepy.RaveInitialize(True, level=openravepy.DebugLevel.Debug)
      openravepy.misc.InitOpenRAVELogging();
      self.env, self.robot = adapy.initialize(attach_viewer=True, sim=False)
      self.manip = self.robot.arm
      inds, pos = self.robot.configurations.get_configuration('home')
      pos[1] = -1.57;
      pos[2] = 0;
      self.robot.SetDOFValues(pos, inds, openravepy.KinBody.CheckLimitsAction.Nothing)

      # find the ordata
      rospack = rospkg.RosPack()
      file_root = rospack.get_path('pr_ordata')
      #file_root = rospack.get_path('ada_description')

     
      # load the table
      table_name = 'table'
      #table_xml = os.path.join(file_root, 'ordata', 'objects', 'furniture', 'table.kinbody.xml')
      table_xml = os.path.join(file_root, 'data', 'furniture', 'table.kinbody.xml')

      table_pose = numpy.array([[ 1,   0,   0,  8.75423792e-01],
                        [ 0,  0,  -1,  6.32824451e-02],
                        [ 0,  1,   0,  0],
                        [  0,   0,   0,  1]])
      self.table = prpy.rave.add_object(self.env, table_name, table_xml, table_pose)
      self.table_aabb = self.table.ComputeAABB()
      

      # # load a fuze bottle
      bowl_name = 'bowl'
      bowl_xml = os.path.join(file_root, 'data', 'objects', 'bowl.kinbody.xml')
      bowl_pose = numpy.eye(4)
      self.bowl = prpy.rave.add_object(self.env, bowl_name, bowl_xml, bowl_pose)
      bowl_aabb = self.bowl.ComputeAABB()
      
      bowl_pose[2,3] = 2*self.table_aabb.extents()[2] + 0.005
      bowl_pose[0,3] = self.table_aabb.pos()[0] - 0.5*self.table_aabb.extents()[0] + 0.3
      bowl_pose[1,3] = self.table_aabb.pos()[1]
      self.bowl.SetTransform(bowl_pose)
      
      bowl_pose[0,3] = bowl_pose[0,3] + 0.1
      bowl_pose[1,3] = bowl_pose[1,3] + 0.275
      bowl_pose[2,3] = 2*self.table_aabb.extents()[2] + 0.04
      bowl_pose[2,3] = bowl_pose[2,3] + 0.02
      bowl_pose[0,3] = bowl_pose[0,3] - 0.4
      self.robot.SetTransform(bowl_pose)
      #embed()

      ViewSide1 = numpy.array([[ 0.9998857 , -0.00582933, -0.01394994,  0.89785039],
       [ 0.01070029, -0.37899823,  0.92533553, -1.42433608],
       [-0.01068109, -0.92537904, -0.37889254,  1.3081876 ],
       [ 0.        ,  0.        ,  0.        ,  1.        ]])

      ViewSide2 = numpy.array([[ 0.99886276,  0.01140204, -0.04629459,  0.92531258],
       [ 0.04448544, -0.57221648,  0.8188952 , -0.81919384],
       [-0.01715345, -0.82002335, -0.57207295,  1.3155508 ],
       [ 0.        ,  0.        ,  0.        ,  1.        ]])

      ViewRobotTop1 = numpy.array([[-0.01158292, -0.94072085,  0.33898396,  0.42924026],
       [-0.99780782,  0.03296392,  0.05738418, -0.0122487 ],
       [-0.06515673, -0.33757617, -0.93904043,  1.93505919],
       [ 0.        ,  0.        ,  0.        ,  1.        ]])


      # self.ball = self.env.ReadKinBodyXMLFile('/homes/snikolai/catkin_ws/src/ada_cbirrt_test/data/study1_objects/mediumsphere.kinbody.xml')
      # self.ball.SetName('Ball1')
      # self.env.AddKinBody(self.ball)


      viewer = self.env.GetViewer()
      viewer.SetCamera(ViewRobotTop1)

      self.trajectoryPlanned = False

      #rospy.Subscriber('/apriltags/marker_array', MarkerArray, self.object_pose_callback)
      # Subscribe to joint states
      rospy.Subscriber('object_poses_array', MarkerArray, self.object_pose_callback)

      # tf listener for querying transforms
      self.tfListener = tf.TransformListener()

   


  def planAndExecuteTrajectorySimple(self):     

      manip = self.robot.arm
      #self.robot.SetActiveManipulator(manip)
      activedofs = [i for i in range(6)]
      self.robot.SetActiveDOFs(activedofs)
 
 
      self.robot.planner = prpy.planning.Sequence(self.robot.cbirrt_planner)      
      startConfiguration1 = np.asarray([ 1.26857175, -0.93843538, -0.22907446,  1.68503582, -2.3883244 ,
        1.79451624])

      startConfiguration2 = np.asarray([1.25990955, -1.4254591 , -0.63813601,  2.00990525, -2.58943394,
        1.79451624])


      startConfiguration3 = np.asarray([ 2.29844437,  0.06159998, -0.25698692,  1.30661661, -1.47202647,
        2.82981319])

      startConfiguration4 = np.asarray([ 1.96253294, -0.9923351 ,  0.28682431,  1.72192592, -1.07456739,
        1.31137727])

      manip.PlanToConfiguration(startConfiguration4)

      rospy.spin()

      # grasp_chains = glassUtils.glass_grasp(self.robot, self.glass, manip)
      # #tsrchain = grasp_chains[0]
      # #tsr = tsrchain.TSRs[0]

      # self.robot.planner = prpy.planning.Sequence(self.robot.cbirrt_planner) 

      # #grasp_chains = glassUtils.glass_grasp(self.robot, self.glass)
      # move_chains = glassUtils.move_glass(self.robot, self.glass)

      # #self.robot.arm.hand.CloseHand()
      # # #move_chain = move_chains[0]
      # self.robot.PlanToTSR(grasp_chains)

      # reached = False
      # distThres = 0.1
      # while(reached == False):
      #    glassPose = self.glass.GetTransform()
      #    glassPos = numpy.array([glassPose[0,3],glassPose[1,3],glassPose[2,3]])
      #    robotPose = manip.GetEndEffectorTransform()
      #    robotPos = numpy.array([robotPose[0,3],robotPose[1,3],robotPose[2,3]])
      #    if(numpy.linalg.norm(robotPos-glassPos) < distThres):
      #         print "*******target reached!************"
      #         reached = True
      #         time.sleep(1.0)
      #         self.robot.arm.hand.CloseHand()
      #         self.robot.Grab(self.glass)

      # reached = False
      # activedofs = [i for i in range(8)]
      # self.robot.SetActiveDOFs(activedofs)
      # while(reached == False):
      #   values = self.robot.GetActiveDOFValues()
      #   target_finger_pos = numpy.array([0.8,0.8])
      #   current_pos = numpy.array([values[6], values[7]])
      #   #embed()
      #   if(numpy.linalg.norm(current_pos - target_finger_pos)<0.1):
      #       reached = True
      #       #print "reached point!"
      #       with prpy.rave.Disabled(self.glass):
      #          manip.PlanToTSR(move_chains)




      embed()
     
   
      
  def joint_states_callback(self, msg):
      #self.lock.acquire()
      name = msg.name
      position = msg.position
      velocity = msg.velocity
      effort = msg.effort
      #self.lock.release()
      
      print "name: ", name, " joint positions: ", position
      
      jointIndices = []
      jointValues = []
      
      for n in name:
           jointIndices.append(self.robot.GetJointIndex(n))
           jointValues.append(position[name.index(n)])
      
      self.robot.SetDOFValues(jointValues, jointIndices)
  
  def startVideo(self):
      self.recorder = openravepy.RaveCreateModule(self.env,'viewerrecorder')
      self.env.AddModule(self.recorder,'')
      codecs = self.recorder.SendCommand('GetCodecs') # linux only
      filename = 'testGrasp.mpg'
      codec = 13 # mpeg4
      self.recorder.SendCommand('Start 640 480 30 codec %d timing realtime filename %s\nviewer %s'%(codec,filename,self.env.GetViewer().GetName()))
  def stopVideo(self):
      self.recorder.SendCommand('Stop') # stop the video
      self.env.Remove(self.recorder) # remove the recorder


    
if __name__ == "__main__":
    adaManipulationTester = ADAmanipulationTester()
    adaManipulationTester.initSimple() 
    #embed()
    #adaManipulationTester.startVideo()
    adaManipulationTester.planAndExecuteTrajectorySimple()
    #adaManipulationTester.stopVideo()
    #embed()
