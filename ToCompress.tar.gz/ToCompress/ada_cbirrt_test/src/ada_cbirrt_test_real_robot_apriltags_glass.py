#!/usr/bin/env python
import Tkinter as tk

import numpy
#import roslib
#mport rospy
import openravepy
import adapy
import prpy
import numpy as np
import math
from IPython import embed
import tf
import rospkg
import sys

import os
import time

import rospy
#from ar_track_alvar.msg import AlvarMarkers
from visualization_msgs.msg import Marker, MarkerArray
from tf.transformations import quaternion_matrix,quaternion_from_matrix

#rom TransformMatrix import *
#from str2num import *

import IPython

from prpy.tsr.tsrlibrary import TSRFactory
from prpy.tsr.tsr import *
from adapy.tsr import glass as glassUtils

 
#some hard-coded configurations   
liftConfiguration = np.asarray([  2.20700740e+00,  -9.48060314e-01,  -5.36111239e-01,      6.41408500e-01,  -1.46131657e+00,   2.29788458e+00])
#placeConfiguration = np.asarray([ 2.77103083, -0.17324981,  0.71128585,  1.18880715, -0.26060922, 1.31018697])
placeConfiguration = np.asarray([2.77103083, -0.55439877,  0.26661185,  1.18880741, -0.26060922,  1.31018697])

#dropConfiguration = np.asarray([  2.77584370e+00,   3.17624571e-02,   8.38335681e-01, 1.18880715e+00,  -2.60609221e-01,   1.31018697e+00])
dropConfiguration = np.asarray([  2.77584370e+00,   3.17624571e-02,   0.95, 1.18880715e+00,  -2.60609221e-01,   1.31018697e+00])
ReleasedConfiguration = numpy.asarray([  3.3e+00,   3.17624571e-02,   8.38335681e-01,  1.18880715e+00,  -2.60609221e-01,   1.31018697e+00])
slowVelocityLimits = np.asarray([ 0.3,0.3,0.3,0.3,0.3,0.3,0.78,0.78])
startConfiguration = np.asarray([ 2.17332001, -0.06063751,  1.04142249,  1.2602073 , -0.67115841, 1.31018697])
  


class ADAmanipulationTester:

  def object_pose_callback(self, msg):
    if(len(msg.markers)>0):
       
                marker = msg.markers[0]
                position_data = marker.pose.position
                orientation_data = marker.pose.orientation

                object_pose = numpy.matrix(quaternion_matrix([orientation_data.x,
                                                             orientation_data.y,
                                                             orientation_data.z,
                                                             orientation_data.w]))
                object_pose[0,3] = position_data.x 
                object_pose[1,3] = position_data.y
                object_pose[2,3] = position_data.z

                world_camera = self.robot.GetLinks()[7].GetTransform()

                object_world_pose = np.dot(world_camera,object_pose)

  
                if(self.MODE == self.UPDATING_POSE):
                        print 'detected ', marker.ns
                        self.numOfUpdateCalls = self.numOfUpdateCalls + 1
                        object_world_pose[0,3] = object_world_pose[0,3] + 0.03 #make the glass a little closer so that it succeeds
                        self.glass.SetTransform(np.asarray(object_world_pose))
                        h  = openravepy.misc.DrawAxes(self.env,object_world_pose)

                        if(self.numOfUpdateCalls > self.NUM_UPDATE_CALLS):
                           self.MODE = self.GRASPING 
                           self.NUM_UPDATE_CALLS = 30
                elif self.MODE == self.GRASPING and self.Initialized == True:
                        self.MODE = self.RUNNING
                        self.planAndExecuteTrajectorySimple()
                        time.sleep(6)
                        print "*********************Done grasping!***************************"
                        self.numOfGrasps = self.numOfGrasps + 1
                        self.numOfUpdateCalls = 0
                        self.MODE = self.UPDATING_POSE
                        glass_start_pose= numpy.eye(4)
                        self.glass.SetTransform(glass_start_pose)

            #time.sleep(10.0)


  def initSimple(self):

      self.NUM_UPDATE_CALLS = 50
      self.Initialized = False

      rospy.init_node('ada_cbirrt_test', anonymous = True)
      env_path = '/environments/tablewithglass.env.xml'

      openravepy.RaveInitialize(True, level=openravepy.DebugLevel.Debug)
      openravepy.misc.InitOpenRAVELogging();
      self.env, self.robot = adapy.initialize(attach_viewer='rviz', sim=False, env_path = env_path)
      #embed()

      self.manip = self.robot.arm
      inds, pos = self.robot.configurations.get_configuration('home')
      pos[1] = -1.57;
      pos[2] = 0;
      #self.robot.SetDOFValues(pos, inds, openravepy.KinBody.CheckLimitsAction.Nothing)
      self.robot.SetDOFValues(self.robot.GetDOFValues())


      # find the ordata
      rospack = rospkg.RosPack()
      file_root = rospack.get_path('pr_ordata')
      #file_root = rospack.get_path('ada_description')

      # self.glass.SetTransform(glass_pose)
      self.glass = self.env.GetKinBody('glass')
      glass_start_pose= numpy.eye(4)
      self.glass.SetTransform(glass_start_pose)

      robot_pose = numpy.array([[1, 0, 0, 0.409],[0, 1, 0, 0.338],[0, 0, 1, 0.795],[0, 0, 0, 1]])
      self.robot.SetTransform(robot_pose)

      ViewSide1Obj = self.env.GetKinBody('ViewSide1')
      ViewSide1Trans = ViewSide1Obj.GetTransform()

      ViewSide2Obj = self.env.GetKinBody('ViewSide2')
      ViewSide2Trans = ViewSide2Obj.GetTransform()

      ViewTopObj = self.env.GetKinBody('ViewTop')
      ViewTopTrans = ViewTopObj.GetTransform()

      prpy.rave.disable_padding(self.glass, False)
      self.glass.GetLink('padding_glass').SetVisible(False)

      self.numOfGrasps = 0
      self.numOfUpdateCalls = 100


      viewer = self.env.GetViewer()
      #viewer.SetCamera(ViewTopTrans)

      self.trajectoryPlanned = True


      # tf listener for querying transforms
      self.tfListener = tf.TransformListener()

      self.UPDATING_POSE = 1
      self.GRASPING = 2
      self.RUNNING = 3
      self.MODE = self.UPDATING_POSE
 
      self.manip = self.robot.arm
      #self.robot.SetActiveManipulator(manip)
      activedofs = [i for i in range(6)]
      self.robot.SetActiveDOFs(activedofs)
 
 
      self.robot.planner = prpy.planning.Sequence(self.robot.cbirrt_planner)      

      embed()
      quit()

      self.robot.arm.hand.OpenHand()
      time.sleep(6)
      self.manip.PlanToConfiguration(startConfiguration)
      time.sleep(6)
      self.Initialized = True
      self.sub = rospy.Subscriber('object_poses_array', MarkerArray, self.object_pose_callback)

      rospy.spin()    

  def getVelocitiesTrajectory(self, cartesian_vels):
      jac = self.robot.arm.CalculateJacobian()
      jointVels = numpy.dot(numpy.transpose(jac),numpy.array(numpy.transpose(cartesian_vels)))
      traj = openravepy.RaveCreateTrajectory(self.env, '')
      self.robot.SetActiveDOFs([0,1,2,3,4,5,6,7]) #have to do that, otherwise get an error from roscontroller
      velocitySpecification = openravepy.ConfigurationSpecification.ConvertToVelocitySpecification(self.robot.GetActiveConfigurationSpecification())
      traj.Init(velocitySpecification)
      velValues = np.zeros([8])
      velValues[0:6] = jointVels
      traj.Insert(0,velValues)
      self.robot.SetActiveDOFs([0,1,2,3,4,5])
      return traj

  def planAndExecuteTrajectorySimple(self):     

      #embed()
      try:
          #res =  openravepy.planningutils.SmoothTrajectory(traj,1, 1, 'ParabolicSmoother', '')
          #self.controller.SetPath(traj)
          #exit()

          prpy.rave.disable_padding(self.glass, False)

        
          grasp_chains = glassUtils.glass_grasp(self.robot, self.glass, self.manip)

          self.robot.planner = prpy.planning.Sequence(self.robot.cbirrt_planner) 


          self.robot.PlanToTSR(self.robot.tsrlibrary(self.glass, 'grasp'))

          #self.robot.PlanToTSR(grasp_chains)
          embed()
          exit()
          reached = False
          distThres = 0.4
          while(reached == False):
             glassPose = self.glass.GetTransform()
             glassPos = numpy.array([glassPose[0,3],glassPose[1,3],glassPose[2,3]])
             robotPose = self.manip.GetEndEffectorTransform()
             robotPos = numpy.array([robotPose[0,3],robotPose[1,3],robotPose[2,3]])
             if(numpy.linalg.norm(robotPos-glassPos) < distThres):
                  print "*******target reached!************"
                  reached = True
                  time.sleep(3.0)
                  self.robot.arm.hand.CloseHandTight()
                  self.robot.Grab(self.glass)

                  #self.robot.Grab(self.glass)
                  #time.sleep(4.0)

          reached = False
          activedofs = [i for i in range(8)]
          self.robot.SetActiveDOFs(activedofs)
          while(reached == False):
            values = self.robot.GetActiveDOFValues()
            target_finger_pos = numpy.array([0.8,0.8])
            current_pos = numpy.array([values[6], values[7]])
            #embed()
            if(numpy.linalg.norm(current_pos - target_finger_pos)<0.1):
                time.sleep(1.5)
                reached = True
                #with prpy.rave.Disabled(self.glass), prpy.rave.Disabled(self.robot):
                #with prpy.rave.Disabled(self.glass):
                currentConfiguration = self.manip.GetDOFValues()

                time.sleep(0.5)
                jointVelsUp = self.getVelocitiesTrajectory([0,0,0.5])
                self.manip.controller.SetPath(jointVelsUp)
                time.sleep(2)
                jointVelsZero = self.getVelocitiesTrajectory([0,0,0])
                self.manip.controller.SetPath(jointVelsZero)
                #self.manip.PlanToConfiguration(liftConfiguration)
                #time.sleep(1)
                #embed()
                #exit()
                self.manip.PlanToConfiguration(placeConfiguration)
                time.sleep(3)
                
          with prpy.rave.Disabled(self.glass):
            defaultVelocityLimits = self.robot.GetDOFVelocityLimits()
            self.robot.SetDOFVelocityLimits(slowVelocityLimits)       
            self.manip.PlanToConfiguration(dropConfiguration)
            #embed()
            #exit()
            time.sleep(4)
            self.robot.SetDOFVelocityLimits(defaultVelocityLimits)
            self.robot.arm.hand.OpenHand()
            self.robot.Release(self.glass)
            time.sleep(5)
            self.manip.PlanToConfiguration(ReleasedConfiguration)

                    #jointVelsDown = self.getVelocitiesTrajectory([0,0,-0.6])
                    #self.manip.controller.SetPath(jointVelsDown)
                    #time.sleep(4)
                    #self.manip.controller.SetPath(jointVelsZero)
                #self.robot.SetDOFVelocityLimits(defaultVelocityLimits)
         #time.sleep(3.0)

          #with prpy.rave.Disabled(self.glass), prpy.rave.Disabled(self.robot):
          
          #with prpy.rave.Disabled(self.glass):
          #time.sleep(1)

          #add cylinder around glass, which has a thicker geometry. I need to replace this in the future with different geometry groups
          prpy.rave.disable_padding(self.glass, True)
          glass_pose_curr = self.glass.GetTransform()
          glass_pose = numpy.eye(4)
          glass_pose[0,3] = glass_pose_curr[0,3]
          glass_pose[1,3] = glass_pose_curr[1,3] 
          glass_pose[2,3] = glass_pose_curr[2,3]
          self.glass.SetTransform(glass_pose)

          time.sleep(3.0)

          self.manip.PlanToConfiguration(startConfiguration)
      except:
          self.numOfUpdateCalls = 0
          self.manip.PlanToConfiguration(startConfiguration)
          time.sleep(2)
          self.robot.arm.hand.OpenHand()
          self.MODE = self.UPDATING_POSE
          glass_start_pose= numpy.eye(4)
          self.glass.SetTransform(glass_start_pose)

    
if __name__ == "__main__":
    adaManipulationTester = ADAmanipulationTester()
    adaManipulationTester.initSimple() 
