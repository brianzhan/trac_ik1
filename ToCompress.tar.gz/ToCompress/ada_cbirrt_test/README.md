ada_cbirrt_test
============================

=======
A set of test scripts for constrained motion using Ada. 


ada_demo
============================
The goal of the demo is autonomous grasping of an object in the environment. Currently, the model of the object is assumed to be known, as well as its location in the environment. 

I describe below the steps to run the demo:

1. Place an empty coke-can on top of the yellow tape mark, next to the keyboard.
2. Set the permissions for the usb: sudo chmod 777 /dev/mico .
3. Make sure that the robot gripper is open. You can open the griper using the joystick. 
4. In the homes/snikolai/catkin_ws folder, type roslaunch ada_launch default.launch. You may get a usb connection error (annotated in red font), as there is currently an issue with the usb drivers. In that case, repeat steps 2 to 4. 
5. Open a new terminal, and type: rosrun ada_cbirrt_test ada_cbirrt_test_real_robot.py 
6. The robot will then plan a motion to the coke can, execute the motion, grasp the can and then pick it up through constrained motion. 

For any questions, please email Stefanos Nikolaidis: snikolai@andrew.cmu.edu
