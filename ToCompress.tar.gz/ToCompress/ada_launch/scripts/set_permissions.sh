#!/bin/bash
sudo chmod 777 /dev/mico

