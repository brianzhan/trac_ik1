ros_controllers
===============

See [ros_control documentation](http://ros.org/wiki/ros_control) on ros.org


rosbuild support
---------------

By the hydro-devel branch of ros_controllers has been catkinized but remains backwards compatible with Fuerte and earlier via a bash script that enables manifest.xml files to be shown. To enable, run ``. enable_manifest_xml.sh`` in the root of this meta package and all of the manifest.xml files will be enabled.

### Build Status

[![Build Status](https://travis-ci.org/ros-controls/ros_controllers.png?branch=hydro-devel)](https://travis-ci.org/ros-controls/ros_controllers)