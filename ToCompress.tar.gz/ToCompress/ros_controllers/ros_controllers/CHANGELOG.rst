^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ros_controllers
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.9.1 (2014-11-03)
------------------
* Update package maintainers
* Contributors: Adolfo Rodriguez Tsouroukdissian

0.9.0 (2014-10-31)
------------------
* Add rqt_joint_trajectory_controller to metapackage

0.8.1 (2014-07-11)
------------------

0.8.0 (2014-05-12)
------------------

0.7.2 (2014-04-01)
------------------

0.7.1 (2014-03-31)
------------------

0.7.0 (2014-03-28)
------------------
* Add diff_drive_controller and gripper_action_controller dependencies.
* Contributors: Adolfo Rodriguez Tsouroukdissian, Dave Coleman

0.6.0 (2014-02-05)
------------------
* Add self as ros_controllers maintainer.
* Contributors: Adolfo Rodriguez Tsouroukdissian

0.5.4 (2013-09-30)
------------------
* Add joint_trajectory_controller to metapackage.

0.5.3 (2013-09-04)
------------------

0.5.2 (2013-08-06)
------------------

0.5.1 (2013-07-16)
------------------
* Added to maintainer list

0.5.0 (2013-07-16)
------------------
* Added force_torque_sensor_controller
* Removed controller_msgs, switched to depend on control_msgs
* Added imu_sensor_controller
* Updates to effort_controllers


0.4.0 (2013-06-26)
------------------
* Initial release of ros_controllers into bloom/ROS distro
