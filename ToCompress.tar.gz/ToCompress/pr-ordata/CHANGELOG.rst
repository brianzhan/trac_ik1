^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pr_ordata
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2015-02-10)
------------------
* Adding padding to tray edges. Updating tag location on tray
* Adding chomp spheres. These are copied from bowl.kinbody.xml, glass.kinbody.xml and plate.kinbody.xml. Need proper verification.
* adding plastic plate bowl cup and wicker tray
* Adding plastic plate, glass and bowl and wicker tray
* Added a new Fuze bottle model. Missing CHOMP spheres.
* Added a README.
* Switched to Catkin-only.
* Copy the data directory into the devel/install.
* Added the table kinbody.
* Added the bookshelf model.
* Added a textured poptarts model.
* Added table-clearing objects.
* Contributors: Aaron Walsman, Jennifer King, Michael Koval
