#!/usr/bin/env python

import threading
import rospy
from std_msgs.msg import Float32MultiArray

class ControlInput(object):

    """Abstract base class for controller inputs for ROS"""


    def __init__(self):
        self.lock = threading.Lock()
        self.data = self.getDefaultData()


    def startSend(self, rostopic, period=rospy.Duration(0.01)):
        """
        Start the send thread.
        
        :param period: Period between sent packets, ``rospy.Duration``
        :param rostopic: name of rostopic to update, ``str``
        """

        self.pub = rospy.Publisher(rostopic, Float32MultiArray)
        self.send_thread = threading.Thread(target=self._send, args=(period,))
        self.send_thread.start()

    def _send(self, period):
        while not rospy.is_shutdown():
            start = rospy.get_rostime()
            
            self.lock.acquire()
            try:
                data = self.data
            finally:
                self.lock.release()

            self.pub.publish(data)

            end = rospy.get_rostime()

            if end - start < period:
                rospy.sleep(period - (end - start))
            else:
                rospy.logwarn("Sending data took longer than the specified period.")

    def receive(*args, **kwargs):
        """
        Receive method, to be passed to the subscriber as a callback.

        This method is not implemented in the base class because it depends on
        the input type.
        """

        raise NotImplementedError

    def getDefaultData(*args, **kwargs):
        """
        Returns whatever message should be sent when no data has been received.

        (must be a Float32MultiArray)
        """
        raise NotImplementedError
