#!/usr/bin/python

#Written by Deepak Gopinath July 1st 2015. Joystick node to control joint velocities of mico arm in Gazebo
import rospy
import sys
import numpy as np 
from std_msgs.msg import Float64, Float32MultiArray, MultiArrayDimension
from sensor_msgs.msg import Joy



class MyJoynode():
	"""docstring for Joy"""
	def __init__(self):
		"MyJoynode constructor"
		rospy.loginfo("In MyJoynode constructor")
		rospy.init_node("joytomico", anonymous=True)
		self.initpublishers()
		self.joy = rospy.Subscriber('joy', Joy, self.myJoyCallback)
		self.mode = 0
		self.max_vel = 0.4
		self.ex = 0.0
		self.ey = 0.0
		self.ez =0.0
		self.etheta = 0.0
		self.ephi = 0.0
		self.epsi = 0.0
		self.send_msg = Float32MultiArray()
		_dim = [MultiArrayDimension()]
		_dim[0].label = 'cartesian_vel'
		_dim[0].size = 8
		_dim[0].stride = 8


		self.send_msg.layout.dim = _dim
		self._cart_vel = np.zeros(8)
		self.send_msg.data = np.zeros_like(self._cart_vel)


	def myJoyCallback(self, joymsg):

		for i in range(0,8):
			self._cart_vel[i] = 0.0



		# joymsg.axes[1] = -joymsg.axes[1]
		# joymsg.axes[2] = -joymsg.axes[2]

		if self.mode == 0:
			for i in range(0,3):
				self._cart_vel[i] = joymsg.axes[i]*self.max_vel

			rospy.loginfo("Axis 1 value %f", self._cart_vel[0])
			rospy.loginfo("Axis 2 value %f", self._cart_vel[1])
			rospy.loginfo("Axis 3 value %f", self._cart_vel[2])
			
		elif self.mode == 1:
			for i in range(3,6):
				self._cart_vel[i] = joymsg.axes[i-3]*self.max_vel

			rospy.loginfo("Axis 1 value %f", self._cart_vel[3])
			rospy.loginfo("Axis 2 value %f", self._cart_vel[4])
			rospy.loginfo("Axis 3 value %f", self._cart_vel[5])


		# rospy.loginfo("Button 1 value %d", joy.buttons[0])
		# rospy.loginfo("Button 2 value %d", joy.buttons[1])
		print ("     ")
		print ("     ")

  		
  		if joymsg.buttons[0]:
  			self.mode = 1 - self.mode
  			print("current mode is %d", self.mode)

  		self.send_msg.data = self._cart_vel
  		self.ikpub.publish(self.send_msg)
  		#all the joints will be getting velocity commands now. ik solver will return a list of joint velocities


  # 		if not self.mode:
		# 	self.j1pub.publish(self._cart_vel[0])
		# 	self.j2pub.publish(self._cart_vel[1])
		# 	self.j3pub.publish(self._cart_vel[2])
		# elif self.mode:
		# 	self.j4pub.publish(self._cart_vel[3])
		# 	self.j5pub.publish(self._cart_vel[4])
		# 	self.j6pub.publish(self._cart_vel[5])


	def initpublishers(self):
		self.ikpub = rospy.Publisher('cart_signal', Float32MultiArray, queue_size=1) #for inverse jacobian calculation
		self.j1pub = rospy.Publisher('/ada/vel_j1_controller/command', Float64, queue_size=1)
		self.j2pub = rospy.Publisher('/ada/vel_j2_controller/command', Float64, queue_size=1)
		self.j3pub = rospy.Publisher('/ada/vel_j3_controller/command', Float64, queue_size=1)
		self.j4pub = rospy.Publisher('/ada/vel_j4_controller/command', Float64, queue_size=1)
		self.j5pub = rospy.Publisher('/ada/vel_j5_controller/command', Float64, queue_size=1)
		self.j6pub = rospy.Publisher('/ada/vel_j6_controller/command', Float64, queue_size=1)




def main():
	global joynode
	joynode = MyJoynode()
	rospy.loginfo("TestExample Starting")
	try:
		rospy.spin()
	except rospy.ROSInterruptException: pass
	rospy.loginfo("TestExample finished")

if __name__ == '__main__':
	sys.exit(main())

