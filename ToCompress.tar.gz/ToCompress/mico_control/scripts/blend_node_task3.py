#!/usr/bin/python

import roslib
roslib.load_manifest('seds')
roslib.load_manifest('mico_control')
import rospy
import rospy.rostime as rostime
from std_msgs.msg import Float64, Float32MultiArray, MultiArrayDimension
from seds.srv import SedsVelocities, SedsVelocitiesRequest, SedsVelocitiesResponse
from seds.msg import SedsVel 
import threading
import numpy as np
import tf
from tf.transformations import euler_from_quaternion, quaternion_from_euler, quaternion_matrix
from dynamic_reconfigure.server import Server as DynamicReconfigureServer
from mico_control.cfg import mico_control_paramsConfig as ConfigType

npa = np.array

class BlendNode(object):

	def __init__(self, period=rospy.Duration(0.05)):
		rospy.loginfo("In init of blendnode class")
		self.lock = threading.Lock()
		self.period = period
		self.alpha = 0 # this alpha will be determined by the goal confidence. 
		self.mafwindowsize = 30
		self.numdof = 8
		self.user_vel_list = [[0]*(self.numdof-2)]*self.mafwindowsize #to perform maf on a history of user vel
		self.seds_vel_list = [[0]*self.numdof]*self.mafwindowsize
		#predefine the targets of the seds model (the end points) and store them in an array. by hand
		self.numOfModels = 2

		self.currentSedsModel = 0

		self.targetsPosition = [[0]*3]*self.numOfModels

		#task2
		self.targetsPosition[0] = [0.305, -0.335, 0.119]
		# self.targetsPosition[1] = [-0.062, -0.367, 0.071]
		self.targetsPosition[1] = [-0.151, -0.344, 0.294]

		#task3
		# self.targetsPosition[0] = [0.265, -0.255, 0.06] #wrt to base
		# self.targetsPosition[1] = [-0.041, -0.369, 0.06]
		# self.targetsPosition[2] = [-0.268, -0.223, 0.06]

		self.distanceToGoals = [100]*self.numOfModels
		self.goalconfidence = [0]*self.numOfModels
		self.confidencelist = [-1]*self.numOfModels # should be self.numOfModels
		self.cosangle = [None]*self.numOfModels
		self.listener = tf.TransformListener(True, rospy.Duration(30))

		self.smoothed_user_vel = [0]*self.numdof
		self.smoothed_seds_vel = [0]*self.numdof
		self.blend_vel = Float32MultiArray()
		_dim = [MultiArrayDimension()]
		_dim[0].label = 'cartesian_velocity'
		_dim[0].size = 8
		_dim[0].stride = 8
		self.blend_vel.layout.dim = _dim
		self.blend_vel.data = [np.finfo(np.double).tiny]*self.numdof #realmin,, to avoid divide by zero

		self.smoothed_user_velforpub = Float32MultiArray()
		self.smoothed_seds_velforpub = Float32MultiArray()
		self.conflistforpub = Float32MultiArray()
		self.distlistforpub = Float32MultiArray()
		self.confidence = 0

		self.confthresh = 0.2
		self.confmax = 0.65
		self.alphamax = 0.9

		self.server = DynamicReconfigureServer(ConfigType, self.reconfigureParams)

		if self.confmax != self.confthresh:
			self.confslope = float(self.alphamax)/(self.confmax - self.confthresh)
		else:
			self.confslope = -1

		self.model_source_frameid = "base_link"
		self.model_target_frameid = "Hand_Link"
		self.listener.waitForTransform(self.model_source_frameid, self.model_target_frameid, rostime.Time(0),timeout=rostime.Duration(50))
		rospy.Subscriber("user_vel", Float32MultiArray, self.userCallback, queue_size=1)
		rospy.Subscriber("seds_vel", Float32MultiArray, self.autoCallback, queue_size=1)


		rospy.Service("/mico_driver_cart/computeconfidence", SedsVelocities, self.compute_goal_confidence_sedsvel)

		self.blendcartpub = rospy.Publisher("control_input", Float32MultiArray, queue_size=1)
		self.smoothed_user_velpub = rospy.Publisher("smoothed_user_vel", Float32MultiArray, queue_size=1)
		self.smoothed_seds_velpub = rospy.Publisher("smoothed_seds_vel", Float32MultiArray, queue_size=1)
		self.confpub = rospy.Publisher("goal_confidence", Float32MultiArray, queue_size=1)
		self.distpub = rospy.Publisher("dist_to_goals", Float32MultiArray, queue_size=1)
		self.blend_thread = threading.Thread(target=self._publishblend, args=(self.period,))
		self.blend_thread.start()

		

	def reconfigureParams(self, config, level):
		self.confthresh = config["cthresh"]
		self.confmax = config["cmax"]
		self.alphamax = config["amax"]

		
		if config["isteleop"] == True:
			print "teleop on"
			self.confthresh = 0.3
			self.confmax = 0.9
			self.alphamax = 0.0
		else:
			print "teleop off"

			
		if config["ismin"] == True:
			print "min assist on"
			self.confthresh = 0.3
			self.confmax = 0.9
			self.alphamax = 0.3
		else:
			print "min assist off"

		if config["ismid"] == True:
			print "mid assist is on"
			self.confthresh = 0.3
			self.confmax = 0.7
			self.alphamax = 0.5
		else:
			print "mid assist is off"

		if config["ismax"] == True:
			print "max assist is on"
			self.confthresh = 0.3
			self.confmax = 0.5
			self.alphamax = 0.8
		else:
			print "max assist is off"

		if config["isca"] == True:
			print "custom a assist is on"
			self.confthresh = 0.3 #change these values properly once determined
			self.confmax = 0.7
			self.alphamax = 0.4
		else:
			print "custom a assist is off"

		if config["iscb"] == True:
			print "custom b assist is on"
			self.confthresh = 0.3
			self.confmax = 0.8
			self.alphamax = 0.5
		else:
			print "custom b assist is off"


		print "cthresh,cmax,amax, %f, %f, %f" % (self.confthresh, self.confmax, self.alphamax)
		# print config["cthresh"]
		# print "cmax"
		# print config["cmax"]
		# print "amax"
		# print config["amax"]
		if self.confmax < self.confthresh:
			self.confmax = self.confthresh + 0.1

		self.confslope = float(self.alphamax)/(self.confmax - self.confthresh)
		return config 

	def _publishblend(self, period):
		while not rospy.is_shutdown():
			start = rospy.get_rostime()
			self.lock.acquire()
			# rospy.loginfo("inside running thread")
			# self.confidence = self.compute_goal_confidence()
			# print "Dot product"
			# print self.cosangle
			self.alpha = self.alpha_from_confidence(self.confidence)
			# print "alpha = %f" % self.alpha
			# self.alpha = 1
			for i in range(0, self.numdof-2):
				self.blend_vel.data[i] = (1-self.alpha)*self.smoothed_user_vel[i] + self.alpha*self.smoothed_seds_vel[i] #+ np.finfo(np.double).tiny

			self.blend_vel.data[6] = self.smoothed_user_vel[6]
			self.blend_vel.data[7] = self.smoothed_user_vel[7]
			# self.checkForTableCollision()
			self.smoothed_user_velforpub.data = self.smoothed_user_vel
			self.smoothed_seds_velforpub.data = self.smoothed_seds_vel
			
			self.distlistforpub.data = self.distanceToGoals

			self.blendcartpub.publish(self.blend_vel)
			self.smoothed_user_velpub.publish(self.smoothed_user_velforpub)
			self.smoothed_seds_velpub.publish(self.smoothed_seds_velforpub)
			
			self.distpub.publish(self.distlistforpub)

			self.lock.release()
			end = rospy.get_rostime()
			if end-start < period:
				rospy.sleep(period - (end-start))
			else:
				rospy.logwarn("sending data took longer than the specified period.")


	def checkForTableCollision(self):
		et = self.listener.lookupTransform(self.model_source_frameid, self.model_target_frameid, rostime.Time(0))
		#can possibly add position of wrist2 link as well. 
		pos = list(et[0][:])
		if pos[2] < 0.08:
			print "near table"
			for i in range(0, self.numdof-2):
				self.blend_vel.data[i] = 0
			self.blend_vel.data[2] = 0.02


	def compute_goal_confidence_sedsvel(self, sedsvelos): #sedsvelocities - SedsVelocitiesRequest
		currentModel = SedsVelocitiesResponse()
		vellist = sedsvelos.vels #this is the list containing all the velocities. 
		# for i in range(0, self.numOfModels):
		# 	print "VEl %d" % (i+1)
		# 	print vellist[i].vel[:3]

		for i in range(0, self.numOfModels):
			currvel = npa(self.smoothed_user_vel[:3])
			if np.linalg.norm(currvel) > 0.0001: #and np.linalg.norm(vellist[i].vel) > 0.0001:
				self.confidencelist[i] = np.dot(vellist[i].vel[:3], currvel)/(np.linalg.norm(vellist[i].vel[:3]) * np.linalg.norm(currvel))
				self.confidencelist[i] = (self.confidencelist[i] + 1)*0.5
			else:
				self.confidencelist = [None]*self.numOfModels

		# if all(list(self.confidencelist)) == False:
		# 	maxconfidence = 0
		# 	currentModel.currentmod = 0 # doesnt matter which one, because alpha will be 1. 
		# else:
		# 	maxconfidence = np.amax(np.array(self.confidencelist))
		# 	currentModel.currentmod = np.argmax(np.array(self.confidencelist))

		
		# self.currentSedsModel = currentModel.currentmod



		et = self.listener.lookupTransform(self.model_source_frameid, self.model_target_frameid, rostime.Time(0))
		pos = list(et[0][:])
		xyrobot = np.array(pos[:3])
		# # print xyrobot
		for i in range(0, self.numOfModels):
			# self.distanceToGoals[i] = np.linalg.norm(xyrobot - np.array(self.targetsPosition[i]))
			self.distanceToGoals[i] = np.linalg.norm(npa(self.targetsPosition[i]) - xyrobot)
		# 	print self.distanceToGoals[i]

		if all(list(self.confidencelist)) == False:
			self.confidencelist = [-1]*self.numOfModels
			maxconfidence = 0
			currentModel.currentmod = 0
		else:
			for i in range(0, self.numOfModels):
				self.confidencelist[i] = (self.confidencelist[i] + 2*np.exp(-self.distanceToGoals[i]))/3
			maxconfidence = np.amax(np.array(self.confidencelist))
			currentModel.currentmod = np.argmax(np.array(self.confidencelist))

		if self.distanceToGoals[0] < 0.07 and xyrobot[0]-self.targetsPosition[0][0] < 0.07 and np.absolute(xyrobot[1] - self.targetsPosition[0][1]) < 0.07:
			print "in tar 0"
			maxconfidence = 0.9
			currentModel.currentmod = 0

		if self.distanceToGoals[1] < 0.1 and xyrobot[0]-self.targetsPosition[1][0] > -0.2:
			print "in tar 1"
			maxconfidence = 0.8
			currentModel.currentmod = 1
		# if self.distanceToGoals[0] < 0.15:
		# 	print "in tar 0"
		# 	currentModel.currentmod = 0

		# if self.distanceToGoals[1] < 0.15:
		# 	print "in tar 1"
		# 	currentModel.currentmod = 1

		# if self.distanceToGoals[2] < 0.15:
		# 	print "in here 2"
		# 	currentModel.currentmod = 2

		# print self.distanceToGoals

		# print "Conf List"
		self.conflistforpub.data = self.confidencelist
		self.confpub.publish(self.conflistforpub)
		print self.confidencelist
		self.confidence = maxconfidence
		print "Confidence is %f and the model is %d" % (maxconfidence, currentModel.currentmod)

		return currentModel



	def alpha_from_confidence(self, conf):
		if self.confslope != -1.0:
			if conf <= self.confthresh:
				return 0
			elif conf > self.confthresh and conf <= self.confmax:
				return self.confslope*(conf-self.confthresh)
			elif conf > self.confmax and conf <= 1.0:
				return self.alphamax
		else:
			if conf <= self.confthresh:
				return 0
			else:
				return self.alphamax


	# def compute_goal_confidence(self):
	# 	#each time the confidence is computed the target will change. which measn the ds_node should be updated about the change in target and obstacles
	# 	#can possibly have three different seds model running all the time. ANd then pick on based on the maximum confidence

	# 	t = self.listener.getLatestCommonTime(self.model_source_frameid, self.model_target_frameid)
	# 	# et = self.listener.lookupTransformFull(self.model_source_frameid, t, self.model_target_frameid, rostime.Time(0), "base_link")
	# 	et = self.listener.lookupTransform(self.model_source_frameid, self.model_target_frameid, rostime.Time(0))
	# 	currentrob = et[0][:] + euler_from_quaternion(et[1][:]) #wrt to base
	# 	# print currentrob
	# 	for i in range(0, self.numOfModels):
	# 		targetwrtrobot = npa(self.targets[i][:3]) - npa(currentrob[:3]) 
	# 		# targetwrtrobot = targetwrtrobot/(np.linalg.norm(targetwrtrobot)) # unit vector
	# 		# print targetwrtrobot
	# 		# currvel = npa(self.blend_vel.data[:3])
	# 		currvel = npa(self.smoothed_user_vel[:3])
	# 		# print np.linalg.norm(currvel)
	# 		if np.linalg.norm(currvel) > 0.00001:
	# 			self.cosangle[i] = np.dot(targetwrtrobot, currvel)/(np.linalg.norm(targetwrtrobot) * np.linalg.norm(currvel))
	# 			self.cosangle[i] = (self.cosangle[i] + 1)*0.5
	# 		else:
	# 			self.cosangle = [None]*self.numOfModels
			
	# 	# print self.cosangle

	# 	if all(list(self.cosangle)) == False:
	# 		# print "in here"
	# 		confidence = 0
	# 	else:
	# 		# self.cosangle = np.array(self.cosangle)
	# 		# confidence = np.amax(self.cosangle)
	# 		confidence = self.cosangle[1]
	# 	return confidence

	def userCallback(self, msg):
		# add new velocities to the list. compute smoothed velocity.
		# print "inside user vel callback"
		# print type(msg.data)
		# print "unsmoothed %s" % str(list(msg.data))
		popped = self.user_vel_list.pop(0)
		self.user_vel_list.append(list(msg.data[:6]))
		nparray = npa(self.user_vel_list)
		self.smoothed_user_vel[:6] = list(np.mean(nparray, axis=0))
		for i in range(0, self.numdof-2):
			self.smoothed_user_vel[i] = self.smoothed_user_vel[i]*0.65
		self.smoothed_user_vel[6] = msg.data[6]
		self.smoothed_user_vel[7] = msg.data[7]
		# print "smoothed %s" %  str(self.smoothed_user_vel)
		#convert rotational velocity in body frame to space frame

		t = self.listener.getLatestCommonTime(self.model_source_frameid, self.model_target_frameid)
		et = self.listener.lookupTransform(self.model_source_frameid, self.model_target_frameid, rostime.Time(0))
		HR = quaternion_matrix(et[1][:]) #homoegenous rotation matrix
		R = np.matrix(HR[0:3,0:3]) #rotation matrix
		velbf = np.array(self.smoothed_user_vel[3:6])
		velwf = np.dot(R, velbf) #vs = Rsb*vb
		self.smoothed_user_vel[3:6] = velwf.tolist()[0] #repopulate the rotation component with the transfromed rotational velocity
	def autoCallback(self,msg):

		popped = self.seds_vel_list.pop(0)
		self.seds_vel_list.append(list(msg.data))
		nparray = npa(self.seds_vel_list)
		self.smoothed_seds_vel = list(np.mean(nparray, axis=0))

		# print self.seds_vel
		

def main():
	rospy.init_node("blend_node", anonymous=True);
	rospy.loginfo("In blending node")
	bn = BlendNode()
	# try:
	# 	rospy.spin()
	# except rospy.ROSInterruptException: pass

	rospy.loginfo("blend_node exiting")



if __name__ == '__main__':
	main()