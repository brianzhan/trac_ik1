#!/usr/bin/python
import roslib
roslib.load_manifest('tf')
roslib.load_manifest('seds')

import rospy
import math
import numpy as np 
import getopt
import sys
import glob
import os
import rosbag
import rospy.rostime as rostime

npa = np.array
from tf import TransformerROS, LookupException, ConnectivityException, ExtrapolationException
from tf.transformations import euler_from_quaternion
import tf

from seds.msg import SedsMessage
from std_msgs.msg import String

class BagListener(TransformerROS):
	 def __init__(self, *args):
	 	TransformerROS.__init__(self, *args)

	 def load(self, data):
	 	for transform in data.transforms:
	 		self.setTransform(transform, "tf2seds_mico")

def iszero(arr):
	for e in arr:
		if math.fabs(e) > 1e-4:
			return False
		return True

def process_bags(bagfiles, output, source_frameid, target_frameid):
	outbag = rosbag.Bag(output, 'w')
	pm = SedsMessage()
	cm = SedsMessage()
	zero = rostime.Duration(0)

	s1 = String()
	s1.data = source_frameid
	outbag.write('seds/source_fid', s1)
	rospy.loginfo("Writing seds/source_frameid" + s1.data)

	s2 = String()
	s2.data = target_frameid
	outbag.write('seds/target_fid', s2)
	rospy.loginfo("Writing seds/target_frameid" + s2.data)

	for (i, bagname) in enumerate(bagfiles):
		rospy.loginfo("Processing bag %d: %s" % (i, bagname))

		listener = BagListener()
		bag = rosbag.Bag(bagname)
		first = True

		tf_cnt = 0
		tf_match_cnt = 0
		nonzero_cnt = 0

		for topic, msg, t in bag.read_messages():
			if topic[-2:] == "tf":
				listener.load(msg)
				tf_cnt += 1
				try:
					unmoving_frameid = "mico_link_base"
					source_time = listener.getLatestCommonTime(source_frameid, unmoving_frameid)
					target_time = listener.getLatestCommonTime(target_frameid, unmoving_frameid)
					et = listener.lookupTransformFull(source_frameid, source_time, target_frameid, target_time, unmoving_frameid)
					tf_match_cnt += 1
					cm.x = et[0][:] + euler_from_quaternion(et[1][:])
					cm.index = i 
					cm.t = max(source_time, target_time)

					if first:
						pm.x = cm.x
						pm.index = cm.index
						pm.t = cm.t
						first = False

					pm.dx = npa(cm.x) - npa(pm.x)
					pm.dt = cm.t - pm.t

					if(pm.dt != zero and not iszero(pm.dx)):
						outbag.write('seds/trajectories', pm)
						nonzero_cnt += 1
						pm.x = cm.x
						pm.t = cm.t

				except tf.Exception, error:
					rospy.logdebug("%s %s %s %s" % (error,topic,msg,t))
 
		cm.dx = npa(cm.x) - npa(pm.x)
		outbag.write('seds/trajectories', cm)
		rospy.loginfo("Processed %s, found transforms for %s and %s are nonzero" % (str(tf_cnt), str(tf_match_cnt), str(nonzero_cnt)))
		bag.close()

	rospy.loginfo("Writing bag %s", output)
	outbag.close()




def main(argv):

	(options, args) = getopt.getopt(argv, 'b:o:')
	rospy.init_node("tf2seds_mico")
	rospy.loginfo("i am here")

	for o,a in options:
		if o == '-b':
			path = a 
		elif o == '-o':
			output = a

	source_frameid = rospy.get_param("/tf2seds_mico/source_frameid", "mico_link_base")
	target_frameid = rospy.get_param("/tf2seds_mico/target_frameid", "mico_link_hand")

	bagfiles = glob.glob(os.path.normpath(path + "/*.bag"))
	process_bags(bagfiles, output, source_frameid, target_frameid)
	

if __name__ == '__main__':
	main(sys.argv[1:])