#!/usr/bin/python

import numpy as np 
import scipy.io as sio

def main():
	obj_arr = np.zeros((2,1), dtype = np.ndarray)
	obj_arr[0] = np.arange(10)
	obj_arr[1] = np.arange(23)
	

	
	sio.savemat('np_cells.mat', {'obj_arr':obj_arr})

if __name__ == '__main__':
	main()