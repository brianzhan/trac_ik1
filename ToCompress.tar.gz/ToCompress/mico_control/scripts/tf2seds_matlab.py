#!/usr/bin/python
import roslib
roslib.load_manifest('tf')
roslib.load_manifest('seds')

import rospy
import math
import numpy as np 
import getopt
import sys
import glob
import os
import rosbag
import rospy.rostime as rostime
import scipy.io as sio
npa = np.array
from tf import TransformerROS, LookupException, ConnectivityException, ExtrapolationException
from tf.transformations import euler_from_quaternion
import tf

from seds.msg import SedsMessage
from std_msgs.msg import String
from IPython import embed
class BagListener(TransformerROS):
	 def __init__(self, *args):
	 	TransformerROS.__init__(self, *args)

	 def load(self, data):
	 	for transform in data.transforms:
	 		self.setTransform(transform, "tf2seds_mico")

def iszero(arr):
	for e in arr:
		if math.fabs(e) > 1e-4:
			return False
		return True

def process_bags(bagfiles, rotmode, source_frameid, target_frameid):
	# outbag = rosbag.Bag(output, 'w')
	pm = SedsMessage()
	cm = SedsMessage()
	zero = rostime.Duration(0)
	# if rotmode == 'euler':
	# 	print 'it is euler'
	# elif rotmode == 'quaternion':
	# 	print 'it is quaternion'

	# s1 = String()
	# s1.data = source_frameid
	# # outbag.write('seds/source_fid', s1)
	# # rospy.loginfo("Writing seds/source_frameid" + s1.data)

	# s2 = String()
	# s2.data = target_frameid
	# # outbag.write('seds/target_fid', s2)
	# # rospy.loginfo("Writing seds/target_frameid" + s2.data)
	globalbigarray = []
	globaltimearray = []

	for (i, bagname) in enumerate(bagfiles):
		rospy.loginfo("Processing bag %d: %s" % (i, bagname))

		if i > 0:
			filename = "traj_%d" % (i-1)
			filenamet = "trajtime_%d" % (i-1)
			var1 = "a"
			var2 = "t"
			print filename
			sio.savemat(filename, {var1:bigarray})
			sio.savemat(filenamet, {var2:timearray})
			# embed()

		
		listener = BagListener()
		bag = rosbag.Bag(bagname)
		first = True

		tf_cnt = 0
		tf_match_cnt = 0
		nonzero_cnt = 0
		bigarray = []
		timearray = []

		if rotmode == 'euler':
			bigarray = np.zeros((6,)).reshape(6,1) #7,1 is for quaternions. np.zeros((6,)).reshape(6,1) if rotation is represented by euler angles
		elif rotmode == 'quaternion':
			bigarray = np.zeros((7,)).reshape(7,1) #7,1 is for quaternions. np.zeros((6,)).reshape(6,1) if rotation is represented by euler angles
		
		timearray = np.array([0])

		for topic, msg, t in bag.read_messages():
			if topic[-2:] == "tf":
				listener.load(msg)
				tf_cnt += 1
				try:
					unmoving_frameid = "base_link"
					source_time = listener.getLatestCommonTime(source_frameid, unmoving_frameid)
					target_time = listener.getLatestCommonTime(target_frameid, unmoving_frameid)
					et = listener.lookupTransformFull(source_frameid, source_time, target_frameid, target_time, unmoving_frameid)
					tf_match_cnt += 1
					if rotmode == 'euler':
						cm.x = et[0][:] + euler_from_quaternion(et[1][:])
					elif rotmode == 'quaternion':
						cm.x = et[0][:] + et[1][:]
					
					# cm.x = et[0][:] + et[1][:] # et[0][:] + euler_from_quaternion(et[1][:]) if euler angles are used for representing 
					cm.index = i 
					cm.t = max(source_time, target_time)

					if first:
						pm.x = cm.x
						pm.index = cm.index
						pm.t = cm.t
						first = False

					pm.dx = npa(cm.x) - npa(pm.x)
					pm.dt = cm.t - pm.t

					if(pm.dt != zero and not iszero(pm.dx)):
						# outbag.write('seds/trajectories', pm)
						# print (npa(pm.x).shape)
						pmnp = npa(pm.x)
						pmt = float(pm.t.secs) + (float(pm.t.nsecs)/1e9)
						pmt = npa([pmt])
						# print pmt
						# embed()
						vert = pmnp.reshape(pmnp.size,1)
						bigarray = np.concatenate((bigarray,vert), axis = 1)
						timearray = np.concatenate((timearray, pmt), axis = 1)
						# print bigarray
						# embed()
						nonzero_cnt += 1
						pm.x = cm.x
						pm.t = cm.t

				except tf.Exception, error:
					rospy.logdebug("%s %s %s %s" % (error,topic,msg,t))
 
		cm.dx = npa(cm.x) - npa(pm.x)
		# outbag.write('seds/trajectories', cm)
		cmnp = npa(cm.x)
		cmt = float(cm.t.secs) + float(cm.t.nsecs)/1e9
		cmt = npa([cmt])
		vert = cmnp.reshape(cmnp.size, 1)
		bigarray = np.concatenate((bigarray, vert), axis = 1)
		timearray = np.concatenate((timearray, cmt), axis = 1)
		bigarray = np.delete(bigarray, 0, 1)
		timearray = np.delete(timearray, 0)
		rospy.loginfo("Processed %s, found transforms for %s and %s are nonzero" % (str(tf_cnt), str(tf_match_cnt), str(nonzero_cnt)))
		globalbigarray = bigarray
		globaltimearray = timearray
		bag.close()


	filename = "traj_%d" % (i)
	filenamet = "trajtime_%d" % (i)
	var1 = "a"
	var2 = "t"
	print filename
	sio.savemat(filename, {var1:globalbigarray})
	sio.savemat(filenamet, {var2:globaltimearray})

	# rospy.loginfo("Writing bag %s", output)
	# outbag.close()




def main(argv):

	(options, args) = getopt.getopt(argv, 'b:r:')
	rospy.init_node("tf2seds_mico")
	rospy.loginfo("i am here")

	for o,a in options:
		if o == '-b':
			path = a
		elif o == '-r':
			assert a in ('euler', 'quaternion')
			rotmode = a 

	source_frameid = rospy.get_param("/tf2seds_mico/source_frameid", "base_link")
	target_frameid = rospy.get_param("/tf2seds_mico/target_frameid", "Hand_Link")

	bagfiles = glob.glob(os.path.normpath(path + "/*.bag"))
	process_bags(bagfiles, rotmode, source_frameid, target_frameid)
	

if __name__ == '__main__':
	main(sys.argv[1:])