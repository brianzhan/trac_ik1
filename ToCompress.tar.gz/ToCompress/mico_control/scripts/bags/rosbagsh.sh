function record_bags
{
	echo "Press enter to start"
	echo "Once done press enter to stop"
	read 
	cd tf
	rosbag record /tf &

	cd ../js
	rosbag record /ada/joint_states &
	read
	kill -2 $$
}

record_bags 