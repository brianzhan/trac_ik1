#!/usr/bin/python

import roslib
roslib.load_manifest('seds')
roslib.load_manifest('mico_control')
import rospy
import rospy.rostime as rostime
from std_msgs.msg import Float64, Float32MultiArray, MultiArrayDimension
from seds.srv import SedsVelocities, SedsVelocitiesRequest, SedsVelocitiesResponse
from seds.msg import SedsVel 
import threading
import numpy as np
import tf
from tf.transformations import euler_from_quaternion, quaternion_from_euler
from dynamic_reconfigure.server import Server as DynamicReconfigureServer
from mico_control.cfg import mico_control_paramsConfig as ConfigType

npa = np.array

class BlendNode(object):

	def __init__(self, period=rospy.Duration(0.05)):
		rospy.loginfo("In init of blendnode class")
		self.lock = threading.Lock()
		self.period = period
		self.alpha = 0 # this alpha will be determined by the goal confidence. 
		self.mafwindowsize = 30
		self.numdof = 8
		self.user_vel_list = [[0]*(self.numdof-2)]*self.mafwindowsize #to perform maf on a history of user vel
		self.seds_vel_list = [[0]*self.numdof]*self.mafwindowsize
		#predefine the targets of the seds model (the end points) and store them in an array. by hand
		self.numOfModels = 3

		self.currentSedsModel = 0

		self.targetsPosition = [[0]*3]*self.numOfModels

		#task2
		self.targetsPosition[0] = [0.305, -0.335, 0.119]
		self.targetsPosition[1] = [-0.062, -0.367, 0.071]

		#task3
		# self.targetsPosition[0] = [0.265, -0.255, 0.06] #wrt to base
		# self.targetsPosition[1] = [-0.041, -0.369, 0.06]
		# self.targetsPosition[2] = [-0.268, -0.223, 0.06]

		self.distanceToGoals = [100]*self.numOfModels
		self.goalconfidence = [0]*self.numOfModels
		self.confidencelist = [None]*self.numOfModels # should be self.numOfModels
		self.cosangle = [None]*self.numOfModels
		self.listener = tf.TransformListener(True, rospy.Duration(30))

		self.smoothed_user_vel = [0]*self.numdof
		self.smoothed_seds_vel = [0]*self.numdof
		self.blend_vel = Float32MultiArray()
		_dim = [MultiArrayDimension()]
		_dim[0].label = 'cartesian_velocity'
		_dim[0].size = 8
		_dim[0].stride = 8
		self.blend_vel.layout.dim = _dim
		self.blend_vel.data = [np.finfo(np.double).tiny]*self.numdof #realmin,, to avoid divide by zero

		self.confidence = 0

		self.confthresh = 0.2
		self.confmax = 0.65
		self.alphamax = 0.9

		self.server = DynamicReconfigureServer(ConfigType, self.reconfigureParams)

		if self.confmax != self.confthresh:
			self.confslope = float(self.alphamax)/(self.confmax - self.confthresh)
		else:
			self.confslope = -1

		self.model_source_frameid = "base_link"
		self.model_target_frameid = "Hand_Link"
		self.listener.waitForTransform(self.model_source_frameid, self.model_target_frameid, rostime.Time(0),timeout=rostime.Duration(50))
		rospy.Subscriber("user_vel", Float32MultiArray, self.userCallback, queue_size=1)
		rospy.Subscriber("seds_vel", Float32MultiArray, self.autoCallback, queue_size=1)


		rospy.Service("/mico_driver_cart/computeconfidence", SedsVelocities, self.compute_goal_confidence_sedsvel)

		self.blendcartpub = rospy.Publisher("control_input", Float32MultiArray, queue_size=1)
		self.blend_thread = threading.Thread(target=self._publishblend, args=(self.period,))
		self.blend_thread.start()

		

	def reconfigureParams(self, config, level):
		self.confthresh = config["cthresh"]
		self.confmax = config["cmax"]
		self.alphamax = config["amax"]

		if self.confmax < self.confthresh:
			self.confmax = self.confthresh + 0.1
		print "cthresh"
		print config["cthresh"]
		print "cmax"
		print config["cmax"]
		print "amax"
		print config["amax"]
		return config 

	def _publishblend(self, period):
		while not rospy.is_shutdown():
			start = rospy.get_rostime()
			self.lock.acquire()
			# rospy.loginfo("inside running thread")
			# self.confidence = self.compute_goal_confidence()
			# print "Dot product"
			# print self.cosangle
			# self.alpha = self.alpha_from_confidence(self.confidence)
			# print "alpha = %f" % self.alpha
			self.alpha = 0
			for i in range(0, self.numdof-2):
				self.blend_vel.data[i] = (1-self.alpha)*self.smoothed_user_vel[i] + self.alpha*self.smoothed_seds_vel[i] #+ np.finfo(np.double).tiny

			self.blend_vel.data[6] = self.smoothed_user_vel[6]
			self.blend_vel.data[7] = self.smoothed_user_vel[7]
			# self.checkForTableCollision()
			self.blendcartpub.publish(self.blend_vel)
			self.lock.release()
			end = rospy.get_rostime()
			if end-start < period:
				rospy.sleep(period - (end-start))
			else:
				rospy.logwarn("sending data took longer than the specified period.")


	def checkForTableCollision(self):
		et = self.listener.lookupTransform(self.model_source_frameid, self.model_target_frameid, rostime.Time(0))
		#can possibly add position of wrist2 link as well. 
		pos = list(et[0][:])
		if pos[2] < 0.08:
			print "near table"
			for i in range(0, self.numdof-2):
				self.blend_vel.data[i] = 0
			self.blend_vel.data[2] = 0.02


	def compute_goal_confidence_sedsvel(self, sedsvelos): #sedsvelocities - SedsVelocitiesRequest
		currentModel = SedsVelocitiesResponse()
		vellist = sedsvelos.vels #this is the list containing all the velocities. 
		# for i in range(0, self.numOfModels):
		# 	print "VEl %d" % (i+1)
		# 	print vellist[i].vel[:3]

		for i in range(0, self.numOfModels):
			currvel = npa(self.smoothed_user_vel[:3])
			if np.linalg.norm(currvel) > 0.0001: #and np.linalg.norm(vellist[i].vel) > 0.0001:
				self.confidencelist[i] = np.dot(vellist[i].vel[:3], currvel)/(np.linalg.norm(vellist[i].vel[:3]) * np.linalg.norm(currvel))
				self.confidencelist[i] = (self.confidencelist[i] + 1)*0.5
			else:
				self.confidencelist = [None]*self.numOfModels

		# if all(list(self.confidencelist)) == False:
		# 	maxconfidence = 0
		# 	currentModel.currentmod = 0 # doesnt matter which one, because alpha will be 1. 
		# else:
		# 	maxconfidence = np.amax(np.array(self.confidencelist))
		# 	currentModel.currentmod = np.argmax(np.array(self.confidencelist))

		
		# self.currentSedsModel = currentModel.currentmod



		et = self.listener.lookupTransform(self.model_source_frameid, self.model_target_frameid, rostime.Time(0))
		pos = list(et[0][:])
		xyrobot = np.array(pos[:3])
		# # print xyrobot
		for i in range(0, self.numOfModels):
			# self.distanceToGoals[i] = np.linalg.norm(xyrobot - np.array(self.targetsPosition[i]))
			self.distanceToGoals[i] = np.linalg.norm(npa(self.targetsPosition[i]) - xyrobot)
		# 	print self.distanceToGoals[i]

		if all(list(self.confidencelist)) == False:
			maxconfidence = 0
			currentModel.currentmod = 0
		else:
			for i in range(0, self.numOfModels):
				self.confidencelist[i] = (self.confidencelist[i] + 2*np.exp(-self.distanceToGoals[i]))/3.0
			maxconfidence = np.amax(np.array(self.confidencelist))
			currentModel.currentmod = np.argmax(np.array(self.confidencelist))

		if self.distanceToGoals[0] < 0.12 and xyrobot[0]-self.targetsPosition[0][0] < 0.07:
			print "in tar 0"
			maxconfidence = 0.9
			currentModel.currentmod = 0

		if self.distanceToGoals[1] < 0.26 and xyrobot[0]-self.targetsPosition[1][0] > -0.07:
			print "in tar 1"
			maxconfidence = 0.9
			currentModel.currentmod = 1
		# if self.distanceToGoals[0] < 0.15:
		# 	print "in tar 0"
		# 	currentModel.currentmod = 0

		# if self.distanceToGoals[1] < 0.15:
		# 	print "in tar 1"
		# 	currentModel.currentmod = 1

		# if self.distanceToGoals[2] < 0.15:
		# 	print "in here 2"
		# 	currentModel.currentmod = 2

		# print self.distanceToGoals

		# print "Conf List"
		print self.confidencelist
		self.confidence = maxconfidence
		print "Confidence is %f and the model is %d" % (maxconfidence, currentModel.currentmod)

		return currentModel



	def alpha_from_confidence(self, conf):
		if self.confslope != -1.0:
			if conf <= self.confthresh:
				return 0
			elif conf > self.confthresh and conf <= self.confmax:
				return self.confslope*(conf-self.confthresh)
			elif conf > self.confmax and conf <= 1.0:
				return self.alphamax
		else:
			if conf <= self.confthresh:
				return 0
			else:
				return self.alphamax


	# def compute_goal_confidence(self):
	# 	#each time the confidence is computed the target will change. which measn the ds_node should be updated about the change in target and obstacles
	# 	#can possibly have three different seds model running all the time. ANd then pick on based on the maximum confidence

	# 	t = self.listener.getLatestCommonTime(self.model_source_frameid, self.model_target_frameid)
	# 	# et = self.listener.lookupTransformFull(self.model_source_frameid, t, self.model_target_frameid, rostime.Time(0), "base_link")
	# 	et = self.listener.lookupTransform(self.model_source_frameid, self.model_target_frameid, rostime.Time(0))
	# 	currentrob = et[0][:] + euler_from_quaternion(et[1][:]) #wrt to base
	# 	# print currentrob
	# 	for i in range(0, self.numOfModels):
	# 		targetwrtrobot = npa(self.targets[i][:3]) - npa(currentrob[:3]) 
	# 		# targetwrtrobot = targetwrtrobot/(np.linalg.norm(targetwrtrobot)) # unit vector
	# 		# print targetwrtrobot
	# 		# currvel = npa(self.blend_vel.data[:3])
	# 		currvel = npa(self.smoothed_user_vel[:3])
	# 		# print np.linalg.norm(currvel)
	# 		if np.linalg.norm(currvel) > 0.00001:
	# 			self.cosangle[i] = np.dot(targetwrtrobot, currvel)/(np.linalg.norm(targetwrtrobot) * np.linalg.norm(currvel))
	# 			self.cosangle[i] = (self.cosangle[i] + 1)*0.5
	# 		else:
	# 			self.cosangle = [None]*self.numOfModels
			
	# 	# print self.cosangle

	# 	if all(list(self.cosangle)) == False:
	# 		# print "in here"
	# 		confidence = 0
	# 	else:
	# 		# self.cosangle = np.array(self.cosangle)
	# 		# confidence = np.amax(self.cosangle)
	# 		confidence = self.cosangle[1]
	# 	return confidence

	def userCallback(self, msg):
		# add new velocities to the list. compute smoothed velocity.
		# print "inside user vel callback"
		# print type(msg.data)
		# print "unsmoothed %s" % str(list(msg.data))
		popped = self.user_vel_list.pop(0)
		self.user_vel_list.append(list(msg.data[:6]))
		nparray = npa(self.user_vel_list)
		self.smoothed_user_vel[:6] = list(np.mean(nparray, axis=0))
		for i in range(0, self.numdof-2):
			self.smoothed_user_vel[i] = self.smoothed_user_vel[i]*0.6
		self.smoothed_user_vel[6] = msg.data[6]
		self.smoothed_user_vel[7] = msg.data[7]
		# print "smoothed %s" %  str(self.smoothed_user_vel)

	def autoCallback(self,msg):

		popped = self.seds_vel_list.pop(0)
		self.seds_vel_list.append(list(msg.data))
		nparray = npa(self.seds_vel_list)
		self.smoothed_seds_vel = list(np.mean(nparray, axis=0))

		# print self.seds_vel
		

def main():
	rospy.init_node("blend_node", anonymous=True);
	rospy.loginfo("In blending node")
	bn = BlendNode()
	# try:
	# 	rospy.spin()
	# except rospy.ROSInterruptException: pass

	rospy.loginfo("blend_node exiting")



if __name__ == '__main__':
	main()