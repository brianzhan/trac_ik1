#!/usr/bin/env python
#! /usr/bin/env python
"""
Author: Jeremy M. Stober
Program: DRIVER.PY
Date: Thursday, July 14 2011
Description: A generic driver class so that PR2 and WAM drivers (and other drivers) can share code.

To subclass this class:

Implement all init_* methods to create the necessary publishers (for
commands) and subscribers (for position information) and the code that
initializes all the variables at the beginning of every run loop
(init_start).

Implement get_current_position which takes the subscribed information
(in some type) and turns it into a list of floats for sending to
ds_node (the model).

Implement publish which takes the current computed new position (newx)
and formats it for publishing on the command topic.

That's it!

Some notes: Both pr2 and wam drivers shared the same basic structure
which is captured in this parent class. The main loop logic is

1. Read from some position topic.

2. Do some logic to update the current position (self.x) using either
the read position or the last position command.

3. Send this computed position to seds.

4. Compute a new position command (self.newx) and format it for
publishing to the command topic.


"""

import roslib
roslib.load_manifest('seds')
import actionlib

import rospy
import rospy.rostime as rostime
from seds.srv import DSSrv
from seds.srv import DSLoaded
# from seds.srv import ObsAvoidSrv
from seds.srv import FloatSrv, IntSrv, StringSrv, JtoC, JtoCRequest, JtoCResponse
from seds.msg import ObjDesc
from seds.msg import SedsVel
from seds.srv import ObjSrv, ObjSrvRequest, ObsAvoidSrv, ObsAvoidSrvRequest
from seds.srv import ObsAvoidSrv
from seds.srv import SedsModel
from seds.srv import SedsVelocities, SedsVelocitiesRequest
from geometry_msgs.msg import Point
from std_srvs.srv import Empty

import seds.msg as action_msg

import numpy as np
import numpy.linalg as la
import getopt
import sys
npa = np.array

import time
import tf
from tf.transformations import euler_from_quaternion, quaternion_from_euler, quaternion_inverse, quaternion_multiply
import threading

class Driver(object):

    def __init__(self, name, vm, feedback, rate):

        rospy.loginfo("Initialized with vm: %f and feedback: %s" % (vm, str(feedback)))

        self.useseds = True
        self.vm = vm
        self.tscale = 1.0
        self.dT = 0.01
        self.feedback = feedback
        self.rateInt = rate #this is thing which controls how many times should the main ros loop be running. 
        self.rate = rospy.Rate(rate)
        self.name = name
        self.numModels = 1
        self.currentModel = 0
        self.istransstop = False
        self.isrotstop = False

        # print "undu"
        # wait for the ds server
        
        # self.indiSedsVel = [SedsVel()]*self.numModels
        self.sedsvels = SedsVelocitiesRequest() # this can hold an array of seds velocities
        
        self.nameSpaces = [None]*self.numModels
        self.dl = [None]*self.numModels
        self.ds = [None]*self.numModels
        self.dsparams = [None]*self.numModels
        self.mod = [None]*self.numModels

        for i in range(0, self.numModels):
        	self.nameSpaces[i] = "/seds%d" % (i+1)


        for i in range(0, self.numModels):
        	rospy.loginfo("Waiting for ds_node " + self.nameSpaces[i])
        	rospy.wait_for_service(self.nameSpaces[i] + "/ds_node/ds_server")
        	rospy.loginfo("ds_node found! " + self.nameSpaces[i])
        	rospy.loginfo("Waiting for sedsobs node " + self.nameSpaces[i])
        	rospy.wait_for_service(self.nameSpaces[i] + "/seds/obs_mod_ellip")
        	rospy.loginfo("sedsobs_node found !" +self.nameSpaces[i])

        for i in range(0, self.numModels):
        	snisLoaded = self.nameSpaces[i] + "/ds_node/is_loaded"
        	self.dl[i] = rospy.ServiceProxy(snisLoaded, DSLoaded)
        	snds_Server = self.nameSpaces[i] + "/ds_node/ds_server"
        	self.ds[i] = rospy.ServiceProxy(snds_Server, DSSrv)
        	snds_Params = self.nameSpaces[i] + "/ds_node/params"
        	self.dsparams[i] = rospy.ServiceProxy(snds_Params, SedsModel)
        	snobs_mod = self.nameSpaces[i] + "/seds/obs_mod_ellip"
        	self.mod[i] = rospy.ServiceProxy(snobs_mod, ObsAvoidSrv)

        
        
        rospy.loginfo("Waiting for blending node service");
        self.computeconf = rospy.ServiceProxy("/mico_driver_cart/computeconfidence", SedsVelocities)

        self.jtocvels = JtoCRequest()
        self.convertjtoc = rospy.ServiceProxy("/supervisor/jointtocart", JtoC)
        # rospy.loginfo("Waiting for ds_node...")
        # rospy.wait_for_service("/ds_node/ds_server")
        # rospy.loginfo("ds_node found!")

        # rospy.loginfo("Waiting for sedsobs node")
        # rospy.wait_for_service("/seds/obs_mod_ellip")
        # rospy.loginfo("sedsobs node found");

        # self.dl = rospy.ServiceProxy("/ds_node/is_loaded", DSLoaded) # check whether the ds_server has a model
        # self.ds = rospy.ServiceProxy("/ds_node/ds_server", DSSrv) # the running model
        # self.dsparams = rospy.ServiceProxy("/ds_node/params", SedsModel)
        # self.mod = rospy.ServiceProxy("/seds/obs_mod_ellip", ObsAvoidSrv)

        
        self.startSRV = rospy.Service("/%s/start" % name, Empty, self.start)
        self.stopSRV = rospy.Service("/%s/stop" % name, Empty, self.stop)
        self.quitSRV = rospy.Service("/%s/quit" % name, Empty, self.quit)
        self.vmSRV = rospy.Service("/%s/set_vm" % name, FloatSrv, self.set_vm)
        self.rateSRV = rospy.Service("/%s/set_rate" % name, IntSrv, self.set_rate)
        self.fbSRV = rospy.Service("/%s/change_feedback" % name, StringSrv, self.change_feedback)
        self.toggleSRV = rospy.Service("/%s/toggle_seds" % name, Empty, self.toggle_seds)
        self.stepSRV = rospy.Service("/%s/step" % name, Empty, self.stepsrv)
        self.thresholdSRV = rospy.Service("/%s/set_threshold" % name, FloatSrv, self.set_threshold)
        self.statusSRV = rospy.Service("/%s/status" % name, Empty, self.show_status) # prints out status to ros_info

        self.zerot = rostime.Time(0)


        self.robopos = ObsAvoidSrvRequest()
        self.adaptive_threshold = 0.1 # 10 cm

        self.running = False
        self.runningCV = threading.Condition()

        self.init_publisher() # creates self.pub
        self.init_subscriber() # creates self.sub

    #def startActionServer(self):
        print "Driver AS starting"
        self._as = actionlib.SimpleActionServer("/%s/action_server" % name, action_msg.doSEDSAction, execute_cb=self.action_cb, auto_start = False)
        self._as.start()

    def action_cb(self,ignore):
        rospy.loginfo("In action call back");
        self.running=False
        self.finished_move=False
        self.start(ignore)
        if self.running==True:
            while self.finished_move==False:
                time.sleep(0.1)
            self.stop(ignore)
            self._as.set_succeeded()
        else:
            self._as.set_aborted()
        
    def init_publisher(self):
        """
        Override this in subclass.
        """
        self.pub = rospy.Publisher("/robot/publish", Point, queue_size=1)

    def callback(self, data):
        """
        Reads subscriber data.
        """
        self.runningCV.acquire()
        self.sdata = data
        self.runningCV.release()

    def init_subscriber(self):
        """
        Override this in subclass.
        """
        self.sub = rospy.Subscriber("/robot/subscribe", Point, self.callback)


    def toggle_seds(self, ignore):
        self.runningCV.acquire()
        self.useseds = not self.useseds
        self.runningCV.release()
        rospy.loginfo("Toggling seds to %s" % self.useseds)
        return []

    def set_vm(self, req):
        self.runningCV.acquire()
        self.vm = req.value
        self.runningCV.release()
        rospy.loginfo("VM set to %f" % self.vm)
        return []

    def set_rate(self, req):
        self.runningCV.acquire()
        self.rateInt = req.value
        self.rate = rospy.Rate(req.value)
        self.runningCV.release()
        rospy.loginfo("Rate set to %d" % req.value)
        return []

    def change_feedback(self, rec):
        self.runningCV.acquire()
        assert str(rec.value) in ('hard','none','adaptive')
        self.feedback = str(rec.value)
        self.runningCV.release()
        rospy.loginfo("Toggling feedback to %s" % self.feedback)
        return []

    def quit(self, ignore):
        """
        Call the quit service to quit the driver.
        """
        self.runningCV.acquire()
        self.running = False
        rospy.core.signal_shutdown("quit %s" % self.name)
        self.runningCV.release()
        return []


    def stop(self, ignore):
        """
        Call the stop service to stop the driver.
        """
        self.runningCV.acquire()

        self.running = False
        rospy.loginfo("%s stopping!" % self.name)

        self.runningCV.release()
        return []

    def show_status(self, ignore):
        rospy.loginfo("Name: %s" % self.name)
        rospy.loginfo("useseds: %s" % str(self.useseds))
        rospy.loginfo("vm: %s" % str(self.vm))
        rospy.loginfo("feedback: %s" % str(self.feedback))
        rospy.loginfo("rate: %s" % str(self.rateInt))
        rospy.loginfo("dT: %s" % str(self.dT))
        rospy.loginfo("tscale: %s" % str(self.tscale))
        rospy.loginfo("thresh: %s" % str(self.adaptive_threshold))
        #rospy.loginfo("source: %s" % str(self.model_source_frameid))
        return []

    def stepsrv(self, ignore):
        self.runningCV.acquire()
        self.step()
        self.runningCV.release()
        return []

    def init_start(self):
        """
        Called inside start to make sure everything is properly initialized.
        Override!
        """

        self.model = self.dsparams[self.currentModel]()
        self.endpoint = npa(self.model.model.offset)[:self.model.model.dim/2]
        self.dT = self.model.model.dT

        cntl_dt = 1.0 / float(self.rateInt)
        self.tscale = cntl_dt / self.dT

        rospy.loginfo("model dt: %s cntl dt: %s tscale : %s" % (self.dT, cntl_dt, self.tscale))
        rospy.loginfo("Dim %d" % self.model.model.dim)
        rospy.loginfo("Using endpoint %s" % str(self.endpoint))

        self.x = [self.sdata.x, self.sdata.y, self.sdata.z]
        self.newx = self.x

    def start(self, ignore):
        """
        Sets running to true and inits a number of important variables.
        """
        rospy.loginfo("In start () of driver class");
        self.runningCV.acquire()
        rospy.loginfo("Acquired");
        isallloaded = True
        for i in range(0, self.numModels):
        	res = self.dl[i]()
        	isallloaded = res.loaded and isallloaded 
        
        rospy.loginfo("has the model been loaded %s " % (res.loaded))
        if isallloaded:
            # init some variables
            # print "in res_loaded"
            result = self.init_start()
            # print result
            if result:
                print "Inside here"
                self.init_start()
                self.running = True
                rospy.loginfo("%s starting!" % self.name)
            else:
                rospy.loginfo("%s unable to start!" % self.name)
            #    self.runningCV.notify()
            #    self.runningCV.release()
                #return False
        else:
            rospy.loginfo("ds_node model not loaded -- not starting!")

        self.runningCV.notify()
        self.runningCV.release()
        #return True
        return []

    def publish(self):
        pt = Point()
        pt.x = self.newx[0]
        pt.y = self.newx[1]
        pt.z = self.newx[2]
        self.pub.publish(pt)
        rospy.logdebug("x : %s dx : %s newx : %s" % (str(self.x), str(self.dx), str(self.newx)))

    def step(self):
        self.compute_old_pose() # incorporate feedback
        self.compute_all_seds_vel()
        self.compute_new_pose() # using seds
        # if la.norm(npa(self.newx)-npa(self.endpoint))<self.adaptive_threshold:
        #     print "Reached the endpoint"
        #     # print la.norm(npa(self.newx) - npa(self.endpoint))
        #     print npa(self.newx)
        #     self.finished_move=True
        # else:
        #     print "Not endpoint"
        #     print la.norm(npa(self.newx) - npa(self.endpoint))
        #     self.finished_move=False
        isstop = self.check_end_condition()
        if isstop:
            print "Reached the endpoint"
            self.finished_move = True
            # self.newx = self.x
        else:
            # print "Not endpoint"
            self.finished_move = False

        #print self.x + self.newx
        self.publish() # publish the command



    def check_end_condition(self):
        npnewx = npa(self.x)
        npendpoint = npa(self.endpoint)
        dx = npnewx[0] - npendpoint[0]
        dy = npnewx[1] - npendpoint[1]
        dz = npnewx[2] - npendpoint[2]
        # for i in [3,5]:
        #     if(npendpoint[i] < 0):
        #         npendpoint[i] = npendpoint[i] + 2*np.pi
        #     if(npnewx[i] < 0):
        #         npnewx[i] = npnewx[i] + 2*np.pi

        der = npnewx[3] - npendpoint[3]
        # if(np.absolute(der) > np.pi):
        #     der = 2*np.pi - np.absolute(der)

        # der = der*0.8 #scale difference. huge changes in value correspond to relatively smaller changes
        dep = npnewx[4] - npendpoint[4]
        dey = npnewx[5] - npendpoint[5]

        # currquat = tuple(self.x[3:7])
        # endquat = tuple(self.endpoint[3:7])
        # quatdiff = list(quaternion_multiply(endquat, quaternion_inverse(currquat)))
        # print quatdiff[0]


        # if(np.absolute(dey) > np.pi):
        #     dey = 2*np.pi - np.absolute(dey)

        
        delta = np.array([dx,dy,dz, der,dep,dey])
        # print delta
        # print la.norm(delta)
        if(la.norm(delta) < self.adaptive_threshold):
			self.istransstop = True
			return True
        else:
			self.istransstop = False
			return False

    def set_threshold(self, req):
        self.runningCV.acquire()
        self.adaptive_threshold = req.value
        self.runningCV.release()
        rospy.loginfo("Threshold set to %f" % self.adaptive_threshold)
        return []

    def get_current_position(self):
        return [self.sdata.x, self.sdata.y, self.sdata.z]

    def compute_old_pose(self):

        """
        Seds sometimes produces velocities that are too small to
        overcome friction, leading to a frozen robot. Open loop
        control will overcome this friction (as the desired pose will
        begin to deviate from the actual pose and the command torques
        will rise). In the case of compliance, we have an adaptive
        feature that implements open loop locally, but updates using
        feedback if there is a big change to the robot pose (indicating
        perturbation by an outside source).
        """

        position = self.get_current_position()
        nx = npa(self.newx)
        cp = npa(position)
        #print nx
        #print cp
        rospy.logdebug("diff: %f" %  la.norm(nx - cp))

        if self.feedback == "adaptive":
            #print la.norm(nx-cp) + self.adaptive_threshold
            if la.norm(nx - cp) > self.adaptive_threshold:
                # something drastic has changed
                self.x = position
                #print "Perturbation detected!"
                rospy.logwarn("Perturbation detected %s" % str(la.norm(nx-cp)))
            else:
                self.x = self.newx

        elif self.feedback == "none":
            self.x = self.newx # old pose is last new pose
        elif self.feedback == "hard":
            self.x = list(position) # old pose is robot's reported pose
        else:
            raise ValueError, "Unknown feedback! %s" % self.feedback

    def compute_all_seds_vel(self):

    	del self.sedsvels.vels[:]
    	for i in range(0, self.numModels):
            indiVel = SedsVel()
            dx = list(self.ds[i](self.x).dx)
            newx = list(npa(self.x) + self.vm*self.tscale*npa(dx))
            indiVel.vel = list((npa(newx) - npa(self.x))*self.rateInt) #velocity vector for each model. Joint velocities
            self.jtocvels.jvels = indiVel.vel
            cart = self.convertjtoc(self.jtocvels).cvels #FK to convert to cartesian
            indiVel.vel = list(cart)
            self.sedsvels.vels.append(indiVel)

    	# for i in range(0, self.numModels):
    	# 	print "Velocity for Seds %d" % i
    	# 	print self.sedsvels.vels[i]
    	# print list(self.sedsvels.vels)
    	cm = self.computeconf(self.sedsvels).currentmod
    	self.reassignCurrentmodel(cm)
    	# print cm

    def reassignCurrentmodel(self, modelNum):
    	self.currentModel = modelNum
    	self.model = self.dsparams[self.currentModel]()
    	self.endpoint = npa(self.model.model.offset)[:self.model.model.dim/2]

    def compute_new_pose(self):
        if self.useseds:
			self.dx = list(self.ds[self.currentModel](self.x).dx) #same as line 226 in Simulation.m
			# self.robopos.x = self.x[:3]
			# self.robopos.dx = self.dx[:3]
			# self.cartdx = list(self.mod[self.currentModel](self.robopos).moddx) #the modulated cartesian velcoity is this
            # print self.dx[:3]
            # print "****************"
            # print self.cartdx
            # print "&&&&&&&&&&&&&&&"
			# self.dx[:3] = self.cartdx
			# # self.dx[3:6] = list(npa(self.dx[3:6])*0.1)
			# self.dx[3:7] = list(npa(self.dx[3:7]))
            # tscale accounts for timing differences, vm is a hack to overcome friction
			self.newx = list(npa(self.x) + self.vm * self.tscale * npa(self.dx)) # this is 6d
        else: # just set the endpoint (might cause torque fault on some robots e.g. WAM)
            self.newx = self.endpoint

    def spin(self):

        rospy.loginfo("Running!")

        try:

            while not rospy.is_shutdown():

                self.runningCV.acquire()
                if self.running:

                    self.step()
                    self.rate.sleep()

                else:

                    # wait around until a start service call
                    # check for an interrupt every once and awhile
                    self.runningCV.wait(1.0)

                self.runningCV.release()

        except KeyboardInterrupt:
            rospy.logdebug('keyboard interrupt, shutting down')
            rospy.core.signal_shutdown('keyboard interrupt')

def main():

    # rospy gets first crack at sys.argv
    rospy.myargv(argv=sys.argv)
    (options,args) = getopt.getopt(sys.argv[1:], 'v:f:', ['vm=','feedback='])

    rospy.init_node('test_driver')

    vm = rospy.get_param("/test_driver/velocity_multiplier", 1.0)
    feedback = rospy.get_param("/test_driver/feedback", 'hard')

    for o,a in options:
        if o in ('-v','--vm'):
            vm = float(a)
        elif o in ('-f','--feedback'):
            assert a in ('none','hard','adaptive')
            feedback = a

    driver = Driver("test_driver", vm, feedback, 100) # start node
    #driver.startActionServer()
    driver.spin()

if __name__ == '__main__':
    main()
