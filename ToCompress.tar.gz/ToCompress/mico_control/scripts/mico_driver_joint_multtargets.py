#!/usr/bin/python

import roslib
roslib.load_manifest('seds')

import rospy
import math
import driver_multiple_joint_multtargets
import rospy.rostime as rostime
# from std_msgs.msg import Float64
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64, Float32MultiArray, MultiArrayDimension
from geometry_msgs.msg import PoseStamped, Pose, Point, Quaternion
from seds.srv import DSEndPoint
import numpy as np
import numpy.linalg as la 
import getopt
import sys
import tf
from tf.transformations import euler_from_quaternion, quaternion_from_euler, quaternion_inverse, quaternion_multiply

npa = np.array

class MICODriverCart(driver_multiple_joint_multtargets.Driver):
	def init_publisher(self):
		self.cartsig = rospy.Publisher('seds_vel', Float32MultiArray, queue_size=1) # this plays the role of the joy stick
		self.roll = rospy.Publisher('roll', Float64, queue_size=1)
		self.pitch = rospy.Publisher('pitch', Float64, queue_size=1)
		self.yaw = rospy.Publisher('yaw', Float64, queue_size=1)
		self.pose = rospy.Publisher('fullpose', PoseStamped, queue_size=1)
		self.targetpose = rospy.Publisher('targetpose', Float32MultiArray, queue_size=1)
		self.diffpose = rospy.Publisher('diffpose', PoseStamped, queue_size=1)

		self.jsvelsPub = rospy.Publisher('/robotjsvels', Float32MultiArray, queue_size=1)



	def init_subscriber(self):
		self.listener = tf.TransformListener(True, rospy.Duration(30))
		self.js = rospy.Subscriber('joint_states', JointState, self.assignCurrentJoints)
		# self.cartfromjs = rospy.Subscriber('measured_cartesian_velocity', Float32MultiArray, self.getCartVel)

	def __init__(self, name, vm, feedback, rate, thresh):
		self.firsttime = True
		driver_multiple_joint_multtargets.Driver.__init__(self, name, vm, feedback, rate)

		# self.source_frameid = source_frameid
		# self.target_frameid = target_frameid
		# self.model_source_frameid = msfid
		# self.model_target_frameid = mtfid
		self.adaptive_threshold = thresh
		self.rotmult = 1.4
		self.oldquat = npa([0,0,0,0])
		self.currquat = npa([0,0,0,0])
		
		# if waittf:
		# 	self.wait_for_transform(source_frameid, target_frameid)

		self.cmd = Float32MultiArray()
		_dim = [MultiArrayDimension()]
		_dim[0].label = 'cartesian_velocity'
		_dim[0].size = 8
		_dim[0].stride = 8
		self.cmd.layout.dim = _dim
		# for i in range(0,6):
		# 	self.cmd.data[i] = 0.0

		# rospy.loginfo("So far so good")
		self.setendpointSRV = rospy.Service("/%s/setendpoint" % name, DSEndPoint, self.set_endpoint)


	# def wait_for_transform(self, sfid, tfid):
	# 	rospy.loginfo('Waiting for transform...')
	# 	tfound = False
 #        #while not tfound:
	# 	try:
	# 		self.listener.waitForTransform(source_frame=sfid, target_frame=tfid,time=self.zerot,timeout=rostime.Duration(10))
	# 		tfound = True # no exception
	# 		rospy.loginfo('Transform found!')
	# 	except tf.Exception, error:
	# 		rospy.logwarn(error)
	# 	return tfound
		
	def init_start(self):
		print "In this ini_start"
		self.model = self.dsparams[self.currentModel]()
		self.endpoint = npa(self.model.model.offset)[:self.model.model.dim/2]
		self.dT = self.model.model.dT
		cntl_dt = 1.0 / float(self.rateInt)
		
		# if self.model_source_frameid=="":
		# 	self.model_source_frameid = self.model.model.source_fid
        #if self.model_target_frameid=="":
        #    self.model_target_frameid = self.model.model.target_fid
		# self.model_target_frameid=self.target_frameid
		self.tscale =  cntl_dt / self.dT
		# print self.model_source_frameid
		# print self.model_target_frameid
		# ret = self.wait_for_transform(self.model_source_frameid, self.model_target_frameid)
		# # print ret
		# if ret != True:
		# 	# print "false now???"
		# 	return False
		# et = self.listener.lookupTransform(self.model_source_frameid, self.model_target_frameid, self.zerot)
		# # print et
		# pos = list(et[:][0])
		# # eu = list(euler_from_quaternion(et[:][1]))
		# eu = list(et[:][1])
		# # for i in [0,2]:
		# # 	if(eu[i] < 0):
		# # 		eu[i] = eu[i] + 2*np.pi
		# self.x = pos + eu 
		# # self.x = et[0][:]+euler_from_quaternion(et[1][:])
		# self.newx = self.x


		return True

	def assignCurrentJoints(self, msg):
		self.x = msg.position[2:]
		if self.firsttime == True:
			self.newx = self.x
			self.firsttime = False

	# def getCartVel(self, msg):
	# 	cartvel = Float32MultiArray()
	# 	a =[0]*8
	# 	a[:6] = list(msg.data)
	# 	# print a
	# 	cartvel.data = a
	# 	self.cartsig.publish(cartvel)

	def set_endpoint(self, req):
		print "In the set_endpointservice" # don't use acquire and release thread. fights with the spin loop.
		self.endpoint = npa(req.x)
		print self.endpoint
		return []

	def get_current_position(self):
		
		return self.x
		# try:
		# 	t = self.listener.getLatestCommonTime(self.model_source_frameid, self.model_target_frameid)
		# 	et = self.listener.lookupTransformFull(self.model_source_frameid, t, self.model_target_frameid, rostime.Time(0), "base_link")
		# 	pos = list(et[:][0])
		# 	quat = et[:][1]
		# 	# eu = list(euler_from_quaternion(quat))
		# 	eu = list(quat)

		# 	self.currquat = np.array(list(quat))
		# 	if self.currquat[0]/np.absolute(self.currquat[0]) == -1.0:
		# 		# print "flip quat"
		# 		eu = np.array(eu)
		# 		eu = list(-eu)
		# 	# print "sum"
		# 	# print self.currquat+self.oldquat

		# 	self.oldquat = self.currquat
		# 	# newposestamped = PoseStamped()
		# 	# newpose = Pose()
		# 	# newpose.position = Point(pos[0], pos[1], pos[2])
		# 	# # newpose.position.x = pos[0]
		# 	# # newpose.position.y = pos[1]
		# 	# # newpose.position.z = pos[2]
		# 	# newpose.orientation = Quaternion(quat[0], quat[1], quat[2], quat[3])
		# 	# newposestamped.pose = newpose
		# 	# newposestamped.header.frame_id = "base_link"
		# 	# newposestamped.header.stamp = rospy.Time.now()

		# 	x = list(euler_from_quaternion(tuple(self.endpoint[3:7])))
		# 	tp = Float32MultiArray()
		# 	tp.data = x
		# 	tp.layout.dim = [MultiArrayDimension()]
		# 	dim = [MultiArrayDimension()]
		# 	dim[0].size = 3
		# 	dim[0].stride = 3
		# 	tp.layout.dim = dim
		# 	# targetposestamped = PoseStamped()
		# 	# x = list(self.endpoint)
		# 	# newposet = Pose()
		# 	# newposet.position = Point(x[0], x[1], x[2])
		# 	# y = quaternion_from_euler(x[3], x[4], x[5])
		# 	# newposet.orientation = Quaternion(y[0], y[1], y[2], y[3])
		# 	# targetposestamped.pose = newposet
		# 	# targetposestamped.header.frame_id = "base_link"
		# 	# targetposestamped.header.stamp = rospy.Time.now()
		# 	self.targetpose.publish(tp)
		# 	# self.pose.publish(newposestamped)

		# 	# inv = quaternion_inverse((y[0],y[1],y[2],y[3]))
		# 	# diffquat = list(np.multiply(npa(list(et[:][1])), npa(list(inv))))
		# 	# differencepose = Pose()
		# 	# differencepose.position = Point(pos[0] -x[0], pos[1]-x[1], pos[2]-x[2])
		# 	# differencepose.orientation = Quaternion(diffquat[0], diffquat[1], diffquat[2], diffquat[3])
		# 	# # differencepose = newpose.inverseTimes(newposet)

		# 	# diffposestamped = PoseStamped()
		# 	# diffposestamped.pose = differencepose
		# 	# diffposestamped.header.frame_id = "base_link"
		# 	# diffposestamped.header.stamp = rospy.Time.now();
		# 	# self.diffpose.publish(diffposestamped)
		# 	# t2 = self.listener.getLatestCommonTime("Wrist_2_Link", "Hand_Link")
		# 	# et2 = self.listener.lookupTransformFull("Wrist_2_Link", t2, "Hand_Link", rostime.Time(0), "base_link")
			
		# 	# eu2 = list(euler_from_quaternion(et2[:][1]))
		# 	#perform wrap arounds before querying the model
		# 	# for i in [0,2]:
		# 	# 	if(eu[i] < 0):
		# 	# 		eu[i] = eu[i] + 2*np.pi
		# 	# if eu[0] < 0:
		# 	# 	eu[0] = eu[0] + 2*np.pi

		# 	eufromquat = euler_from_quaternion(quat)
		# 	self.roll.publish(eufromquat[0])
		# 	self.pitch.publish(eufromquat[1])
		# 	self.yaw.publish(eufromquat[2])
		# 	# print eu
		# 	return pos + eu
		# except tf.Exception, error:
		# 	rospy.loginfo("%s tf exception in gcp: %s!", self.name, error)

		# return self.newx

	def publish(self):

		# when the ik is using prpy util it can deal with the entire 6d at once. no need to 0 out any part of the entire pose.
		# print self.newx
		self.cmd.data = [0,0,0,0,0,0]
		# print "this is the file"
		for i in range(0,6):
			self.cmd.data[i] = (self.newx[i] - self.x[i])*self.rateInt
			if self.cmd.data[i] < -0.25:
				self.cmd.data[i] = -0.25
			if self.cmd.data[i] > 0.25:
				self.cmd.data[i] = 0.25
		
		# self.cmd.data[5] = self.cmd.data[5]*0.8
		# print self.cmd.data
		# for i in range(3,6):
		# 	self.cmd.data[i] = (self.newx[i+1] - self.x[i+1])*self.rateInt

		# if(not self.newx == self.x):
		# 	quatnew = np.array(self.newx[3:7])
		# 	quatnew = quatnew/la.norm(quatnew)
		# 	quatnew = tuple(quatnew)
		# 	quatold  = tuple(self.x[3:7])
		# 	quatdiff = quaternion_multiply(quatold, quaternion_inverse(quatnew))
		# 	quatdiff = npa(quatdiff)
		# 	quatdiff = quatdiff/la.norm(quatdiff)

		# 	# print euler_from_quaternion(quatdiff)
		# 	self.cmd.data[3:6] = list(npa(euler_from_quaternion(quatdiff))*self.rateInt*self.rotmult)
		# 	eunew = euler_from_quaternion(quatnew)
		# 	euold = euler_from_quaternion(quatold)
		# 	# print npa(eunew) - npa(euold)
		# 	# for i in range(0,3):
		# 	# 	if(math.fabs(eunew[i] - euold[i])) > math.pi:
		# 	# 		print "Enter flip zone"
		# 	# 		self.cmd.data[i+3] = -self.cmd.data[i+3]
		# # if(not self.newx == self.x):
		# # 	epquat = self.endpoint[3:7]
		# # 	currquat = self.x[3:7]
		# # 	epeu = euler_from_quaternion(tuple(epquat))
		# # 	curreu = euler_from_quaternion(tuple(currquat))
		# # 	for i in range(0,3):
		# # 		sign = math.fabs(epeu[i] - curreu[i])/(epeu[i] - curreu[i])
		# # 		self.cmd.data[i+3] = sign*0.3
			
				


		# 	# self.cmd.data[3:6] = 0.3*(npa(euler_from_quaternion(npa(self.newx[3:7])))- npa(euler_from_quaternion(npa(self.x[3:7]))))*self.rateInt
		# # print npa(self.newx) - npa(self.x)
		# # self.cmd.data[3:6] = list(euler_from_quaternion(npa(self.newx[3:7]) - npa(self.x[3:7]))*self.rateInt)
		# for i in range(3,6):
		# 	if self.cmd.data[i] < -0.2:
		# 		self.cmd.data[i] = -0.2
		# 	if self.cmd.data[i] > 0.2:
		# 		self.cmd.data[i] = 0.2

		if self.istransstop == True:
			for i in range(0,6):
				self.cmd.data[i] = 0
		# self.cmd.data[0] = 0.0
		# self.cmd.data[1] = 0.0
		# self.cmd.data[2] = 0.0
	
		# self.cmd.data[6] = 0.0
		# self.cmd.data[7] = 0.0

		# jsvel = Float32MultiArray()
		# _dim = [MultiArrayDimension()]
		# _dim[0].label = 'joint_vels'
		# _dim[0].size = 6
		# _dim[0].stride = 6
		# jsvel.layout.dim = _dim
		# jsvel.data = self.cmd.data

		# self.jsvelsPub.publish(jsvel)
		
		self.jtocvels.jvels = self.cmd.data
		cartvel = self.convertjtoc(self.jtocvels).cvels
		self.cmd.data = list(cartvel)
#check for collision with table....brute force
		# currx = npa(self.x)
		# if currx[2] < 0.06:
		# 	print "close to table"
		# 	for i in range(0,8):
		# 		self.cmd.data[i] = 0.0

		# 	self.cmd.data[2] = 0.05
		# # print self.cmd.data
		# print self.cmd.data
		# if np.linalg.norm(np.array(self.cmd.data)) < 0.01: # low seds velocity
		# 	self.cmd.data = [0]*8
		# print self.cmd.data
		#no need to change the coordinate reference. In any coordinate frame the difference in piositions (ie velocities along each dimension will be the same). pr2 is position control.
		# for i in range(3,6):
		# 	self.cmd.data[i] = self.cmd.data[i]*1.0

		self.cartsig.publish(self.cmd) # 6d pose velocities. 
		#Here publish fill out the self.cmd with the vel vector from SEDS+obs6tacle avoidance.And opublish. 

def main():
	rospy.myargv(argv=sys.argv)
	(options, args) = getopt.getopt(sys.argv[1:], 'v:f:s:t:a:', ['vm=','feedback=','source=','target=','athresh='])
	rospy.init_node('mico_driver_joint')
	# source_frameid = rospy.get_param("/mico_cart/base_name","base_link")
	# target_frameid = rospy.get_param("/mico_cart/hand_name","Hand_Link")
	vm = rospy.get_param("/mico_driver_cart/velocity_multiplier", 1)
	feedback = rospy.get_param("/mico_driver_cart/feedback", 'adaptive')
	msfid=""
	mtfid=""
	adaptive_threshold=0.1
	for o,a in options:
		if o in ('-v','--vm'):
			vm = float(a)
		elif o in ('-f','--feedback'):
			assert a in ('none','hard','adaptive')
			feedback = a
		elif o in ('-s','--source'):
			msfid = a
		elif o in ('-t','--target'):
			mtfid = a
		elif o in ('-a','--athresh'):
			adaptive_threshold = float(a)

	driver = MICODriverCart('mico_driver_cart', vm, feedback, 100, adaptive_threshold) # start node
	driver.spin()

if __name__ == '__main__':
	main()