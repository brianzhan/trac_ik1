#!/usr/bin/python

import roslib
roslib.load_manifest('seds')

import rospy
import driver
import rospy.rostime as rostime
from std_msgs.msg import Float64
from sensor_msgs.msg import JointState
import numpy
import numpy.linalg as la 
import getopt
import sys
npa = numpy.array


class MICODriver(driver.Driver): 

	def callback(self, data):
		self.runningCV.acquire
		self.current_pose = data
		self.runningCV.release

	def init_publisher(self):
		self.j1pub = rospy.Publisher('/ada/vel_j1_controller/command', Float64, queue_size=1)
		self.j2pub = rospy.Publisher('/ada/vel_j2_controller/command', Float64, queue_size=1)
		self.j3pub = rospy.Publisher('/ada/vel_j3_controller/command', Float64, queue_size=1)
		self.j4pub = rospy.Publisher('/ada/vel_j4_controller/command', Float64, queue_size=1)
		self.j5pub = rospy.Publisher('/ada/vel_j5_controller/command', Float64, queue_size=1)
		self.j6pub = rospy.Publisher('/ada/vel_j6_controller/command', Float64, queue_size=1)


	def init_subscriber(self):
		self.current_pose = JointState()
		self.sub = rospy.Subscriber('/ada/joint_states', JointState, self.callback)

	

	def init_start(self):
		self.model = self.dsparams()
		self.endpoint = npa(self.model.model.offset)[:self.model.model.dim/2] #this has been stored in the model, this is the target point. which will be subtracted from each of the data points while doing regression
		self.dT = self.model.model.dT

		cntl_dt = 1.0/float(self.rateInt)
		self.tscale = cntl_dt/self.dT
		self.x = list(self.current_pose.position[0:6]) #only first 3 dimensions for the time being. First 3 joint states
		self.newx = self.x
		return True
    	# return True


	
	def __init__(self,name, vm,feedback,rate):
		driver.Driver.__init__(self, name,vm, feedback, rate)

	def publish(self):
		rospy.logdebug("x : %s dx : %s newx : %s" % (str(self.x), str(self.dx), str(self.newx)))
		
		self.j1pub.publish((self.newx[0] - self.x[0])*self.rateInt) # possibly the way to change delta in position to current velocity....,maybe
		self.j2pub.publish((self.newx[1] - self.x[1])*self.rateInt)
		self.j3pub.publish((self.newx[2] - self.x[2])*self.rateInt)
		self.j4pub.publish((self.newx[3] - self.x[3])*self.rateInt)
		self.j5pub.publish((self.newx[4] - self.x[4])*self.rateInt)
		self.j6pub.publish((self.newx[5] - self.x[5])*self.rateInt)


	def get_current_position(self):
		return self.current_pose.position[0:6]

def main():
	rospy.myargv(argv=sys.argv)
	(options,args) = getopt.getopt(sys.argv[1:], 'v:f:', ['vm=','feedback='])

	rospy.init_node('mico_driver')
	vm = rospy.get_param("/mico_driver/velocity_multiplier", 1.0)
	feedback = rospy.get_param("/mico_driver/feedback", 'none')

	for o,a in options:
		if o in ('-v', '--vm'):
			vm = float(a)
		elif o in ('-f', '--feedback'):
			assert a in ('none', 'hard', 'adaptive')
			feedback = a

	driver = MICODriver('mico_driver', vm, feedback, 500)
	driver.spin()

	
if __name__ == '__main__':
	main()